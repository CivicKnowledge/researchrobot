
demosearch
==========

A demographics radius search service

Description
-----------

A longer description of your project goes here...


Development
-----------

Use pyment to manage, create and update doc strings:

    find . -type f -name '*.py' -exec pyment -w {} \;