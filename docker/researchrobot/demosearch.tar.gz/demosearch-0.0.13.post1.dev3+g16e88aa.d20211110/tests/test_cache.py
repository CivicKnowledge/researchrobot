import unittest

from demosearch import cache

class TestBasic(unittest.TestCase):
    """ """




    def test_basic_File(self):
        """ """

        dc = cache.FileCache('/tmp/cache_test')

        dc.put('foo','bar')
        self.assertEqual(dc.get('foo'), 'bar')

    def test_config(self):
        """ """
        dc = cache.FileCache('/tmp/cache_test')

        dc.put('foo', 'bar')
        self.assertEqual(dc.get('foo'), 'bar')

        dc.config['foobar'] = 'baz'

        self.assertEqual(dc.config['foobar'], 'baz')

    def test_redis_cache(self):
        """ """
        import demosearch as ds
        from demosearch.cache import RedisCache

        config = ds.ConfigFile.default(testing=False)
        r = RedisCache.get_redis(config)
        print(r)

        config = ds.ConfigFile.default(testing=True)
        r = RedisCache.get_redis(config)
        print(r)

        r.put('test_int',101)
        self.assertEqual(101, r.get('test_int'))

        r.delete('test_int')

        with self.assertRaises(KeyError):
            r.get('test_int')


if __name__ == '__main__':
    unittest.main()
