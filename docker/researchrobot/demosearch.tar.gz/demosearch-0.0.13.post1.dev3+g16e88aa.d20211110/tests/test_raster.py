import warnings

warnings.simplefilter("ignore")
import unittest
import osmnx as ox
from demosearch import *
from demosearch.raster import *

from .testlib import RasterTest

def rms_diff(a, b):
    """

    :param a: 
    :param b: 

    """
    return np.sqrt(np.square(np.subtract(a, b)).sum())


class TestLocations(RasterTest):
    """ """

    def setUp(self):
        """ """
        super().setUp()

    def test_basic(self):
        """ """
        rm = RasterManager(self.cache)

        region = ox.geocode_to_gdf('San Diego County, California')

        z = rm.get_zone(region[['lat', 'lon']])
        self.assertEqual(11, z.band)

        z = rm.get_zone(region[['bbox_west', 'bbox_south', 'bbox_east', 'bbox_north']])
        self.assertEqual(11, z.band)

        z = rm.get_zone(region)
        self.assertEqual(11, z.band)

        z = rm.get_zone(11)
        self.assertEqual(11, z.band)



if __name__ == '__main__':
    unittest.main()
