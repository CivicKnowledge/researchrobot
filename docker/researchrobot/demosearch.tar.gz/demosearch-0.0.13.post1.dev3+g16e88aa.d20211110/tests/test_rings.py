import unittest
from demosearch import *
import pandas as pd

class TestRings(unittest.TestCase):
    """ """

    def test_basic(self):
        """ """

        cache = FileCache('/Volumes/SSD_Extern/radius')

        t = pd.read_csv('/Users/eric/proj/code-projects/radius-search/Notebooks/addresses.csv')
        addr_latlon = [(r.lat, r.lon) for idx, r in t.iterrows()]

        sr = SearchRings(cache, *addr_latlon[4])
        print(sr.tracts.head())


if __name__ == '__main__':
    unittest.main()
