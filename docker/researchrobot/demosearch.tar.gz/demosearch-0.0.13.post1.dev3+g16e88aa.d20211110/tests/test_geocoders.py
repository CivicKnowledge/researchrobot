import unittest
from operator import itemgetter

import demosearch as ds
from demosearch.geocode import CachingGeocoder

from .locations import locations

config = ds.ConfigFile.default(testing=True)


# logging.basicConfig(level=logging.INFO)

class TestGeocoders(unittest.TestCase):
    """ """

    def test_basic(self):
        """ """
        cg = CachingGeocoder(config)

        print(cg.primary_geocoders)
        print(cg.backup_geocoders)

        rd = cg.redis
        rd.set('test', 1)
        print(rd.get('test'))

    def test_geocode(self):
        """ """

        ig = itemgetter('_cache', 'lat', 'lng')

        cg = CachingGeocoder(config)

        r = cg.geocode('1370 Wilbur Ave, San Diego, California')
        self.assertEqual(ig(r), ('miss', 32.806641, -117.247275))

        r = cg.geocode('1370 Wilbur Ave, San Diego, California')
        self.assertEqual(ig(r), ('hit', 32.806641, -117.247275))

    def test_bbox(self):


        ig = itemgetter('_cache', 'lat', 'lng')

        cg = CachingGeocoder(config)

        r = cg.gc_nom('1370 Wilbur Ave, San Diego, California')
        self.assertEqual(ig(r), ('miss', 32.806641, -117.247275))

        r = cg.gc_open_cage('1370 Wilbur Ave, San Diego, California')
        self.assertEqual(ig(r), ('hit', 32.806641, -117.247275))

    def test_backups(self):
        """ """
        ig = itemgetter('_cache', 'lat', 'lng')

        cg = CachingGeocoder(config)

        l = locations[0]

        for c in cg.backup_geocoders:
            r = cg._geocode(l, *c)

            print(c[1], ig(r))

    def test_locations(self):
        """ """
        from collections import Counter

        ig = itemgetter('_cache', '_geocoder', 'lat', 'lng')

        counters = []
        coder_counts = []

        for testing in (True, False):

            config = ds.ConfigFile.default(testing=testing)
            cg = CachingGeocoder(config)

            results = []

            for l in locations:
                r = cg.geocode(l)
                results.append((*ig(r), l))

            for l in locations:
                r = cg.geocode(l)
                results.append((*ig(r), l))

            coder_counts.append(Counter([e[1] for e in results]))
            counters.append(Counter([e[0] for e in results]))

        print(counters)
        print(coder_counts)

        # With the testing cache, which is cleared, the first half should be misses
        # and the second half are hits
        self.assertEqual(counters[0]['miss'], 10)
        self.assertEqual(counters[0]['hit'], 10)

    def test_caching(self):
        """ """

        lines = ['2321 N Druid Hills Road, Atlanta, GA 30329',
                 'Gromfromble',
                 '110 E Second St, Austin, TX 78701',
                 'San Diego, CA',
                 '6160 Roswell Road, Atlanta, GA 30328',
                 '3330 Piedmont Road, Atlanta, GA 30305',
                 'San Diego',
                 '33.8735021, -84.381014',
                 '907 W  5th St, Austin, TX 78703',
                 '10107 Research Blvd, Austin, TX 78759',
                 '1801 E. 51ST STREET BLDG A, Austin, TX 78723',
                 '3393 Peachtree Rd, Atlanta, GA 30326']

        rm = ds.ConfigFile.default().manager

        x = rm.geocode_user_args(lines)


if __name__ == '__main__':
    unittest.main()
