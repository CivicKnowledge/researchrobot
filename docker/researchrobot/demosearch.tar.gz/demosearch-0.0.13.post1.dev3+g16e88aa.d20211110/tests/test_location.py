import warnings

warnings.simplefilter("ignore")
import unittest
import osmnx as ox
from demosearch import *
import numpy as np
import demosearch as ds
from demosearch.raster import RasterInfo
from demosearch.geo import *


def rms_diff(a, b):
    """

    :param a: 
    :param b: 

    """
    return np.sqrt(np.square(np.subtract(a, b)).sum())


class TestLocations(unittest.TestCase):
    """ """

    def setUp(self):
        """ """
        # Requires system to be built

        # BOunding box of La Jolla Ca
        self.lj = -117.35087, 32.7526, -117.1458, 32.8862

        # A portion of San Diego
        inner_sd = -117.31, 32.57, -116.8, 33.21

        # Center of the La Jolla bounding box
        self.ljc = np.mean([self.lj[1], self.lj[3]]), np.mean([self.lj[0], self.lj[2]])



    def test_basic(self):
        """ """

        ll = LatLon(self.ri, *self.ljc)

        self.assertEqual(ll, ll.utm.ll)
        self.assertEqual(ll, ll.pix.ll)
        self.assertEqual(ll.utm, ll.pix)


    def testArgs(self):
        """ """
        city = self.city
        rz = self.rm.get_zone(11)['extra_points']
        print(rz._llbb_args(city.total_bounds))
        print(rz._llbb_args(city.total_bounds[:2]))
        print(rz._llbb_args(city.lat, city.lon, ll=True))

    def test_bb(self):
        """ """
        rz = self.rm.get_zone(11)['extra_points']
        t = LatLonBbox.from_bbox(rz, *list(self.city.total_bounds))

        # They will be different because of truncation ad the edges of the
        # raster
        self.assertLess(rms_diff(list(t), self.city.total_bounds), 0.04)

        # No truncation, but slight differences because of conversions
        bkr = ox.geocode_to_gdf('Bakersfield, California')
        bb = LatLonBbox.from_bbox(rz, *list(bkr.total_bounds))
        self.assertLess(rms_diff(list(bb), bkr.total_bounds), 1e-10)

        print(bb.pix)



    def test_ll(self):
        """ """
        rz = self.rm.get_zone(11)['extra_points']
        ll = rz.latlon(self.city.lat, self.city.lon)  # Centroid?
        self.assertEqual(ll.lat, float(self.city.lat))
        self.assertEqual(ll.lon, float(self.city.lon))


    def test_cvt(self):
        """Test various inputs to  cvt_loc_arg"""
        from random import shuffle

        locations = [
            "2409 Grand Canal, Venice, CA 90291",
            "553 Central Ave, Kansas City, KS 66101",
            "2249 Central Ave, Memphis, TN 38104",
            "7004 Charlotte Pike, Nashville, TN 37209",
            "2209 N Slappey Blvd Albany, GA 31701",
            "12233 Ranch Rd 620 N suite 105, Austin, TX 78750",
            "155 Mose Coleman Dr, Vidalia, GA 30474-8676",
            "116 Glenn Falls St, Peachland, NC 28133",
            "1120 S Lewis St, Metter, GA 30439",
            "2020 Demere Rd., St. Simons Island GA 31522 ",
        ]

        rm = ds.ConfigFile.default().manager

        layers = list(rm.layers.keys())
        shuffle(layers)
        layers = layers[:len(locations)]

        ll_obj = []
        ll_str = []
        for layer, loc in zip(layers, locations):
            try:
                ll = rm.process_location_arg(loc, layer=layer)
                ll_obj.append(ll.center)
            except Exception as e:
                print(loc, e)

        for layer, loc in zip(layers, ll_obj):
            ll = rm.process_location_arg(loc, layer=layer)
            ll_str.append(f"{list(ll)[0]}, {list(ll)[1]}")

            assert list(ll) == list(loc)

        def rl(l):
            return [round(e, 4) for e in list(l)]

        for layer, loc, llo in zip(layers, ll_str, ll_obj):
            ll = rm.process_location_arg(loc, layer=layer)

            assert rl(ll) == rl(llo), (loc, list(ll), list(llo))

        metros = ["San Diego", ' La Jolla, San Diego, Ca', 'Gaslamp, San Diego, Ca',
                  "New York, New York"]

        metro_bb = [
            [-117.61108100000001, 32.52883199999999, -116.08094000000001, 33.505024999999996],
            [-117.3116839, 32.79259, -117.23168390000001, 32.87259000000001],
            [-117.1701106, 32.701486, -117.1501106, 32.721486],
            [-75.359184, 39.47519799999999, -71.86741070745227, 41.60436180491015]

        ]

        for layer, loc, bb in zip(layers, metros, metro_bb):
            ll = rm.process_location_arg(loc, layer=layer)

            assert rl(ll) == rl(bb), (loc, list(ll), list(bb))

if __name__ == '__main__':
    unittest.main()
