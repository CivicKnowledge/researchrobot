import fiona
import warnings

warnings.simplefilter("ignore")
import unittest
import demosearch as ds
import numpy as np

from .testlib import RasterTest

def rms_diff(a, b):
    """

    :param a: 
    :param b: 

    """
    return np.sqrt(np.square(np.subtract(a, b)).sum())


class TestLocations(RasterTest):
    """ """

    def setUp(self):
        """ """
        super().setUp()
        self.rm = ds.ConfigFile.default().manager

    def test_basic(self):
        """ """

        t = self.rm.ftsearch('San Diego').iloc[0]
        self.assertEqual(np.sum(t.bb).round(3), -167.658)

        t = self.rm.geocoder.geocode('680 N High St Columbus, OH 43215')
        self.assertEqual(np.sum(t['raw']['boundingbox']).round(3), -167.658)


if __name__ == '__main__':
    unittest.main()
