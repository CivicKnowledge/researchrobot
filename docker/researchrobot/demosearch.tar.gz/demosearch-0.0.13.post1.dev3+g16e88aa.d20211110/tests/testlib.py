import warnings
import unittest
warnings.simplefilter("ignore")
from demosearch import *
from demosearch.raster import *

class RasterTest(unittest.TestCase):
    """ """

    def setUp(self):
        """ """
        pass
