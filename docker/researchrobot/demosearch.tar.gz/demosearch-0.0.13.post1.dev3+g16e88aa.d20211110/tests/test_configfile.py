import unittest
from demosearch.cache import ConfigFile, FileCache
from os import environ

cache_dir = '/Volumes/SSD_Extern/radius'
cache = FileCache(cache_dir)

class TestConfigFile(unittest.TestCase):
    """ """

    def test_basic(self):
        """ """

        environ['FOOBAR'] = '/envvar'

        cf = ConfigFile(cache=cache, path='/explicit_path', env_name='FOOBAR')

        print(cf._search_path)

        print(cf._find_config())

        print(cf._searched)

        with self.assertRaises(AttributeError):
            print(cf.config.foo)

if __name__ == '__main__':
    unittest.main()
