
locations = [
    "2409 Grand Canal, Venice, CA 90291",
    "553 Central Ave, Kansas City, KS 66101",
    "2249 Central Ave, Memphis, TN 38104",
    "7004 Charlotte Pike, Nashville, TN 37209",
    "2209 N Slappey Blvd Albany, GA 31701",
    "12233 Ranch Rd 620 N suite 105, Austin, TX 78750",
    "155 Mose Coleman Dr, Vidalia, GA 30474-8676",
    "116 Glenn Falls St, Peachland, NC 28133",
    "1120 S Lewis St, Metter, GA 30439",
    "2020 Demere Rd., St. Simons Island GA 31522 ",
]

import pandas as pd
from pathlib import Path


sbux_locations = pd.read_csv(Path(__file__).parent.joinpath('sbux-sample-addr.csv'))


