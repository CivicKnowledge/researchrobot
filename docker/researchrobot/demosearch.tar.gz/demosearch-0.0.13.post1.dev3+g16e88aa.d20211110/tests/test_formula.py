import unittest
import demosearch as ds

class TestFormulas(unittest.TestCase):
    """ """

    def test_basic(self):
        """ """
        from demosearch.formulae import FormulaVisitor
        import ast

        tree = ast.parse("a.footz/b.baz+norm(c)+unk(b)+unk(x)", mode="eval")

        env = {
            'names': ['a', 'b', 'c'],
            'attrs': ['footz'],
            'funcs': ['norm']
        }

        fv = FormulaVisitor(**env)

        fv.visit(tree)

        self.assertEqual({'a','b','c'}, fv.used_names)
        self.assertEqual( {'Unknown function call: unk',
                           'Unknown attribute name: baz',
                           'Unknown patch name: x'},
                         fv.errors)

    def test_split(self):
        x = ["""
        (primary+secondary+highway).convolve(2).color('Reds').label('Roads'),
        (construction_occupations+sales_occupations)/total_population,
        cafe,

        (cafe.unorm * total_population.unorm).convolve(10).label('Population, Adjusted Cafes'),
        cafe.convolve(10).color('jet').label('Cafe Density'),

        total_population
        """, 'foobar', 'baz', "cafe.convolve(10)"]

        rm = ds.ConfigFile.default().manager

        print(rm.process_layer_args(x))

    def test_methods(self):
        """ """
        from demosearch.formulae import FormulaVisitor
        import ast

        tree = ast.parse("a.foo()/b.bar()", mode="eval")

        env = {
            'names': ['a', 'b', 'c'],
            'attrs': ['footz'],
            'funcs': ['norm'],
            'methods': ['foo']
        }

        fv = FormulaVisitor(**env)

        fv.visit(tree)

        self.assertEqual({'a','b'}, fv.used_names)
        self.assertEqual( {'Unknown method call: bar'},
                         fv.errors)


    def test_parse(self):
        """ """

        from demosearch.formulae import parse_formula
        from demosearch.exceptions import FormulaError

        whitelist = {
            'names': ['a', 'b', 'c'],
            'attrs': ['footz'],
            'funcs': ['norm'],
            'methods': ['foo']
        }

        with self.assertRaises(FormulaError):
            names, code = parse_formula("a.foo()/b.bar()", whitelist)

        names, code = parse_formula("a.foo()/norm(b)", whitelist)

    def test_names(self):
        rm = ds.ConfigFile.default().manager
        p1 = rm.make_summary_patch("5616 176th E, Puyallup WA", "(cafe.unorm+(highway+primary).unorm).label('Foobar')")
        p2 = rm.make_summary_patch("5616 176th E, Puyallup WA", p1.name)
        assert p1.name == p2.name


if __name__ == '__main__':
    unittest.main()

