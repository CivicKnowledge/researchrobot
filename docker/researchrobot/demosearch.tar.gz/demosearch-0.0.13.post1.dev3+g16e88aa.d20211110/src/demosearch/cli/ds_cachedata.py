# -*- coding: utf-8 -*-
"""
Cache data for the radius search server
"""

import argparse
import logging
import sys
from os import environ
from pathlib import Path
from demosearch import ConfigFile
from demosearch.install import logger as install_logger
from demosearch.cache import FileCache
from demosearch.install import RasterInstaller
from demosearch.search import build_index
from demosearch import __version__
import rowgenerators as rg

from metapack.appurl import SearchUrl
SearchUrl.initialize() # So 'index:' urls work

__author__ = "Eric Busboom"
__copyright__ = "Eric Busboom"
__license__ = "mit"

_logger = logging.getLogger(__name__)
cli_logger = logging.getLogger('cli')
cli_logger.setLevel(logging.INFO)

try:
    default_cache =  ConfigFile.default().config.root #environ.get('DS_CACHE_DIR')
except AttributeError:
    default_cache = environ.get('DS_CACHE_DIR')


class CliError(Exception):
    """ """
    pass

def parse_args(args):
    """Parse command line parameters

    :param args: command line parameters as list of strings
    :type args: str]
    :returns: obj:`argparse.Namespace`: command line parameters namespace

    """
    parser = argparse.ArgumentParser(description=sys.modules[__name__].__doc__)

    parser.add_argument(
        "--version",
        action="version",
        version="demosearch {ver}".format(ver=__version__),
    )

    parser.add_argument(
        "-v",
        "--verbose",
        dest="loglevel",
        help="set loglevel to INFO",
        action="store_const",
        const=logging.INFO,
    )
    parser.add_argument(
        "-vv",
        "--very-verbose",
        dest="loglevel",
        help="set loglevel to DEBUG",
        action="store_const",
        const=logging.DEBUG,
    )

    parser.add_argument('--exceptions', help="Show full exceptions", action="store_true")

    parser.add_argument("-c", "--clean", help="Clean the whole cache before starting",
                        action='store_true')

    parser.add_argument("-D", "--delete", help="Delete the raster file before starting",
                        action='store_true')

    group = parser.add_mutually_exclusive_group()

    group.add_argument("-l", '--list', help='List contents of the raster', action='store_true')
    group.add_argument("-g", '--geo', help='Install a geographic file', action='store_true')
    group.add_argument("-d", '--data', help='Install a data file', action='store_true')
    group.add_argument("-i", '--index', help='Create the CBSA search index', action='store_true')
    group.add_argument("-q", '--percentile', help='Intsall the CBSA percentiles', action='store_true')

    parser.add_argument("-o", '--output_file', help='Path to output file. Default: raster.h5, in the cache',
                        nargs='?')

    parser.add_argument('-n','--name', help="Name of the dataset")
    parser.add_argument('-p','--primary-key', help="Define the primary key in the dataset, for linking data.")

    parser.add_argument('data_url', nargs='?')

    return parser.parse_args(args)

def setup_logging(loglevel):
    """Setup basic logging

    :param loglevel: minimum loglevel for emitting messages
    :type loglevel: int

    """
    logformat = "[%(asctime)s] %(levelname)s:%(name)s:%(message)s"
    logging.basicConfig(stream=sys.stdout, format=logformat, datefmt="%Y-%m-%d %H:%M:%S")

    if loglevel:

        install_logger.setLevel(loglevel)

def main(args):
    """Main entry point allowing external calls

    :param args: command line parameter list
    :type args: str]

    """

    config = ConfigFile.default()
    cache = config.cache

    setup_logging(args.loglevel)

    if args.clean:
        cache.clean()

    ri = RasterInstaller(config, output_file=args.output_file)

    if args.delete:
        ri.delete()

    if args.list:
        from demosearch import RasterManager
        rm = RasterManager(config, args.output_file)
        for l in rm.layers.keys():
            print(l)
        return
    elif args.geo:
        if not args.name:
            raise CliError(f"Must specify --name")
        if not args.data_url:
            raise CliError(f"Must specify data url")

        ri.rasterize(args.data_url, args.name, primary_key=args.primary_key)

    elif args.data:

        if not args.primary_key:
            raise CliError(f"Didn't get primary key. Did you mean --geo?")

        if not args.data_url:
            raise CliError(f"Must specify data url")
        df = rg.dataframe(args.data_url)
        ri.add_data(df, args.name, primary_key=args.primary_key)
    elif args.index:
        print('Creating search index. Downloading dataset may be slow ...')
        df = rg.geoframe(args.data_url)
        build_index(cache, df)
        ri.add_cbsa(df)

    elif args.percentile:
        df = rg.dataframe(args.data_url)
        ri.add_percentile(df)

    else:
        print("Cache      : ",cache.root)
        print("Raster file: ",str(ri.rp))


def intuit_dataset(url):
    """

    :param url: 

    """
    u = rg.parse_app_url(url)
    print(dir(u))
    print("!!!", u.target_file)

def run():
    """Entry point for console_scripts"""

    args = parse_args(sys.argv[1:])

    try:
        main(args)
    except Exception as e:
        if args.exceptions:
            raise
        else:
            sys.exit("ERROR: "+str(e))



if __name__ == "__main__":
    run()
