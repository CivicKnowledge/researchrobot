# -*- coding: utf-8 -*-
"""
Batch score locations
"""

import argparse
import logging
import sys
from os import environ
from pathlib import Path
from demosearch import ConfigFile
from demosearch.cache import FileCache
from demosearch.batch import batch_score, coalesce, logger as batch_logger, default_cache_key, list_score_files
import demosearch.batch as dsb # for the default_cache_key
from demosearch import __version__
import rowgenerators as rg


from metapack.appurl import SearchUrl
SearchUrl.initialize() # So 'index:' urls work

__author__ = "Eric Busboom"
__copyright__ = "Eric Busboom"
__license__ = "mit"

_logger = logging.getLogger(__name__)
cli_logger = logging.getLogger('cli')
cli_logger.setLevel(logging.INFO)


class CliError(Exception):
    """ """
    pass

def parse_args(args):
    """Parse command line parameters

    :param args: command line parameters as list of strings
    :type args: str]
    :returns: obj:`argparse.Namespace`: command line parameters namespace

    """
    parser = argparse.ArgumentParser(description=sys.modules[__name__].__doc__)

    parser.add_argument(
        "--version",
        action="version",
        version="demosearch {ver}".format(ver=__version__),
    )

    parser.add_argument(
        "-v",
        "--verbose",
        dest="loglevel",
        help="set loglevel to INFO",
        action="store_const",
        const=logging.INFO,
    )
    parser.add_argument(
        "-vv",
        "--very-verbose",
        dest="loglevel",
        help="set loglevel to DEBUG",
        action="store_const",
        const=logging.DEBUG,
    )

    parser.add_argument('--exceptions', help="Show full exceptions", action="store_true")

    parser.add_argument("-d", "--debug", help="Run multi-process tasks single process for debugging",
                        action='store_true')

    parser.add_argument("-c", "--clean", help="Clean the scoring portion of the cache before starting",
                        action='store_true')

    parser.add_argument("-r", '--raster', help='Path to the raster file, if it is not in the cache')

    parser.add_argument("-k", '--cache_key', help='Directory in the cache to use for intermediate files')

    parser.add_argument("-s", '--score', help='Run the batch scoring', action='store_true')

    parser.add_argument('-L', '--list', help="List all of the cached score files", action="store_true")

    parser.add_argument("-o", '--output', help='Read cached results and coalesce to a file')

    parser.add_argument("-i", '--ignore-errors', help='Ignore errors when coalescing', action="store_true")

    parser.add_argument('-l', '--layer', action='append', help='Name of a layer to score. Can be used multiple times')

    parser.add_argument('-f', '--layers', type=argparse.FileType('r'),
                        help='A file to load layer names from, one per line')

    parser.add_argument('data_url', nargs='?', help='Metapack URL to data package of points')

    return parser.parse_args(args)

def setup_logging(loglevel):
    """Setup basic logging

    :param loglevel: minimum loglevel for emitting messages
    :type loglevel: int

    """
    logformat = "[%(asctime)s] %(levelname)s:%(name)s:%(message)s"
    logging.basicConfig(stream=sys.stdout, format=logformat, datefmt="%Y-%m-%d %H:%M:%S")

    if loglevel:
        batch_logger.setLevel(loglevel)

def main(args):
    """Main entry point allowing external calls

    :param args: command line parameter list
    :type args: str]

    """

    import warnings

    if not sys.warnoptions:
        warnings.simplefilter("ignore")

    setup_logging(args.loglevel)

    config = ConfigFile.default()
    cache = config.cache

    layers = args.layer if args.layer else []

    if args.layers:
        layers.extend([ e.strip() for e in args.layers.readlines()])

    if args.clean:
        ck = args.cache_key if args.cache_key else default_cache_key

        cli_logger.info(f"Deleting cache section {ck}")

        cache.delete(ck)


    if args.list:

        score_files = list_score_files(config, args.cache_key)

        for f in score_files:
            print(f)

        return

    if args.data_url is None:
        raise argparse.ArgumentError(args.data_url, 'Must specify data url')

    cli_logger.info(f"Running with cache={cache.root} cache_key={args.cache_key} data={args.data_url}")

    if args.score:

        if len(layers) == 0:
            raise Exception("Must specify layers with -l or -L")

        cli_logger.info(f"Loading point data file {args.data_url}")
        df = rg.geoframe(args.data_url)

        r = batch_score(config, args.cache_key, df, layers, args.raster, debug=args.debug)
        cli_logger.info(f"Completed scoring with {len(r)} score files")

    if args.output:

        cli_logger.info(f"Loading point data file {args.data_url}")
        df = rg.dataframe(args.data_url)

        df = coalesce(config, args.cache_key, df, ignore_errors=args.ignore_errors)
        if df is not None:
            df.to_csv(args.output, index=False)
            cli_logger.info(f"Wrote data to '{args.output}' ")
        else:
            cli_logger.info("No data written; did not get scoring data")



def run():
    """Entry point for console_scripts"""

    args = parse_args(sys.argv[1:])

    try:
        main(args)
    except Exception as e:
        if args.exceptions:
            raise
        else:
            sys.exit("ERROR: "+str(e))



if __name__ == "__main__":
    run()
