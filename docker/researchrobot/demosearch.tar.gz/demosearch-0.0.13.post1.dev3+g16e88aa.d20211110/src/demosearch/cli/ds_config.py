# -*- coding: utf-8 -*-
"""
Print configuration information
"""

import argparse
import logging
import sys
from os import environ

from demosearch import ConfigFile, RasterManager, __version__



__author__ = "Eric Busboom"
__copyright__ = "Eric Busboom"

_logger = logging.getLogger(__name__)
cli_logger = logging.getLogger('cli')
cli_logger.setLevel(logging.INFO)


class CliError(Exception):
    """ """
    pass

def parse_args(args):
    """Print Demosearch configuration

    :param args: command line parameters as list of strings
    :type args: str]
    :returns: obj:`argparse.Namespace`: command line parameters namespace

    """
    parser = argparse.ArgumentParser(description=sys.modules[__name__].__doc__)

    parser.add_argument('--exceptions', help="Show full exceptions", action="store_true")

    group = parser.add_mutually_exclusive_group(required=True)

    group.add_argument("-c", "--cache", action='store_true', help=f'Print the path to the cache')

    group.add_argument("-f", "--config", action='store_true', help=f'Print the path to the config file')

    group.add_argument("-r", '--raster', action='store_true', help='Print the path to the raster')

    group.add_argument("-v", '--version', action='store_true', help='Print the path to the raster')

    return parser.parse_args(args)

def main(args):
    """Main entry point allowing external calls

    :param args: command line parameter list
    :type args: str]

    """

    config = ConfigFile.default()

    if args.raster:
        rm = RasterManager(config)
        print (str(rm.rp))
    elif args.cache:
        print(config.cache.root)
    elif args.config:
        print(config.config_path)
    elif args.version:
        print(__version__)




def run():
    """Entry point for console_scripts"""

    args = parse_args(sys.argv[1:])

    try:
        main(args)
    except Exception as e:
        if args.exceptions:
            raise
        sys.exit("ERROR: "+str(e))



if __name__ == "__main__":
    run()
