from dataclasses import dataclass, replace
from functools import reduce
from operator import xor
from typing import Any, Union

import geopandas as gpd
import pandas as pd
import numpy as np
from demosearch.constants import DEFAULT_RESOLUTION, SUMMARY_ADDRESS
from demosearch.exceptions import KernelSizeError, DataNotFound, PatchError
from demosearch.geo import Location, Bbox
from demosearch.kernel import *

from demosearch.plot import write_plot_to_buffer, add_rings
from demosearch.util import replace_with_dict, raster_transform, nn, infnan
from matplotlib import cm
from matplotlib.colors import Colormap

import address_parser

address_parser = address_parser.Parser()

def _convert_other(other):
    """For Patch math function overrides, convert the other
    from a patch to a raster

    :param other:

    """

    try:
        other = nn(other.raster)
    except AttributeError:
        pass

    return other


marker_colors = "blue green red cyan magenta black purple darkblue olive plum slategrey royalblue".split()


@dataclass
class MarkerPoint(object):
    """Markers to draw on a patch map"""

    location: Any  # Whatever the user entered for a location
    label: int
    color: str = 'green'
    ua: "UserArgs" = None

    utm: tuple = None
    ll: tuple = None
    geohash: str = None

    def __reduce__(self):
        # we return a tuple of class_name to call,
        # and optional parameters to pass when re-creating
        return (self.__class__, (self.utm, self.label, self.color))

    def __post_init__(self):
        from .raster import UserArgs

        if isinstance(self.location, Location):
            self.utm = list(self.location.utm)
            self.ll = list(self.location.ll)

        elif isinstance(self.location, UserArgs):
            raise NotImplementedError()

        elif isinstance(self.location, Bbox):
            self.utm = list(self.location.utm.center)
            self.ll = list(self.location.ll.center)
            raise NotImplementedError()

        elif isinstance(self.location, MarkerPoint):
            self.label = self.location.label
            self.color = self.location.color
            raise NotImplementedError()

        elif isinstance(self.location, (tuple, list)):
            self.utm = self.location
            raise NotImplementedError()

    def patch_location(self, patch):
        """Return a tuple that can index the raster to the location of this marker"""

        pixloc = ((np.array(list(self.location)) - np.array(list(patch.bbox.utm.min_pt))) // 100).round(0).astype(int)

        return tuple(pixloc[::-1])

    def value(self, patch):
        """Return the value of the raster at the marker location"""

        return patch.raster[self.patch_location(patch)]

    def percentile(self, patch):
        """Compute the percentile (quantile) of the value at the marker point
        relative to the rest of the patch"""

        s = patch.series.sort_values()
        idx = (s - self.value(patch)).abs().argmin()

        return idx / len(s)



@dataclass
class Patch(object):
    """A rectangular subset of a zone raster, with styling information"""
    name: str  # name of layer, or encoded formula
    ri: "RasterInfo"
    loc: Location
    bbox: Bbox
    raster: Any
    kernel_f: Any = k_log

    layer_index: Union[int, None] = None  # For single layer rasters, the layer of the zone's raster
    size: int = 0  # Convolution size for plotting
    alphaq: float = None  # Quantile below which is transparent
    opacity: float = .7  # Opacity on parts that aren't completely transparent
    colormap: Colormap = cm.viridis  # Colormap to use for plotting
    basemap_name: str = 'Stamen.Toner'
    _raster_replaced: bool = False

    _cbsa: str = None  # CBSA Record

    layer_type: str = 'l'  # l for layer, f for function
    location_info: "UserArgs" = None  # User input for location
    layer_name: str = None  # Name of the layer, if different from name. May be a layer or a function
    _label: str = None  # Label set by label() function
    address: str = None  # name of location
    units: str = None  # Units, for display
    prefix: str = None  # score_val prefix, for display

    # List of display points. List of Locations, converted to MarkerDisplay after show()
    # or convert_markers.
    markers: Any = None

    def __hash__(self):

        hashes = [hash(getattr(self, n)) for n in
                  ['name', 'ri', 'loc', 'bbox', 'layer_index', 'size', 'alphaq', 'opacity', 'colormap',
                   'basemap_name']]

        return reduce(xor, hashes)

    def __post_init__(self):

        assert len(list(self.bbox)) == 4

        if self._raster_replaced is False:
            if self.ri.geom_type == 'table':
                # This raster has ID numbers that are linked to a table,
                # as wth a census table, which has tract ids in the raster. These tract ids
                # need to be linked to tract values.
                data = self.ri.manager.get_data(self.ri.key, self.ri.band, area_norm=True)
                data_dict = data.set_index(self.ri.primary_key)[self.ri.layer].to_dict()
                self._raw_raster = self.raster
                self.raster = replace_with_dict(self.raster, data_dict)
            else:
                self._raw_raster = None

            self._raster_replaced = True

        if self.layer_name is None:
            self.layer_name = self.name

        if self.title is None:
            self.title = self.layer_name

        if self.location_info is not None:
            self.address = self.location_info.spec

        self.kernel_f = k_log

    @property
    def key(self):
        return (self.name, self.geohash)

    @property
    def is_summary(self):
        return self.markers is not None and self.address == SUMMARY_ADDRESS

    def update(self, **kwargs):
        """

        :param **kwargs:

        """
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, k, v)

        return self

    def replace(self, **kwargs):

        return replace(self, **kwargs)

    # def set_location_info(self, location_name):
    #    return self.replace(location_info=self.ri.manager.ua_from_ll(self.loc, location_name=location_name))


    @property
    def kernel(self):
        return self.kernel_f() + 1


    @property
    def nanless_raster(self):
        """ """
        return np.nan_to_num(self.raster)

    @property
    def min(self):
        """Raster minimum"""
        return np.nanmin(self.raster).round(6)

    @property
    def max(self):
        """ """
        return np.nanmax(self.raster).round(6)


    @property
    def rkernel(self):
        """Return a new patch with the  kernel as the raster


        :returns: rtype:

        """

        return self.replace(raster=self.kernel, name=self.name + '_kernel')

    @property
    def unique(self):
        """ Return a numpy array of unique raster values, excluding nan"""

        a = np.unique(self.raster)
        return a[~np.isnan(a)]

    @property
    def epsg(self):
        """ """
        return self.ri.epsg

    @property
    def folium_bounds(self):
        """Bounds for the raster in a form that is suitable for
        a Folium ImageOverlay. Assumes the internal position is a bounding box


        """

        # Maybe re-create the xc and yc using linspace and the bounding box?
        raise NotImplementedError()

        y_slice, x_slice = self.bbox.pix.slice

        return list(
            self.rz.utm(self.rz.xc[x_slice][0] - DEFAULT_RESOLUTION, self.rz.yc[y_slice][0] - DEFAULT_RESOLUTION).ll), \
               list(self.rz.utm(self.rz.xc[x_slice][-1] - DEFAULT_RESOLUTION,
                                self.rz.yc[y_slice][-1] - DEFAULT_RESOLUTION).ll)

    @property
    def pyplot_bounds(self):
        """ """

        return [self.bbox.utm.x_min, self.bbox.utm.x_max,
                self.bbox.utm.y_min, self.bbox.utm.y_max]

    @property
    def cbsa(self):
        if not self._cbsa:
            self._cbsa = self.ri.manager.find_cbsa(self.loc)

        return self._cbsa

    def transform(self):
        """ """

        return raster_transform(*self.bbox, self.ri.resolution)


    def mult(self, kernel):
        """Multiply the raster by a kernel, centering the kerne on the raster"""

        from .kernel import align_to_kernel

        kernel = kernel() if callable(kernel) else kernel

        return self.replace(raster=align_to_kernel(self.raster, kernel)*kernel)

    def score(self, kernel= None):

        kernel = DEFAULT_KERNEL if kernel is None else kernel

        kernel = kernel() if callable(kernel) else kernel

        return np.nansum(self.mult(kernel).raster)

    def percentile(self, kernel= None):
        """Return the percentile ( actually quantile ) of the value ( center point )
        compared to the area of the patch """

        if kernel is not None:
            t = self.convolve(kernel)
        else:
            t = self

        s = t.series.sort_values()
        idx = (s - t.value).abs().argmin()

        return idx / len(s)


    def process_for_display(self):

        from .plot import scale10

        img_scaled = scale10(self.raster)
        img_cm = self.colormap(img_scaled)

        if self.alphaq is not None:
            q = np.nanquantile(img_scaled, self.alphaq)
            mask = (img_scaled > q).astype(int)
            img_cm[:, :, 3] = mask

        else:
            img_cm[:, :, 3] = 1

        if self.opacity is not None:
            img_cm[:, :, 3] = np.where(img_cm[:, :, 3] == 0, 0, self.opacity)

        # Make nans completely opaque
        img_cm[:, :, 3] = np.where(np.isnan(self.raster), 0, img_cm[:, :, 3])

        return img_cm

    def show(self, ax=None, return_buffer=False, show_rings=False,
             return_raster=False, legend=False):
        """

        :param ax: Default value = None)
        :param process: Default value = None)
        :param basemap: Default value = True)
        :param return_buffer: Default value = False)

        """
        import matplotlib.pyplot as plt
        from .plot import add_basemap

        from .util import signif

        t = self.process_for_display()

        if return_raster:
            return t

        if ax is None:
            fig, ax = plt.subplots(1, figsize=(10, 10))

        if self.basemap_name:
            add_basemap(ax, self.bbox, map_name=self.basemap_name)

        ax.margins(0)
        ax.set_axis_off()

        if self.markers:
            for mkr in self.markers:
                ax.text(*mkr.utm, mkr.label, fontsize=10, color='white', weight='bold',
                        bbox=dict(facecolor=mkr.color, edgecolor=mkr.color, boxstyle='round'))

                if show_rings:  # Add rings for each marker
                    add_rings(ax, mkr.location, add_text=False, color=mkr.color)

        elif show_rings:  # Add rings to the whole patch
            add_rings(ax, self, add_text=True)

        if not self.markers:
            x, y = list(self.loc.utm.center)
            cc = plt.Circle((x, y), 100, color='red', linewidth=0.5, fill=True)
            ax.add_artist(cc)

        im = ax.imshow(t, origin='lower', extent=self.pyplot_bounds)

        if legend is True:
            from mpl_toolkits.axes_grid1 import make_axes_locatable
            divider = make_axes_locatable(ax)
            cax = divider.append_axes("bottom", size="5%", pad=0.05)

            rnd = lambda x: signif(x, 3)

            mid_t = (np.nanmin(t) + np.nanmax(t)) / 2
            mid_r = (self.min + self.max) / 2

            cb = plt.colorbar(im, cax=cax, orientation='horizontal', ticks=[np.nanmin(t), mid_t, np.nanmax(t)])
            cb.ax.set_xticklabels([rnd(e) for e in [self.min, mid_r, self.max]])

            ax.set_title(self.title, fontsize=16)

        if return_buffer:
            return write_plot_to_buffer(ax)
        else:
            return ax

    def set_markers(self, points=None):
        """Convert a list of Locations in self.points or the argument to
        a list of MarkerPoint

        :param points:  A list of points, as Locations, Bbox or tuples, in UTM for the
            band of the patch (Default value = None)

        """

        from itertools import cycle

        if points is None:
            points = self.markers

        if not points or len(points) == 0:
            return None

        self.markers = [MarkerPoint(p, i, color, geohash=p.center.to_geohash())
                        for i, (p, color) in enumerate(zip(points, cycle(marker_colors)), 1)]

        return self.markers

    @property
    def nonan(self):
        """ """
        return self.replace(raster=np.nan_to_num(self.raster))

    def convolve(self, kernel):
        """Return a new patch with a convolved raster.

        """
        import cv2

        kernel = kernel() if callable(kernel) else kernel

        kern = np.nan_to_num(kernel.astype(float), 0)

        convolved_rast = cv2.filter2D(np.nan_to_num(self.raster), -1, kern)

        return self.replace(raster=convolved_rast)

    def color(self, colormap=None):
        """

        :param colormap: type colormap: (Default value = cm.viridis)
        :returns: rtype:

        """

        if colormap is None:
            return self

        import matplotlib.pyplot as plt

        if isinstance(colormap, str):
            colormap = plt.get_cmap(colormap)

        return self.replace(colormap=colormap)

    def map(self, basemap_name=None):
        """Set the contextily map name

        :param basemap_name:

        """
        if basemap_name is not None:
            return self.replace(basemap_name=basemap_name)
        else:
            return self

    def label(self, label):
        """Change the name of the layer

        :param name:

        """
        return self.replace(_label=label)

    @property
    def unorm(self):
        """Normalize raster to [0,1]


        :returns: A new patch, with a normalize raster

        :rtype: Patch

        """

        mx = np.nanmax(self.raster)
        mn = np.nanmin(self.raster)

        return self.replace(raster=(self.raster - mn) / (mx - mn))

    @property
    def zscore(self):
        """Standardize raster to z-score


        :returns: rtype:

        """

        return self.replace(raster=(self.raster - np.nanmean(self.raster)) / np.nanstd(self.raster))

    @property
    def qscale(self):
        """Quantize raster to -1, 0 or 1


        :returns: A new patch, with a normalize raster

        :rtype: Patch

        """

        r = np.copy(self.raster)

        r[r > 0] = 1
        r[r < 0] = -1

        return self.replace(raster=r)

    @property
    def binarize(self):
        """Binarize raster to 0 or 1

        :returns: A new patch, with a normalize raster

        :rtype: Patch

        """

        r = np.copy(self.raster)

        # use a small cutoff threshold, because convolution can give the whole
        # array a small non-negative value
        min_val = np.nanmax(r) * 1e-8

        r[r > min_val] = 1
        r[r <= min_val] = 0

        return self.replace(raster=r)

    @property
    def robust_scale(self):
        """Scale the raster using SKLearns RobustScaler"""
        from sklearn.preprocessing import RobustScaler

        return self.replace(raster=RobustScaler().fit(self.ravel2d) \
                            .transform(self.ravel2d).ravel().reshape(self.raster.shape))

    @property
    def qtransform(self):
        """Transform the raster to quantile values, with 10 levels. """

        from sklearn.preprocessing import quantile_transform

        r = quantile_transform(self.ravel2d, n_quantiles=10, random_state=0, copy=True) \
            .ravel().reshape(self.raster.shape)

        return self.replace(raster=r)

    @property
    def ptransform(self):
        """Transform the raster to quantile values, with 100 levels. """

        from sklearn.preprocessing import quantile_transform

        r = quantile_transform(self.ravel2d, n_quantiles=100, random_state=0, copy=True) \
            .ravel().reshape(self.raster.shape)

        return self.replace(raster=r)

    def nband(self, mu=50, std=10):
        """ Quantile band using a normal distribution range of quantiles.

        :param mu:
        :type mu:
        :param std:
        :type std:
        :return:
        :rtype:

        Return the raster scaled by a normal distribution on the percentile
        bins of the original raster.

        For instance, for mu=50, std=10, the routine creates a normal distribution
        centered on the 50th percentile, with a standard deviation of 10 percentiles.
        The scale the raster using this distribution, adjusting each cell of the raster
        according to the percentile value of the cell. The result is a new raster that
        strongly emphasizes the parts of the original raster that are at or near the
        50th percentile, and ( almost ) zeroing out cells that are far away from
        the 50th percentile.
        """

        from scipy.stats import norm

        # Compute the quantile breaks for the raster
        bins = np.quantile(self.raster, np.arange(0, 1, 0.01))

        # Create a normal distribution of weights for each of the quantiles.
        d = norm.pdf(np.arange(0, 100), mu, std)

        # Bin the raster values. The result is the shape of the original raster,
        # where each cell has a number from 1 to 100 that references the bin
        # that holds the original value of that cell. Because there are 100 bins,
        # this is also the percentile of that value.
        r_bin = np.digitize(self.raster, bins) - 1

        # Use the bin numbers to look up the value of the normal distribution
        r_band = d[r_bin]

        return self.replace(raster=r_band)

    def pband(self, low=0, high=100):
        """ Percentile band using a lower and upper bound. Returns values from the
        raster that have percentile values between the lower and upper bounds, and
        NaN otherwise

        :param low:
        :type low:
        :param high:
        :type high:
        :return:
        :rtype:
        """

        def _pband(raster, low, high):

            # Compute the quantile breaks for the raster
            bins = np.nanquantile(raster, np.arange(0, 1, 0.01))

            # Bin the raster values. The result is the shape of the original raster,
            # where each cell has a number from 1 to 100 that references the bin
            # that holds the original value of that cell. Because there are 100 bins,
            # this is also the percentile of that value.
            r_bin = np.digitize(raster, bins) - 1

            return self.replace(raster=np.where((r_bin >= low) & (r_bin < high), raster, np.nan))

        try:
            return _pband(self.raster, low, high)
        except ValueError:
            # Usually because there are fewer unique values than bins ( 100 )
            # so by adding a small error we can increase the number of bins.
            raster = self.randerr(self.max / 1000).raster
            return _pband(raster, low, high)

    @property
    def abs(self):
        """Return a patch with the absolute valued raster

        :returns: A new patch, with a normalize raster

        :rtype: Patch

        """

        return self.replace(raster=np.abs(self.raster))

    def randerr(self, eps=.001):
        """ Add a random uniform error to the raster
        :param eps: Absolute value of error to be added to the raster. Actual
        values are in range -eps to +eps
        :type eps: number
        :return:
        :rtype:
        """

        r = np.random.uniform(low=-eps, high=eps, size=self.raster.shape)

        return self.replace(raster=self.raster + r)

    @property
    def ln(self):
        """Return the natural log of the raster values as a new patch"""
        return self.replace(raster=np.log(self.raster))

    @property
    def int(self):
        return self.replace(raster=self.raster.astype(int))

    def epz(self, eps):
        """Epsilon to zero: Set values a small distance away from zero to be zero."""

        r = np.copy(self.raster)

        r[np.abs(r) < eps] = 0

        return self.replace(raster=r)

    def epq(self, eps_q):
        """Epsilon to zero by quantiles. Like epz, but the argument is a quantile"""

        eps = self.series.quantile(float(eps_q))

        r = np.copy(self.raster)

        r[np.abs(r) < eps] = 0

        return self.replace(raster=r)

    def clip(self, a_min, a_max=None):
        """Clip the raster values to a min and max"""
        return self.replace(raster=np.clip(self.raster, a_min, a_max))

    def qclip(self, q_min, q_max=None, shift=False):
        """Clip the raster values to a min and max, specified by a quantile values. """

        a_min = self.series.quantile(float(q_min))
        if q_max:
            a_max = self.series.quantile(float(q_max))
        else:
            a_max = None

        r = np.clip(self.raster, a_min, a_max)

        if shift:
            r = r - np.nanmin(r)

        return self.replace(raster=r)

    @property
    def znan(self):
        """Convert zero to nan"""

        r = np.where((~np.isnan(self.raster)) & (self.raster != 0), self.raster, np.nan)

        return self.replace(raster=r)

    @property
    def nanz(self):
        """Convert nan to 0"""

        return self.replace(raster=np.nan_to_num(self.raster))

    def round(self, v):

        return self.replace(raster=np.round(self.raster, v))

    @property
    def ones(self):
        return self.replace(raster=np.ones_like(self.raster))

    @property
    def zeros(self):
        return self.replace(raster=np.zeros_like(self.raster))

    def clip_to(self, other):
        from .kernel import clip_to_kernel

        r = clip_to_kernel(self.raster, other)

        # Re-calc the bounding box
        s = (r.shape[0] - 1) / 2
        new_bb = self.bbox.pix.center.patch(s)

        return self.replace(raster=r, bbox=new_bb)

    @property
    def kclip(self):
        """Clip a large size raster to the same size as the kernel"""

        return self.clip_to(self.kernel)

    @property
    def center_mean(self):
        """Return a new patch after subtracting the raster mean from the  raster"""
        return self.replace(raster=self.raster - np.nanmean(self.raster))

    @property
    def center_median(self):
        """Return a new patch after subtracting the raster median from the raster"""
        return self.replace(raster=self.raster - np.nanmedian(self.raster))

    def apply(self, f):
        """Return a new patch after applying a function to the raster"""
        return self.replace(raster=f(self.raster))

    @property
    def ident(self):
        """returns self, but has the effect of forcing a layer name ot be interpreted as a formula"""

        return self

    def alpha(self, alphaq=None):
        """Set the quantile value below which the layer is always completely transparent

        :param alphaq: Default value = None)

        """
        if alphaq is not None:
            return self.replace(alphaq=alphaq)
        else:
            return self

    def transparency(self, opacity=None):
        """

        :param opacity: Default value = None)

        """
        if opacity is not None:
            return self.replace(opacity=opacity)
        else:
            return self

    @property
    def title(self):
        """Return the label or layer name depending on what is set"""
        from .formulae import is_encoded_formula, decode_formula
        t = self._label or self.layer_name or self.name

        # Mostly should not be an encoded formula, becuase the layer_name
        # should be set to the decoded formula
        return decode_formula(t) if is_encoded_formula(t) else t

    def plot_title(self, length=50):
        """Return the layer and the address in a nice format for plots"""
        from .util import truncate_elip

        return truncate_elip(self.title.title().replace('_', ' '), length) + '\n' +\
               truncate_elip(self.address,length).title()

    @property
    def parsed_address(self):
        return address_parser.parse(self.address)

    @property
    def geohash(self):
        from .geo import prefix_geohash
        return prefix_geohash(self.loc.ll.to_geohash())

    def hist(self, *args, **kwargs):
        """

        :param *args:
        :param **kwargs:

        """
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.hist(np.ravel(self.raster), *args, **kwargs)

    def to_points(self, x, y=None):
        """Convert a list of x,y points to Shapely Point geometries, in Lat/Lon

        :param x: param y:  (Default value = None)
        :param y:  (Default value = None)

        """

        if y is None:
            xy = x
        else:
            xy = zip(x, y)

        return gpd.GeoSeries([self.bbox.pix.to_zone(*r[::-1]).ll.point for r in xy], crs=4326)

    def peaks(self, threshold=0.1, as_frame=True):
        """

        :param threshold: Default value = 0.1)

        """
        from .plot import find_peaks, to_float32

        peak_locations = np.round(find_peaks(to_float32(self.raster), threshold=threshold), 0).astype(int)

        peak_values = self.raster[tuple(peak_locations.T)]

        if as_frame is False:
            return peak_locations
        else:
            return gpd.GeoDataFrame({
                'values': peak_values,
                'geometry': self.to_points(peak_locations)
            }, crs=4326).sort_values('values', ascending=False)

    @property
    def pix_center(self):
        return tuple(np.array(self.raster.shape) // 2)

    @property
    def pix_origin(self):
        """Pixel coordinates ( of band raster ) that is 0,0 for
        this patch"""

        kx, ky = self.pix_center

        rx, ry = list(self.loc.center.pix)

        return (rx - kx, ry - ky)

    def kernel_coords(self, loc):
        """Return the coordinates in the kernel of a location"""
        from operator import sub

        return tuple(map(sub, list(loc.center.pix), self.pix_origin))

    @property
    def value(self):
        """Return the value at the center of the patch"""

        return self.raster[self.pix_center]

    @property
    def values(self):
        """Return a data frame of values the markers"""
        return [self.value_at(marker.location) for marker in self.markers]

        # Could also be:
        # [ m.value(p) for m, p  in zip(ps.summary_patch.markers, ps.non_summary_patches)]

    def value_at(self, loc):

        xy = self.kernel_coords(loc)[::-1]

        return self.raster[xy]

    @property
    def series(self):
        """Return the raster, raveled to a Pandas Series, or to a dataframe, if
        the raster is color or has an alpha channel


        :returns: rtype:

        """

        if self.raster.ndim == 3:  # Full color, maybe with an alpha chanel
            if self.raster.shape[-1] == 3:
                raise NotImplementedError()
            elif self.raster.shape[-1] == 4:
                return pd.DataFrame(self.raster.reshape((-1, self.raster.shape[-1])),
                                    columns=[self.name + '_' + e for e in 'ch1 ch2 ch3 alpha'.split()])
            else:
                assert False
        else:
            return pd.Series(np.ravel(self.raster), name=self.name)

    @property
    def dataframe(self):
        return self.series.to_frame(self.name)

    @property
    def ravel(self):
        """
        :return:
        :rtype:
        """

        return np.ravel(self.raster)

    @property
    def ravel2d(self):
        """
        :return:
        :rtype:
        """

        return np.ravel(self.raster).reshape(-1, 1)

    def to_file(self, path=None):
        """Save the entire band as a raster image

        :param path: Default value = None)

        """
        import rasterio
        from rasterio.crs import CRS

        transform = raster_transform(*self.bbox.utm, self.ri.resolution)

        profile = {
            'driver': 'GTiff',
            'dtype': 'uint32',
            'nodata': 0,
            'width': self.raster.shape[1],
            'height': self.raster.shape[0],
            'count': 1,
            'crs': CRS.from_epsg(self.epsg),
            'transform': transform,
            'tiled': False,
            'interleave': 'pixel'
        }

        with rasterio.open(path, 'w', **profile) as dst:
            dst.write(self.raster.astype(np.uint32), 1)

    def _repr_pretty_(self, p, cycle):

        if cycle:
            from .exceptions import RasterException
            raise RasterException('Cycle in pretty printing, which should never happen')

        self.show(legend=True)

    def __neg__(self):
        return replace(self, raster=-self.raster)

    def __add__(self, other):
        other = _convert_other(other)
        return replace(self, raster=np.add(nn(self.raster), other))

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):

        other = _convert_other(other)

        return replace(self, raster=np.subtract(nn(self.raster), other))

    def __rsub__(self, other):

        other = _convert_other(other)

        return replace(self, raster=np.subtract(other, nn(self.raster)))

    def __mul__(self, other):
        other = _convert_other(other)
        try:
            return replace(self, raster=np.multiply(nn(self.raster), other))
        except ValueError as e:
            from demosearch.exceptions import RasterException
            raise RasterException("Can't multiply rasters of different shapes "
                                  f" ( {self.raster.shape} and {other.shape} ). Try reducing patch size. ")

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):

        other = _convert_other(other)

        if isinstance(other, np.ndarray):  # Avoid div by zero warnings
            other[other == 0] = np.nan

        return replace(self, raster=infnan(np.divide(nn(self.raster), other)))

    def __rtruediv__(self, other):

        return replace(self, raster=infnan(np.divide(other, self.raster)))

    def __floordiv__(self, other):

        other = _convert_other(other)
        return replace(self, raster=np.floor_divide(nn(self.raster), other))

    def __rfloordiv____(self, other):
        return self.__floordiv__(other)

    def gt(self, v):
        """Return a raster of 1 or 0 indicating if the cell is greater than the value"""

        return self.replace(raster=(self.raster > v) * self.raster)

    def __gt__(self, other):
        return self.gt(other)

    def gte(self, v):
        """Return a raster of 1 or 0 indicating if the cell is greater than or equal tothe value"""

        return self.replace(raster=(self.raster >= v) * self.raster)

    def __ge__(self, other):
        return self.gte(other)

    def lt(self, v):
        """Return a raster of 1 or 0 indicating if the cell is less than the value"""

        return self.replace(raster=(self.raster < v) * self.raster)

    def __lt__(self, other):
        return self.lt(other)

    def lte(self, v):
        """Return a raster of 1 or 0 indicating if the cell is less than or equal to the value"""

        return self.replace(raster=(self.raster <= v) * self.raster)

    def __le__(self, other):
        return self.lte(other)

    def __eq__(self, other):
        # Not really implemented

        if isinstance(other, Patch):
            # This gets called in Patches.score() for an unknown reason, and
            # causes errors, so returning simplest possible impl to stop the error
            return id(self) == id(other)

            # raise NotImplementedError(f"{self.name}, {self.address}")
        elif isinstance(other, (int, float)):
            return self.replace(raster=(self.raster == other).astype(int))
        else:
            return NotImplemented

    def __and__(self, other):

        if not isinstance(other, Patch):
            return NotImplemented
        else:
            return self.replace(raster= (self.raster.astype(bool) & other.raster.astype(bool)).astype(int) )




def ps_grouper(x, kf):
    """Group by a key function"""
    from itertools import groupby
    return [(k, list(v)) for k, v in groupby(sorted(x, key=kf), kf)]


class PatchesCollection(dict):
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)

    def __getitem__(self, item):
        """Allow accessing the groups by integer index"""
        return list(self.values())[item]

    def _repr_html_(self):

        rows = []

        def _row_wrap(r):
            return "<tr>" + ''.join([f"<td>{e}</td>" for e in r]) + "</tr>"

        i = 0
        for k, v in self.items():
            j = 0

            if v.summary_patch is not None:
                markers = v.summary_patch.markers + [None]
            else:
                markers = [None] * len(v.items)

            for (n, p), m in zip(v.items(), markers):

                if m is not None:

                    label = f'<span style="background-color:{m.color};color:white; padding: 2px;">{m.label}</span>'
                else:
                    label = ''

                rows.append(_row_wrap([i, j, k[1], p.layer_name, p.address, label]))
                j += 1
            i += 1

        return "<h2>Patches Collection</h2>" + \
               "<table>" + \
               "<tr><th>Group</th><th>Patch</th><th>CBSA</th><th>Layer</th><th>Address</th>" + "<th>Label</th>" + \
               ''.join(rows) + \
               "</table>"

    def _repr_pretty_(self, p, cycle):
        if cycle:
            print("Why are we cycling?")
        else:
            return None  # Let the _repr_html_ get it.


class Patches(object):
    """ """

    def __init__(self, patch_list, add_summary=False, group_name=None):
        self.patches = patch_list
        self.group_name = None

        if add_summary is True:
            self.patches.append(self.make_summary_patch())

    def __getitem__(self, key):

        if isinstance(key, int):
            return self.patches[key]

        for v in self.patches:
            if key == v.key:
                return v

        raise KeyError(f"Key '{key}' not found in patches. " +
                       f"Has '{'; '.join(e.ri.key for e in self.patches)}' ")

    @property
    def loc(self):
        """ """
        return list(self.values())[0].loc

    @property
    def has_summary_patch(self):
        """Return the summary patch, if one exists"""
        for p in self.patches:
            if p.is_summary:
                return True


        return False

    @property
    def summary_patch(self):
        """Return the summary patch, if one exists"""
        for p in self.patches:
            if p.is_summary:
                return p

        # No summary, need to make one
        return self.make_summary_patch()


    @property
    def summary_values(self):

        return [p.value for p in self.non_summary_patches]

    def _summarize(self):
        """Return the combined bbox for all of the patches in the set.

        This operation only make sense for a patch set in which the patches have the same layer and band
        """
        # Expand the bb so points aren't right on the edge.
        from .geo import LatLonBbox

        bands = set()
        layers = set()
        ris = set()

        all_patches = [p for p in self.patches if not p.is_summary]

        for p in all_patches:
            bands.add(p.ri.band)
            layers.add(p.name)
            ris.add(id(p.ri))

        assert len(bands) == 1, f"Summary operation requires patch set have only one band. Got {len(bands)}, {bands}"
        assert len(
            layers) == 1, f"Summary operation requires patch set have only one layer. Got {len(layers)}, {layers}"
        assert len(ris) == 1, f"Summary operation requires patch set have only one raster_info. Got {len(ris)}"

        # If above two conditions are true, then every

        locations = [p.loc.utm for p in all_patches]
        bbox = LatLonBbox.from_positions(all_patches[0].ri, locations).utm.square().expand(10_000)

        return bbox, locations, list(layers)[0], list(bands)[0], all_patches[0].ri

    def make_summary_patch(self):
        """Create a single patch that includes the locations of all of the internal patches.
        The patch will be created anew from the layer, and will not include any processing done on
        the underlying patches. """

        bbox, locations, layer, band, ri = self._summarize()

        p = ri.manager.patch(bbox, layer)

        p.set_markers(locations)
        p.address = SUMMARY_ADDRESS

        return p

    def __iter__(self):
        for v in self.patches:
            yield v.key

    def __len__(self):
        return len(self.patches)

    def keys(self):
        """ """
        return [p.key for p in self.patches]

    def values(self):
        """ """
        return self.patches

    def items(self):
        """ """
        return [(v.key, v) for v in self.patches]

    def __getitem__(self, item):
        return self.patches[item]

    @property
    def non_summary_patches(self):
        return [p for p in self.patches if not p.is_summary]

    def score(self, kernel=None, return_dataframe=True):
        """

        """
        from .kernel import DEFAULT_KERNEL

        kernel = DEFAULT_KERNEL if kernel is None else kernel

        try:
            kernel_name = kernel.__name__
        except AttributeError:
            kernel_name = 'unknown'

        scores = []
        for i, (k, p) in enumerate(self.items()):

            if p.is_summary:
                continue

            try:

                row = {
                    'idx': i,
                    'marker': i+1,
                    'name': p.name,
                    'location': p.loc,
                    'cbsa': p.cbsa.name,
                    'cbsa_geoid': p.cbsa.geoid,
                    'address': p.address,
                    'street': p.parsed_address.street_str(),
                    'geohash': p.geohash,
                    'kernel': kernel_name,
                    'value': p.value
                }

                if kernel is None or not isinstance(kernel, list):
                    row['score']  = p.score(kernel)
                elif  isinstance(kernel, list):
                    for k in kernel:
                        row[k.__name__] = p.score(k)

                scores.append(row)
            except KernelSizeError:
                # At the edges of the raster. FIXME
                pass

        if self.has_summary_patch:
            assert len(scores) == len(self.summary_patch.markers)

            if kernel is not None:

                if isinstance(kernel, list):
                    k = kernel[0]
                else:
                    k = kernel

                sp = self.summary_patch.convolve(k)
            else:
                sp = self.summary_patch

            for s, m in zip(scores, sp.markers):
                s['summary_value'] = m.value(sp)
                s['pct'] = m.percentile(sp)

        if return_dataframe:
            return pd.DataFrame(scores)
        else:
            return scores

    def dataframe(self, const=False):
        """Returns a dataframe with one row per kernel cell, and one column per patch

        :param const: Default value = False)
        :returns: with an optional const patch of the same size

        """

        r = [p.raster.ravel()[:, np.newaxis] for p in self.patches]

        names = [p.name for p in self.non_summary_patches]

        if const is True:
            r = [np.ones_like(r[0])] + r
            cols = ['const'] + names
        else:
            cols = names

        return pd.DataFrame(np.hstack(r), columns=cols)

    def group_by_location(self):
        return PatchesCollection({k: Patches(v, group_name=k)
                                  for k, v in (ps_grouper(self.non_summary_patches, lambda e: e.loc))})

    def group_by_layer(self):
        return PatchesCollection({k: Patches(v, group_name=k)
                                  for k, v in (ps_grouper(self.non_summary_patches, lambda e: (e.name, e.ri.band)))})

    def group_by_cbsa(self):
        # Group by name, for cases when the CBSA has the default geoid, and by
        # band when the cbsa crosses a band

        items = {k: Patches(v, True, group_name=k)
                 for k, v in (ps_grouper(self.non_summary_patches,
                                         lambda e: (e.cbsa.geoid, e.cbsa.name, e.ri.band)))}
        return PatchesCollection(items)

    def apply(self, f):
        patches = [f(p) for p in self.patches]
        return Patches(patches)

    def __getattr__(self, item):
        """Delegate a call or attribute to all of the internal patches"""

        from .util import CallContainer

        patches = []

        if len(self.patches) == 0:
            return self

        for p in self.patches:
            f = getattr(p, item)  # Sometimes a property, sometimes a function
            patches.append(f)

        # If the attribute isn't a property, it will be a callable, so we will
        # need to call all of them and then produce a new Patches
        if callable(patches[0]):
            ps = CallContainer(patches, Patches)

        else:
            # Just an attribute, so getting it ause the execution and returned a patch.
            ps = Patches(patches)

        return ps

    def sum(self):
        """Sum all of the internal patches and return a single patch"""

        if len(set(p.loc for p in self.non_summary_patches)) > 0:
            raise PatchError(f'Sum() requires that patch set have only one location.')

        return np.sum(self.non_summary_patches)

    def product(self):
        """Product of all of the internal patches and return a single patch"""

        if len(set(p.loc for p in self.non_summary_patches)) > 0:
            raise PatchError('Sum() requires that patch set have only one location')

        return np.product(self.non_summary_patches)

    def show(self, show_rings=False, legend=True):
        import matplotlib.pyplot as plt

        # Pick a square that is less than the total number of keys,
        # and also less than 25

        def arrange_plots(n):
            """Create a nice grid based on the number of plots"""

            if n == 1:
                return (1, 1)

            d1 = int(np.floor(np.sqrt(n)))
            d2 = int(np.ceil(n / d1))

            return (d1, d2)

        shape = arrange_plots(len(self))

        fig, axes = plt.subplots(*shape, figsize=(16, 16))

        axes = np.ravel(axes)

        for ax, (name, p) in zip(axes, self.items()):
            p.show(ax=ax, show_rings=show_rings, legend=legend)
            ax.set_title(p.plot_title())

    def _repr_pretty_(self, p, cycle):

        if cycle:
            from .exceptions import RasterException
            raise RasterException('Cycle in pretty printing, which should never happen')

        self.show(legend=True)


mean_road_length = 87.05  # _mean_road_length()
