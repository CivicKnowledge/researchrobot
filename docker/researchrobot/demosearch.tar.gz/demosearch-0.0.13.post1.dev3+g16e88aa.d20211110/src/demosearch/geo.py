from functools import lru_cache, total_ordering
from typing import Union

import libgeohash as gh
import numpy as np
import utm

from .exceptions import OutofBoundsError

GEOHASH_PREFIX = '📍'
GEOHASH_PRECISION = 8


class UTMTransformer(object):
    """Pre-build pyproj transformers to and from lat/lon and UTM zones for North America"""

    def __init__(self):
        from pyproj import Transformer

        self.to_utm = {}
        self.from_utm = {}

        for band in range(10, 20):
            self.to_utm[band] = Transformer.from_crs(4326, 32600 + band, always_xy=True).transform
            self.from_utm[band] = Transformer.from_crs(32600 + band, 4326, always_xy=True).transform

    def buffer_utm(self, band, size, g):
        """Convert a geometry in crs 4326 to UTM, buffer it, and convert it back

        :param band: param size:
        :param g: 
        :param size: 

        """
        from shapely.ops import transform

        g = transform(self.to_utm[band], g)
        g = g.buffer(size)
        g = transform(self.from_utm[band], g)

        return g


utm_transformer = UTMTransformer()


def assert_noram(lat, lon):
    """a rough check that the lat/lon has the right signs to
    be in North America

    :param lat: param lon:
    :param lon: 

    """
    if not (lat > 0 and lon < 0):
        raise OutofBoundsError(f'Definitely not in North America: lat={lat} lon={lon}')


@total_ordering
class Location(object):
    """Base class for a raster position, specified in lat/lon, UTM or pixels"""

    def __init__(self, raster_info: "RasterInfo", x: float, y: float):
        self.raster_info = raster_info

        self.orig_x = x
        self.orig_y = y

        self.x, self.y = raster_info.clip_utm(x, y)

        self.px, self.py = self.utm_to_pix(self.x, self.y)

        assert self.px >= 0, (self.x, raster_info.bbox[0], self.px)
        assert self.py >= 0, (self.y, raster_info.bbox[1], self.py)

        self.lat, self.lon = self.raster_info._utm_to_ll.transform(self.x, self.y)

        assert_noram(self.lat, self.lon)

    @property
    def area(self):
        return 0

    def reassign(self, rz: "RasterInfo"):
        """

        :param rz: RasterInfo":
        :param rz: "RasterInfo": 

        """
        return self.__class__(rz, self.x, self.y)

    def utm_to_pix(self, x, y):
        """

        :param x: param y:
        :param y: 

        """
        rz = self.raster_info

        x = int(np.round(x - int(rz._bbox[0]))) // rz.resolution
        y = int(np.round(y - int(rz._bbox[1]))) // rz.resolution

        return int(x), int(y)

    @property
    def utm(self):
        """ """
        return Utm(self.raster_info, self.x, self.y)

    @property
    def ll(self):
        """ """
        assert_noram(self.lat, self.lon)
        return LatLon(self.raster_info, self.lat, self.lon, self.x, self.y)

    @property
    def pix(self):
        """X,Y location for indexing rasters"""
        return Pix(self.raster_info, self.lat, self.lon, self.x, self.y)

    @property
    def band(self):
        """ """
        ll = self.ll
        x, y, band, row = utm.from_latlon(ll.lat, ll.lon)

        return band

    @property
    def epsg(self):
        """ """

        if self.ll.lat > 0:
            return int(f"326{self.band}")
        else:
            return int(f"327{self.band}")

    @property
    def center(self):
        """ """
        return self

    @property
    def area(self):
        """Area, in square meters. For a point, always 0"""

        return 0

    @property
    def min_utm(self):
        """ """
        from demosearch.util import resfloor
        res = self.raster_info.resolution
        return Utm(self.raster_info, resfloor(self.x, res), resfloor(self.y, res))

    @property
    def max_utm(self):
        """ """
        from demosearch.util import resceil
        res = self.raster_info.resolution
        return Utm(self.raster_info, resceil(self.x, res), resceil(self.y, res))

    @property
    def transform(self):
        """ """
        from rasterio.transform import from_origin

        res = self.raster_info.resolution

        return from_origin(*(self.min_utm), res, -res)

    def to_geohash(self, precision=GEOHASH_PRECISION):
        """Convert to a geohash string"""
        return gh.encode(*(self.ll), precision)

    def to_array(self):
        """return components as a numpy array"""
        return np.array(list(self))

    @classmethod
    def from_geohash(self, hash):
        lat, lon = gh.decode(hash)
        return lat, lon

    def __iter__(self):
        return iter([self.x, self.y])

    def __eq__(self, other):
        return int(self.x) == int(other.x) and int(self.y) == int(other.y)

    def __lt__(self, other):
        return self.to_geohash() < other.to_geohash()

    def __hash__(self):
        return hash(self.x) ^ hash(self.y)

    def __str__(self):
        return f"[{self.x} {self.y} p({self.px} {self.py})]"

    def __repr__(self):
        return str(self)

    def __sub__(self, other):
        raise NotImplementedError


class Pix(Location):
    """A location that returns coordinates on the zone raster"""

    def __init__(self, raster_info: "RasterInfo",
                 pix_x: float, pix_y: float,
                 utm_x: float = None, utm_y: float = None):

        self.orig_px = pix_x
        self.orig_py = pix_y

        if utm_x is not None and utm_y is not None:
            super().__init__(raster_info, utm_x, utm_y)
        else:
            # Offset the pix location by the UTM minimum point of the
            # raster bounding box
            super().__init__(raster_info,
                             (pix_x * raster_info.resolution + int(raster_info._bbox[0])),
                             (pix_y * raster_info.resolution + int(raster_info._bbox[1])))

    def copy(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        return Utm(raster_info, self.orig_px, self.orig_py)

    def patch(self, size=None):
        """

        :param size: Default value = SMALL_PATCH_SIZE)

        """
        from demosearch.constants import SMALL_PATCH_SIZE

        size = size if size is not None else SMALL_PATCH_SIZE

        x, y = list(self)

        return PixBbox.from_bbox(self.raster_info,
                                 x - size, y - size,
                                 x + size + 1, y + size + 1, )

    @property
    def slice(self):
        """ """
        return (self.py, self.px)

    def __iter__(self):
        return iter([self.px, self.py])

    def __str__(self):
        return f"[{self.x} {self.y} p({self.px} {self.py})]"

    def __sub__(self, other):
        assert isinstance(other, Pix)

        dpx, dpy = self.px - other.px, self.py - other.py

        return (dpx, dpy) # Can't be a location object

    def __rsub__(self, other):
        assert isinstance(other, Location)
        raise NotImplementedError()


@lru_cache()
def null_raster_info(lat, lon):
    """

    :param lat: param lon:
    :param lon: 

    """
    from .raster import RasterInfo
    return RasterInfo.null(lat, lon)


class LatLon(Location):
    """A location specified in Lat/Lon"""

    def __init__(self, raster_info: "RasterInfo",
                 lat: float, lon: float,
                 utm_x: float = None, utm_y: float = None):

        assert_noram(lat, lon)

        self.orig_lat = float(lat)
        self.orig_lon = float(lon)

        if utm_x is not None and utm_y is not None:
            super().__init__(raster_info, utm_x, utm_y)
            assert_noram(self.lat, self.lon)
        else:
            # PERFORMANCE. The creation of the null RasterInfo in null_raster_info is the
            # slowest part of requesting rasters, due to looking up UTM zones, probably,
            # so it is LRU'd, but it would be good to optimize it further. Or get rid of it.

            allow_clipping = raster_info is not None

            self.raster_info = raster_info if raster_info is not None else \
                null_raster_info(round(lat, 0), round(lon, 0))  # Round to improve LRU cache hits

            x, y = self.raster_info._ll_to_utm.transform(lat, lon)

            # Clipping ensures that the coordinates will be inside the raster boundaries,
            # but we should not be clipping to the null raster.
            if allow_clipping:
                self.x, self.y = self.raster_info.clip_utm(x, y)
            else:
                self.x, self.y = (x, y)

            self.px, self.py = self.utm_to_pix(self.x, self.y)
            # Converting back from UTM because the UTM may have been clipped
            self.lat, self.lon = self.raster_info._utm_to_ll.transform(self.x, self.y)

            assert_noram(self.lat, self.lon)

        assert self.orig_lat * self.lat > 0, "sign changed"  # Check for same sign
        assert self.orig_lon * self.lon > 0, "sign changed"  # Check for same sign

    def reassign(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        return LatLon(raster_info, self.orig_lat, self.orig_lon)

    @property
    def slice(self):
        """ """
        return (self.lon, self.lat)

    @property
    def point(self):
        """ """
        from shapely.geometry import Point
        return Point(self.lon, self.lat)

    def __iter__(self):
        return iter([self.lat, self.lon])

    def __str__(self):
        return f"[{self.x} {self.y} ll({self.lat} {self.lon})]"

    def __sub__(self, other):
        from math import sqrt

        dx = self.lon - other.lon
        dy = self.lat - other.lat

        return sqrt(dx ** 2 + dy ** 2)


class Utm(Location):
    """A location specified in UTM X,Y"""

    def copy(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        return Utm(raster_info, self.orig_x, self.orig_y)

    @property
    def slice(self):
        """ """
        return (self.x, self.y)

    def patch(self, size=None):
        """

        :param size: Default value = SMALL_PATCH_SIZE)

        """
        from demosearch.constants import DEFAULT_RESOLUTION
        from demosearch.constants import SMALL_PATCH_SIZE

        size = size if size is not None else SMALL_PATCH_SIZE * DEFAULT_RESOLUTION

        x, y = list(self)

        # Adjustment required to have patches created in UTM align with patches
        # created in pixels.
        # assert list(loc.pix.patch().utm)  == list(loc.utm.patch())
        x -= DEFAULT_RESOLUTION / 2
        y -= DEFAULT_RESOLUTION / 2

        return UtmBbox.from_bbox(self.raster_info,
                                 x - size, y - size,
                                 x + size + DEFAULT_RESOLUTION, y + size + DEFAULT_RESOLUTION, )


class Bbox(object):
    """ """

    location_class = None

    def __init__(self, raster_info: "RasterInfo", min_pt: Location, max_pt: Location):
        self.raster_info = raster_info
        self.min_pt = min_pt
        self.max_pt = max_pt

    def __hash__(self):
        return hash(self.min_pt) ^ hash(self.max_pt)

    @property
    def utm(self):
        """ """
        return UtmBbox(self.raster_info, self.min_pt.utm, self.max_pt.utm)

    @property
    def ll(self):
        """ """
        return LatLonBbox(self.raster_info, self.min_pt.ll, self.max_pt.ll)

    @property
    def pix(self):
        """ """
        return PixBbox(self.raster_info, self.min_pt.pix, self.max_pt.pix)

    @property
    def transform(self):
        """ """
        return self.min_pt.transform

    @property
    def geom_transform(self):
        """


        :returns: convert geometries in UTM to the same coordinates as a raster.

        """
        res = self.raster_info.resolution
        return [1 / res, 0, 0, 1 / res, -self.min_pt.x / res, -self.min_pt.y / res]

    @property
    def epsg(self):
        """ """
        return self.center.epsg

    @property
    def band(self):
        """ """
        return self.center.band

    @property
    def x_min(self):
        """ """
        return self.min_pt.x

    @property
    def y_min(self):
        """ """
        return self.min_pt.y

    @property
    def x_max(self):
        """ """
        return self.max_pt.x

    @property
    def y_max(self):
        """ """
        return self.max_pt.y

    @property
    def area(self):
        """Area, in square meters, after converting to UTM"""
        xmin, ymin, xmax, ymax = list(self.utm)

        return np.abs((xmax - xmin) * (ymax - ymin))

    @property
    def shape(self):
        """ """
        xmin, ymin, xmax, ymax = list(self.utm)

        return (xmax - xmin), (ymax - ymin)

    @property
    def x_len(self):
        """ """
        xmin, ymin, xmax, ymax = list(self.utm)

        return (xmax - xmin)

    @property
    def y_len(self):
        """ """
        xmin, ymin, xmax, ymax = list(self.utm)

        return (ymax - ymin)

    def square(self):
        """


        :returns: increasing the shorter dimension

        """

        raise NotImplementedError()

    @property
    def polygon(self):
        from shapely.geometry import box
        return box(*list(self))

    def to_array(self):
        """return components as a numpy array"""
        return np.array(list(self))

    def expand(self, margin):
        """

        :param margin: 

        """
        raise NotImplementedError()

    def reassign(self, rz: "RasterInfo"):
        """

        :param rz: RasterInfo":
        :param rz: "RasterInfo": 

        """
        return self.__class__(rz,
                              self.min_pt.reassign(rz),
                              self.max_pt.reassign(rz))

    def to_geohash(self, precision=GEOHASH_PRECISION):
        ll = self.ll
        return ll.min_pt.to_geohash(precision) + ';' + ll.max_pt.to_geohash(precision)

    def __eq__(self, other):
        return self.min_pt == other.min_pt and self.max_pt == other.max_pt

    def __hash__(self):
        return hash(self.min_pt) ^ hash(self.min_pt)

    def __iter__(self):
        """Return a list version of the bounding box"""
        from itertools import chain
        return chain(self.min_pt, self.max_pt)

    def __str__(self):
        return f"[{str(self.min_pt)}\n {str(self.max_pt)}]"

    def __repr__(self):
        return str(self)


class UtmBbox(Bbox):
    """ """

    location_class = Utm

    @classmethod
    def from_bbox(cls, raster_info, xmin, ymin, xmax, ymax):
        """

        :param raster_info: param xmin:
        :param ymin: param xmax:
        :param ymax: 
        :param xmin: 
        :param xmax: 

        """
        return UtmBbox(raster_info, Utm(raster_info, xmin, ymin), Utm(raster_info, xmax, ymax))

    @property
    def center(self):
        """ """
        return Utm(self.raster_info,
                   np.mean([self.min_pt.x, self.max_pt.x]),
                   np.mean([self.min_pt.y, self.max_pt.y]))

    def copy(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        n = UtmBbox(raster_info,
                    Utm(raster_info, self.min_pt.x, self.min_pt.y),
                    Utm(raster_info, self.max_pt.x, self.max_pt.y))

        return n

    @property
    def slice(self):
        """ """
        return (slice(self.min_pt.x, self.max_pt.x), slice(self.min_pt.y, self.max_pt.y))

    def patch(self, size=None):

        if size is not None:
            r = self.center.patch(size)
            assert r.area > 0
            return r

        else:
            assert self.area > 0
            return self

    def square(self):
        """


        :returns: increasing the shorter dimension

        """

        xmin, ymin, xmax, ymax = list(self)

        x, y = list(self.center)

        if self.x_len == self.y_len:
            return self
        elif self.x_len < self.y_len:
            dy = self.y_len / 2
            xmin = x - dy
            xmax = x + dy

        else:  # self.y_len < self.x_len:
            dx = self.x_len / 2
            ymin = y - dx
            ymax = y + dx

        return self.__class__.from_bbox(self.raster_info, xmin, ymin, xmax, ymax)

    def expand(self, margin):
        """

        :param margin: 
        :returns: the margin.

        """

        xmin, ymin, xmax, ymax = list(self)

        return self.__class__.from_bbox(self.raster_info,
                                        xmin - margin, ymin - margin, xmax + margin, ymax + margin)


class LatLonBbox(Bbox):
    """ """

    location_class = LatLon

    @classmethod
    def from_bbox(cls, raster_info, lon_min, lat_min, lon_max, lat_max):
        """

        :param raster_info: param lon_min:
        :param lat_min: param lon_max:
        :param lat_max: 
        :param lon_min: 
        :param lon_max: 

        """
        assert_noram(lat_min, lon_min)
        assert_noram(lat_max, lon_max)

        return LatLonBbox(raster_info,
                          LatLon(raster_info, lat_min, lon_min),
                          LatLon(raster_info, lat_max, lon_max))

    @classmethod
    def from_dict(cls, raster_info, d):
        """Create bounding box from a dictionary, with northeast and sw

        :param raster_info: param d:
        :param d: 

        """

        lat_min, lon_min = d['southwest']
        lat_max, lon_max = d['northeast']

        # lon_min, lat_min = d['southwest']
        # lon_max ,lat_max = d['northeast']

        return cls.from_bbox(raster_info, lon_min, lat_min, lon_max, lat_max)

    @classmethod
    def from_positions(cls, raster_info, positions):
        """Create a bounding boc that contains a set of positions

        :param raster_info: 
        :param positions: 

        """
        import numpy as np

        lat_min = np.min([p.center.lat for p in positions])
        lat_max = np.max([p.center.lat for p in positions])
        lon_min = np.min([p.center.lon for p in positions])
        lon_max = np.max([p.center.lon for p in positions])

        return cls.from_bbox(raster_info, lon_min, lat_min, lon_max, lat_max)

    @property
    def center(self):
        """ """
        clat = np.mean([self.min_pt.lat, self.max_pt.lat])
        clon = np.mean([self.min_pt.lon, self.max_pt.lon])
        assert_noram(clat, clon)
        return LatLon(self.raster_info, clat, clon)

    def copy(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        return LatLonBbox(raster_info,
                          LatLon(raster_info, self.min_pt.lat, self.min_pt.lon),
                          LatLon(raster_info, self.max_pt.lat, self.max_pt.lon))

    def __iter__(self):
        return iter([self.min_pt.lon, self.min_pt.lat, self.max_pt.lon, self.max_pt.lat])

    @property
    def nsew(self):
        """Return a list of values in the order of North, South, East, West"""

        w, s, e, n = self.min_pt.lon, self.min_pt.lat, self.max_pt.lon, self.max_pt.lat

        return (n, s, e, w)

    @property
    def slice(self):
        """ """
        return (slice(self.min_pt.lon, self.max_pt.lon), slice(self.min_pt.lat, self.max_pt.lat))


class PixBbox(Bbox):
    """ """

    def __init__(self, raster_info: "RasterInfo", min_pt: Location, max_pt: Location):

        super().__init__(raster_info, min_pt, max_pt)

    @classmethod
    def from_bbox(cls, raster_info, xmin, ymin, xmax, ymax):
        """

        :param raster_info: param xmin:
        :param ymin: param xmax:
        :param ymax: 
        :param xmin: 
        :param xmax: 

        """

        return PixBbox(raster_info, Pix(raster_info, xmin, ymin), Pix(raster_info, xmax, ymax))

    def from_patch(self, xmin, ymin, xmax, ymax):
        """Create a pix bounding box from patch dimensions, a subset of the zone raster

        :param xmin: param ymin:
        :param xmax: param ymax:
        :param ymin: 
        :param ymax: 

        """

        return PixBbox.from_bbox(self.raster_info,
                                 xmin + self.min_pt.px, ymin + self.min_pt.py,
                                 xmax + self.max_pt.px, ymax + self.max_pt.py)

    def to_zone(self, x, y):
        """Convert a patch coordinate to a zone coordinate, ( pix coordinate relative to
        the whole band raster )

        :param x: param y:
        :param y: 

        """
        return Pix(self.raster_info, x + self.min_pt.px, y + self.min_pt.py)

    @property
    def center(self):
        """ """
        return Pix(self.raster_info,
                   np.mean([self.min_pt.px, self.max_pt.px]),
                   np.mean([self.min_pt.py, self.max_pt.py]))

    def copy(self, raster_info: "RasterInfo"):
        """

        :param raster_info: RasterInfo":
        :param raster_info: "RasterInfo": 

        """
        return PixBbox(raster_info,
                       Pix(raster_info, self.min_pt.px, self.min_pt.py),
                       Pix(raster_info, self.max_pt.px, self.max_pt.py))

    @property
    def slice(self):
        """ """
        return (slice(self.min_pt.py, self.max_pt.py), slice(self.min_pt.px, self.max_pt.px))

    def patch(self, size=None):

        if size is not None:
            r = self.center.patch(size)
            assert r.area > 0
            return r

        else:
            assert self.area > 0
            return self

    @property
    def area(self):
        """Area, in square pixels"""
        xmin, ymin, xmax, ymax = list(self)

        return np.abs((xmax - xmin) * (ymax - ymin))

    @property
    def shape(self):
        """ """
        xmin, ymin, xmax, ymax = list(self)

        return (xmax - xmin), (ymax - ymin)


LocOrBB = Union[Location, Bbox, None]


def normalize_addresses(addresses):
    """

    :param addresses: 

    """

    def astr(adr):
        """

        :param adr: 

        """

        a = " ".join(
            [str(i).title() for i in [adr.number.number if adr.number.number > 0 else '',
                                      adr.road.direction,
                                      adr.road.name, adr.road.suffix] if i])

        if adr.locality.city and adr.locality.city != 'none':
            a += ", " + adr.locality.city.title()

        if adr.locality.state:
            a += ", " + adr.locality.state.upper()

        if adr.locality.zip:
            a += " " + str(adr.locality.zip)

        return a

    if isinstance(addresses, str):
        addresses = [addresses]

    from address_parser import Parser

    parser = Parser()

    def _f(line):
        """

        :param line: 

        """
        a = parser.parse(line)
        return astr(a)

    return [_f(line) for line in addresses]


# Geohash alphabet
import string

gh32chars = string.ascii_lowercase + string.digits
gh32chars = ''.join([e for e in gh32chars if e not in "ailo"])
assert len(gh32chars) == 32, len(gh32chars)


def is_geohash(v, extra_chars=''):
    if ';' in v:
        return len(v) <= 12 + 12 + 1 and all([e in gh32chars + extra_chars + ';' for e in v])
    else:
        return len(v) <= 12 and all([e in gh32chars + extra_chars for e in v])

    # return isinstance(v, str) and v.startswith(GEOHASH_PREFIX)


def prefix_geohash(v):
    return v
    # return GEOHASH_PREFIX+v


def encode_geohash(v):
    if isinstance(v, Location):
        return prefix_geohash(v.ll.to_geohash())
    else:
        return prefix_geohash(gh.encode(*v, GEOHASH_PRECISION))


def decode_geohash(v):
    if ';' in v and is_geohash(v):
        a, b = v.split(';')
        # In this case, return the bounding box format, which has
        # the lat/lon reversed
        return decode_geohash(a)[::-1] + decode_geohash(b)[::-1]

    if is_geohash(v):
        if v.startswith(GEOHASH_PREFIX):
            return gh.decode(v[1:])
        else:
            return gh.decode(v)

    raise TypeError('Probably not a geohash: ' + str(v))
