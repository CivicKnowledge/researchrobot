"""

"""

import logging
import warnings
from collections import defaultdict
from dataclasses import dataclass

import geocoder
from address_parser import Parser
from geocoder.api import options
from geocoder.base import OneResult
from geocoder.here import HereQuery as _HereQuery
from geocoder.opencage import OpenCageQuery as _OpenCageQuery, OpenCageResult as _OpenCageResult

from geocoder.osm import OsmQuery
from slugify import slugify

logger = logging.getLogger(__name__)


class GeocodeFailed(Exception):
    """ """
    pass


class HereResult(OneResult):

    def __init__(self, json_content):
        self._display_position = json_content.get('position', {})
        self._address = json_content.get('address', {})
        self._mapview = json_content.get('mapView', {})

        super(HereResult, self).__init__(json_content)

    @property
    def lat(self):
        return self._display_position.get('lat')

    @property
    def lng(self):
        return self._display_position.get('lng')

    @property
    def address(self):
        return self._address.get('label')

    @property
    def postal(self):
        return self._address.get('PostalCode')

    @property
    def housenumber(self):
        return self._address.get('HouseNumber')

    @property
    def street(self):
        return self._address.get('Street')

    @property
    def neighborhood(self):
        return self.district

    @property
    def district(self):
        return self._address.get('District')

    @property
    def city(self):
        return self._address.get('City')

    @property
    def county(self):
        return self._address.get('County')

    @property
    def state(self):
        return self._address.get('State')

    @property
    def country(self):
        return self._address.get('Country')

    @property
    def quality(self):
        return self.raw.get('MatchLevel')

    @property
    def accuracy(self):
        return self.raw.get('MatchType')

    @property
    def bbox(self):
        south = self._mapview['south']
        north = self._mapview['north']
        west = self._mapview['west']
        east = self._mapview['east']
        return self._get_bbox(south, west, north, east)


class HereQuery(_HereQuery):
    _RESULT_CLASS = HereResult

    _URL = "https://geocode.search.hereapi.com/v1/geocode"

    def _build_params(self, location, provider_key, **kwargs):
        return {'apikey': kwargs['api_key'], 'q': location}

    def _adapt_results(self, json_response):
        # Build intial Tree with results
        return [item for item in json_response['items']]


options['here']['geocode'] = HereQuery


class OpenCageResult(_OpenCageResult ):
    @property
    def bbox(self):
        """Address a bug, https://github.com/DenisCarriere/geocoder/issues/447"""
        from geocoder.location import BBox
        south = self._bounds.get('southwest', {}).get('lat')
        north = self._bounds.get('northeast', {}).get('lat')
        west = self._bounds.get('southwest', {}).get('lng')
        east = self._bounds.get('northeast', {}).get('lng')

        if all([south, west, north, east]):
            return BBox.factory([west, south, east, north]).as_dict


class OpenCageQuery(_OpenCageQuery):

    _RESULT_CLASS = OpenCageResult

    def _adapt_results(self, json_response):
        results = super()._adapt_results(json_response)

        return results



options['opencage']['geocode'] = OpenCageQuery

from typing import Callable


@dataclass
class GCRecord:
    name: str
    gc: Callable
    args: dict
    group: int
    priority: int

    def __call__(self, q):
        return self.gc(q, **self.args)


class CachingGeocoder(object):
    """ """

    geocode_cache_prefix = 'geocode'
    user_cache_prefix = 'geoinput'

    def __init__(self, config, testing=False):
        from .cache import RedisCache

        self.config = config
        self.cache = self.config.cache

        self.testing = testing

        self.key_template = '{prefix}/{slug}'

        self.hits = 0
        self.misses = 0
        self.not_found = 0

        self.address_parser = Parser()

        self._by_name, self._geocoders = self.setup_geocoders()

        self.gc_cache = self.redis = RedisCache.get_redis(config)

    def select_gc(self, group=1, using=None, exclude=[]):
        from random import choices

        # Get all of the geocoders in the group, excluding those that don't have
        # any priority or are on the exclude list
        gcs = list(filter(lambda e: e not in exclude and e.priority > 0, self._geocoders[group]))


        if len(gcs) == 0:
            raise GeocodeFailed('All GCS are excluded')

        weights = [e.priority for e in gcs]

        while True:
            return choices(gcs, weights=weights, k=1)[0]

        raise GeocodeFailed('This should never happen')

    def gc_set(self, using=False):
        """Produce a list of GC records that considers the priorities withing each group"""

        if using:
            return [self._by_name[using]]


        gcs = []
        for group in sorted(self._geocoders.keys()):
            while True:
                try:
                    gc = self.select_gc(group=group, exclude=gcs, using=using)
                    gcs.append(gc)
                except GeocodeFailed:
                    break

        return gcs

    def setup_geocoders(self):
        coders = {}

        for name, d in self.config.config.geocoders.items():

            d = dict(d)

            if 'priority' in d:
                priority = d['priority']
                del d['priority']
            else:
                priority = 1

            if 'group' in d:
                group = d['group']
                del d['group']
            else:
                group = 1

            # The getattr extracts the geocoding routine from the
            # geocoder module
            coders[name] = GCRecord(name, getattr(geocoder, name), d, group, priority)

        gc_groups = defaultdict(list)

        for k in sorted(coders.keys(), key=lambda e: coders[e].group):
            gc_groups[coders[k].group].append(coders[k])

        return coders, gc_groups

    def clear_cache(self):
        """ """
        self.gc_cache.clear(self.geocode_cache_prefix)
        self.gc_cache.clear(self.user_cache_prefix)

    def cache_key(self, address):
        """

        :param address: 

        """
        return self.key_template.format(prefix=self.geocode_cache_prefix, slug=slugify(address))

    def _geocode(self, gcr, query):
        """

        :param query:
        :param gcf:
        :param name:
        :param gc_key:

        """
        logger.info(f'Geocode with {gcr.name}: {query}')

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            r = gcr(query).json

        if r:
            r['_geocoder'] = gcr.name
            r['_cache'] = 'miss'
            self.misses += 1
            return r
        else:
            self.not_found += 1
            return None

    def geocode(self, query, using=None, force=False):
        """

        :param query: param force:  (Default value = False)
        :param force:  (Default value = False)

        """

        key = self.cache_key(query)

        if self.gc_cache.exists(key) and force is False:
            r = self.gc_cache.get(key)
            r['_cache'] = 'hit'
            r['_query'] = query
            self.hits += 1
            logger.info(f'Cache hit for key: {key}')
            return r

        for gcr in self.gc_set(using):

            r = self._geocode(gcr, query)
            if r is not None:
                logger.info(f'Cache miss for key: {key}')
                r['_cache_key'] = key
                r['_query'] = query
                r['_cache'] = 'hit'  # For the later get
                self.gc_cache.put(key, r)
                r['_cache'] = 'miss'  # b/c this time it was a miss
                return r

        logger.info(f'All geocoders failed for: {query}')
        raise GeocodeFailed(f"Failed to geocode '{query}'")

    def multi_geocode(self, query, parallel=True, using=None, use_tqdm=False):
        """Geocode a list of addresses in parallel

        :param query: 
        :param parallel:  (Default value = True)

        """
        from tqdm.auto import tqdm

        if not query:
            return []

        # Enumerate the queries so we can keep track of order for output.
        if isinstance(query[0], (tuple, list)):
            equery = query
        else:
            equery = list(enumerate(query))

        # First, compile all of the queries which are already in the cache.

        results = []
        misses = []

        logger.info(f"MultiGeocode: query length {len(equery)}")

        if use_tqdm:
            equery = tqdm(equery, desc="checking cache")

        # Check the cache for all queries first
        for i, q in equery:
            key = self.cache_key(q)
            if self.gc_cache.exists(key):
                r = self.gc_cache.get(key)
                r['_enum'] = i
                r['_exception'] = None
                self.hits += 1
                logger.info(f'Cache hit for key: {key}')
                results.append((i, r, None))
            else:
                misses.append((i, q))

        logger.info(f"MultiGeocode: {len(results)} in cache")
        logger.info(f"MultiGeocode: {len(misses)} not in cache")

        # Now we can batch process the misses

        def _gc(i, q):
            """

            :param i: 
            :param q: 

            """
            try:
                r = self.geocode(q, using=using)
                r['_exception'] = None
                r['_enum'] = i
                return (i, r, None)
            except GeocodeFailed as e:
                return (i, {
                    '_query': q,
                    '_cache': 'error',
                    'lat': None,
                    'lng': None,
                    '_enum': i,
                    '_exception': e
                }, e)

        logger.info(f"MultiGeocode: parallel geocode {len(misses)} jobs")

        if parallel:
            from joblib import Parallel, delayed

            if tqdm:
                misses = tqdm(misses, desc="Parallel geocode")

            r = Parallel(n_jobs=4, prefer="threads")(delayed(_gc)(i, q) for i, q in misses)
            results.extend(r)
        else:

            if use_tqdm:
                misses = tqdm(misses, desc="Serial geocode")

            for i, q in misses:
                results.append(_gc(i, q));

        results = [e[1] for e in sorted(results, key=lambda e: e[0])]

        return results
