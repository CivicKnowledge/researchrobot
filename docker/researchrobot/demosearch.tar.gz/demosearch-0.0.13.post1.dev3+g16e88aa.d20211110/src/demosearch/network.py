import geopandas as gpd
import networkx as nx
import osmnx as ox
from osmnx.distance import nearest_nodes
from shapely.geometry import Point, LineString, Polygon

from .geo import Location

GRID_SIZE = 40_000  # Size of network to download
GRID_OVERLAP = 8_000  # How much larger the downloaded grid is.


class Isochrone(object):

    def __init__(self, config):

        self.config = config
        self.cache = config.cache

    def location_key(self, loc):
        """Produce a key for a bounding box to download for the network"""

        from demosearch.geo import Utm

        l = loc.utm.center
        l2 = Utm(l.raster_info, *list(l.to_array() // GRID_SIZE * GRID_SIZE))

        bbox = l2.patch(GRID_SIZE + GRID_OVERLAP).ll

        return bbox, 'osm_network/' + bbox.to_geohash(12).replace(';', '_')

    def download_graph(self, loc: Location, network_type='walk'):
        """Download a graph section that includes a location, or return a cached version"""

        import pickle, bz2
        from demosearch.cache import ensure_dir

        bbox, lk = self.location_key(loc)

        p = self.cache.path(lk)
        print(p)

        if not self.cache.exists(lk):
            G_ll = ox.graph_from_bbox(*bbox.ll.nsew, network_type=network_type)
            G = ox.project_graph(G_ll)

            ensure_dir(p)
            with bz2.open(p, "wb") as f:
                pickle.dump(G, f)

        else:
            with bz2.open(p, "rb") as f:
                G = pickle.load(f)

        return G

    # From https://github.com/gboeing/osmnx-examples/blob/v0.13.0/notebooks/13-isolines-isochrones.ipynb
    def make_iso_polys(self, G, loc: Location, distances, edge_buff=25, node_buff=25, infill=False):
        """Create polygons for isochrones in a network"""

        center = loc.utm.center

        center_node = nearest_nodes(G, *list(center))

        isochrone_polys = []
        for trip_time in sorted(distances, reverse=True):
            subgraph = nx.ego_graph(G, center_node, radius=trip_time, distance='length')

            node_points = [Point((data['x'], data['y'])) for node, data in subgraph.nodes(data=True)]
            nodes_gdf = gpd.GeoDataFrame({'id': subgraph.nodes()}, geometry=node_points)
            nodes_gdf = nodes_gdf.set_index('id')

            edge_lines = []
            for n_fr, n_to in subgraph.edges():
                f = nodes_gdf.loc[n_fr].geometry
                t = nodes_gdf.loc[n_to].geometry
                edge_lookup = G.get_edge_data(n_fr, n_to)[0].get('geometry', LineString([f, t]))
                edge_lines.append(edge_lookup)

            n = nodes_gdf.buffer(node_buff).geometry
            e = gpd.GeoSeries(edge_lines).buffer(edge_buff).geometry
            all_gs = list(n) + list(e)
            new_iso = gpd.GeoSeries(all_gs).unary_union

            # try to fill in surrounded areas so shapes will appear solid and blocks without white space inside them
            if infill:
                new_iso = Polygon(new_iso.exterior)
            isochrone_polys.append(new_iso)

        t = gpd.GeoDataFrame({'geometry': isochrone_polys}, crs=center.epsg)
        t['distance'] = distances

        return t

    def make_iso_df(self, loc,  dists=None):
        """Make an isochrone, rasterize it to the HDF file,
        and return the new layer name"""

        from demosearch.constants import LARGE_PATCH_SIZE
        from . import ConfigFile, RasterInstaller
        import pandas as pd

        if dists is None:
            from demosearch.kernel import v_walk

            dists = [5 * v_walk, 10 * v_walk, 15 * v_walk, 30 * v_walk]

        G = self.download_graph(loc.center, network_type='walk')
        gdf = self.make_iso_polys(G, loc, dists, infill=True)


        raster_name = loc.ll.to_geohash() + '_' + '_'.join([str(int(e)) for e in dists])

        # This is a total hack to get the raster to be at least
        # the size of a patch, but rasterizing a square polygon
        # that is just outside of the patch area

        bbox_poly = loc.utm.patch(LARGE_PATCH_SIZE + 5).polygon.boundary.buffer(5)

        crs = gdf.crs
        gdf = pd.concat([gpd.GeoDataFrame([{'geometry': bbox_poly, 'distance': 0}], crs=gdf.crs),
                         gdf]).rename(columns={'distance': raster_name})
        gdf.crs = crs

        return raster_name, G, gdf


