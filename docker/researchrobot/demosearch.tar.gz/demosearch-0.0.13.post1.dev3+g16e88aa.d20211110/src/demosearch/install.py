"""
Manager object to install data into the caches.
"""
__docformat__ = 'restructuredtext en'

import logging
from pathlib import Path
from typing import Any

import geopandas as gpd
import h5py
import numpy as np
import pandas as pd
import rowgenerators as rg
from demosearch.exceptions import InstallException

logger = logging.getLogger(__name__)


class RasterInstaller(object):
    """ """

    def __init__(self, config, output_file=None, resolution=100):
        """ """

        self.config = config
        self.cache = self.config.cache

        logger.debug(f'Install to cache {self.cache._cache_root}')
        self.radius = 10_000
        self.resolution = resolution

        if output_file is not None:
            self.rp = Path(output_file)
        else:
            self.rp = self.cache.joinpath('raster.h5')

    def rasterization_tasks(self, primary_key=None):
        """Return tasks for the reaming rasterization tasks in the cache

        :param primary_key: Default value = None)
        :returns: rtype:

        """

        tasks = []

        for f in self.cache.list('install/tasks', '**/*.pkl'):
            tasks.append((self.cache, f, primary_key))


        return tasks

    def fetch_and_cache(self, data_url, force=False):
        from slugify import slugify

        data_key = f'/install/data/{slugify(data_url)}'

        if self.cache.exists(data_key) and not force:
            logger.debug(f'Found cached data for {data_url}')
            df =  self.cache.get(data_key)
        else:
            logger.debug(f'Fetching and caching {data_url}')
            df = rg.geoframe(data_url)

            # Add bands here to get it into the cache
            df = self.add_bands(df)

            self.cache.put(data_key, df)

        logger.debug(f"Dataset has {len(df)} rows")

        return df

    def add_bands(self, df):
        if not 'band' in df.columns:
            logger.debug('Dataset has no bands, adding it via overlay')
            try:
                data_url = self.config.config.data.utm_bands_buffered
            except AttributeError:
                raise InstallException('Input dataset does not have a bands column, and'
                                       ' there is no configuration value for data.utm_bands_buffered')

            utm_bands_buffered = rg.geoframe(data_url).to_crs(4326)

            t = df.to_crs(4326)

            df = gpd.overlay(t, utm_bands_buffered)

        return df

    def prep_for_rasterize(self, df, group, layers=None, force=False):
        """Segment a geographic file into UTM bands and cache them.

        :param df: type df:
        :param group: type group:
        :param layers: type layers: (Default value = None)
        :param force: type force: (Default value = False)
        :returns: rtype:

        """

        logger.debug(f'Prep for group {group}')
        marker_key = f'/install/prep/{group}'

        if self.cache.exists(marker_key) and not force:
            logger.debug(f'Found cached markers')
            return self.cache.get(marker_key)

        if layers is None:
            # Figure out what columns to rasterize, numeric columns only, and
            # exclude some support columns
            layers = set(df.select_dtypes(include=np.number).columns.tolist()) - \
                     {'band', 'zone', 'epsg', 'geometry'}

        keys = []
        logger.debug(f'Prep for group {group}; writing {df.band.nunique()} bands')
        for idx, g in df.groupby('band'):
            g = g.to_crs(32600 + idx)
            k = f'install/tasks/{group}/{idx}'

            self.cache.put(k, g[list(layers) + ['geometry']])
            keys.append(k)
            logger.debug(f'Wrote band for {k} ')

        self.cache.put(marker_key, keys)

        return keys

    def clean_markers(self):
        """Remove the marker files to indicate that a group should not
        be pre-prepared in prep_for_rasterize


        """

        from collections import defaultdict

        counts = defaultdict(int)

        for cache, key in self.rasterization_tasks():
            _, _, group, band = key.split('/')
            counts[group] += 1

        for fn in self.cache.list('install/prep'):
            if counts.get(fn, 0) == 0:
                self.cache.delete(fn)

        return counts

    @staticmethod
    def _rasterize(cache, cache_key, primary_key):
        """

        :param cache: param cache_key:
        :param primary_key: 
        :param cache_key: 

        """
        from demosearch.raster import RasterZoneInstaller

        dest_key = cache_key.replace('/tasks/', '/hdf/')

        dest_path = cache.joinpath(dest_key, mkdir=True).with_suffix('.hd5')

        if dest_path.exists():
            cache.delete(cache_key)
            return dest_path

        _, _, group, band = cache_key.split('/')

        df = cache.get(cache_key)

        rzi = RasterZoneInstaller.rasterize(group, df, primary_key=primary_key)

        rzi.write(dest_path)

        cache.delete(cache_key)

        return dest_path

    def mp_rasterize(self, primary_key=None, tasks=None, debug=False):
        """Just run the multiple process rasterication part, not the dataset prep

        :param primary_key: Default value = None)
        :param tasks: Default value = None)
        :param debug: Default value = False)

        """
        from demosearch.util import run_mp

        if tasks is None:
            tasks = self.rasterization_tasks(primary_key=primary_key)

        logger.debug(f'{len(tasks)} Tasks')

        if debug:
            for task in tasks:
                print("Debug run:", task)
                self._rasterize(*task)
        else:
            return run_mp(self._rasterize, tasks)

    def rasterize(self, data_url_or_df, group, layers=None, primary_key=None, force=False, debug=False):
        """Rasterize and store a geographic data frame

        :param df: param group:
        :param layers: Default value = None)
        :param primary_key: Default value = None)
        :param force: Default value = False)
        :param debug: Default value = False)
        :param group: 

        """

        if isinstance(data_url_or_df, str):
            df = self.fetch_and_cache(data_url_or_df, force)
        else:
            df = data_url_or_df
            df = self.add_bands(df)

        self.prep_for_rasterize(df, group, layers, force)

        self.mp_rasterize(primary_key=primary_key, debug=debug)

        self.combine_rasters()

        self.clean_markers()

    @property
    def raster_frags(self):
        """ """
        return [fn for fn in self.cache.joinpath('install/hdf').glob('**/*.hd5')]

    def combine_rasters(self, mode='a'):
        """Combine all of the raster split fies into a single HDF5 file

        :param mode: Default value = 'a')

        """

        logger.debug('Combine rasters')

        # Collect the group names we will overwrite, so they can be deleted in the
        # combined raster file
        groups = set()
        for fn in self.raster_frags:
            with h5py.File(fn, 'r') as sp:
                for group_name, group in sp.items():
                    groups.add(group_name)

        with h5py.File(self.rp, mode) as f:

            # Delete the groups we will overwrite
            for group_name in groups:
                if group_name in f:
                    del f[group_name]
                    f.create_group(group_name)

            for fn in self.raster_frags:
                with h5py.File(fn, 'r') as sp:
                    for group_name, group in sp.items():  # All objects at the top level are groups

                        for band_name, band_group in group.items():
                            f.copy(band_group, group_name + '/' + band_name)

                fn.unlink()

        return self.rp

    def add_data(self, df: 'DataFrame', group: str, primary_key: str,
                 hd_f: Any = None) -> None:
        """Add a non-geographic dataset, linked to a rasterized layer. The
        values in the layer are indexes into this non-geographics dataset

        :param group: Name of group to data data to
        :param base_layer: Name of the layer to connect the primary key to, format 'group/layer'
        :param primary_key: Column in this dataset that links to the base layer
        :param df: Dataframe to load
        :param hd_f: return: None
        :param df: DataFrame':
        :param group: str:
        :param primary_key: str:
        :param hd_f: Any:  (Default value = None)
        :param df: 'DataFrame': 
        :param group: str: 
        :param primary_key: str: 
        :param hd_f: Any:  (Default value = None)
        :returns: None

        """
        import h5py
        from .raster import RasterManager

        if not '/' in primary_key:
            raise InstallException(
                f"For datasets, the primary key must be in the for 'group/layer'. Got '{primary_key}' ")

        rm = RasterManager(self.config, self.rp)

        if primary_key not in rm.layers:
            raise InstallException(f'Raster store does not have layer {primary_key}. ' +
                                   f'Has: {list(rm.index.keys())} ')

        bgroup, primary_key = primary_key.split('/')

        if primary_key not in df.columns:
            raise Exception(f"The primary key '{primary_key}' must be a column in the dataframe")

        if hd_f is None:
            hd_f = self.rp

        df = df.copy()
        if primary_key is not None:
            df = df.rename(columns={primary_key: primary_key})

        df = df.select_dtypes(include=np.number)
        # Get rid of the nullable ints, just make them ints
        df.loc[:, df.dtypes == 'Int64'] = df.loc[:, df.dtypes == 'Int64'].fillna(0).astype(int)

        frames = []

        with h5py.File(hd_f, 'r') as f:
            # Merging the data frame with the area dataset gives us the selectino f the
            # data frame that is appropriate for this band
            for band in rm.bands:
                a_key = f'{bgroup}/{band}/area'

                area = pd.DataFrame(f[a_key][:], columns=[primary_key, 'area'])
                t = area.merge(df, on=primary_key)

                data_k = f'{bgroup}/{band}/data/{group}'

                frames.append((data_k, t))
                logger.debug(f"Create band frame {data_k}, area dataframe  {a_key}")

        for k, df in frames:
            df.to_hdf(hd_f, k, mode='a', complib='zlib', complevel=9)
            logger.debug(f"Write data {k}")

        with h5py.File(hd_f, 'a') as f:
            for k, df in frames:
                logger.debug(f"Update primary key {k}.layers")
                f[k].attrs['layers'] = list(df.columns)[2:]  # [2:] to cut of primary key and 'area'

    def add_cbsa(self, df: 'DataFrame'):
        """Install the CBSA dataset. The input is a GeoDataFrame of a census CBSA TigerLine shapefile

        :param df: DataFrame':
        :param df: 'DataFrame': 

        """

        from geoid.census import Cbsa
        from .raster import RasterManager

        rm = RasterManager(self.config, self.rp)

        df = df.to_crs(4326)

        df = df.join(df.bounds)

        df.columns = [c.lower() for c in df.columns]

        df['geoid'] = df.geoid.apply(lambda v: str(Cbsa.parse(v).as_acs()))

        # Convert from GeoDataFrame to normal DataFrame
        df = pd.DataFrame(df.drop(columns=['geometry']))

        df.to_hdf(rm.rp, '/_support/cbsa', format='table', data_columns='minx miny maxx maxy'.split())

    def add_percentile(self, df: 'DataFrame'):
        """Install the percentile data. It just stuffs the dataset into the HDF file,
        with no procesing.

        :param df: DataFrame':
        :param df: 'DataFrame': 

        """
        from .raster import RasterManager

        df['pct'] = df.pct.astype(int)

        rm = RasterManager(self.config, self.rp)

        df.set_index(['pct', 'cbsa', 'weight']).to_hdf(rm.rp, '/_support/percentiles', format='table')

    def delete(self):
        """ """
        self.rp.unlink()
