import ast
from typing import Any

from demosearch.exceptions import FormulaError
from base64 import urlsafe_b64encode, urlsafe_b64decode

FORMULA_PREFIX = 'Σ'

def is_encoded_formula(formula):
    return isinstance(formula, str) and formula.startswith(FORMULA_PREFIX)

def encode_formula(formula):

    if not is_encoded_formula(formula):
        return FORMULA_PREFIX + urlsafe_b64encode(formula.encode('utf8')).decode('utf8')
    else:
        return formula

def decode_formula(formula):
    if is_encoded_formula(formula):
        return urlsafe_b64decode(formula[1:]).decode('utf8')
    else:
        return formula

class FormulaVisitor(ast.NodeVisitor):
    """ """

    def __init__(self, names=None, funcs=None, attrs=None, methods=None) -> None:
        super().__init__()

        self.funcs = funcs  # Valid functions
        self.names = names
        self.attrs = attrs
        self.methods = methods

        self.codesplit = None # Individual formula parts
        self.used_names = set()
        self.errors = set()

        self.stack = []

    def generic_visit(self, node):
        """

        :param node:

        """
        self.stack.append(node)
        super().generic_visit(node)
        self.stack.pop()

    def is_func_name(self, node):
        """

        :param node:

        """

        if not isinstance(self.stack[-1], ast.Call) or not isinstance(node, ast.Name):
            return False

        return self.stack[-1].func == node

    def is_method_name(self, node):
        """

        :param node:

        """

        if not isinstance(self.stack[-1], ast.Call) or not isinstance(node, ast.Attribute):
            return False

        return self.stack[-1].func == node

    def visit_Call(self, node):
        """
        Check that function calls are inthe methods or functions whitelists.
        :param node:

        """

        # Call func is Attribute for calls to rm._patch, the result of
        # the first substitution run
        try:
            if node.func.id not in self.funcs:
                self.errors.add(f'Unknown function call: {node.func.id}')
        except AttributeError as e:
            if node.func.attr not in self.methods:
                self.errors.add(f'Unknown method call: {node.func.attr}')

        self.generic_visit(node)

    def visit_Name(self, node):
        """
        Find layer names
        :param node:

        """
        if not self.is_func_name(node):
            if node.id not in self.names:
                self.errors.add(f'Unknown layer name: {node.id}')
            else:
                self.used_names.add(node.id)

        self.generic_visit(node)

    def visit_Attribute(self, node):
        """
        Check that atributes are in the whitelist.
        :param node:

        """
        if node.attr not in self.attrs and not self.is_method_name(node):
            self.errors.add(f'Unknown attribute name: {node.attr}')

        self.generic_visit(node)

    def visit_Tuple(self, node) -> Any:
        """Split a tuple of formulae into seperate parts"""
        import astunparse
        self.codesplit = [astunparse.unparse(n) for n in node.elts]
        self.generic_visit(node)


def parse_formula(formula, whitelist):
    """

    :param formula: param whitelist:
    :param whitelist:

    """
    import ast

    # Parse the formula to an AST
    tree = ast.parse(formula, mode="eval")

    fv = FormulaVisitor(**whitelist)

    fv.visit(tree)

    if fv.errors:
        raise FormulaError('; '.join(fv.errors))

    # Turn it back into executable code.
    return fv.used_names, fv.codesplit, compile(tree, filename="<ast>", mode="eval")


def split_formulae(x):
    """Break a tuple of formula components into seperate formula"""
    import ast

    class TupleVisitor(ast.NodeVisitor):

        def __init__(self, names=None, funcs=None, attrs=None, methods=None) -> None:
            super().__init__()
            self.formulae = None

        def visit_Tuple(self, node):
            """Split a tuple of formulae into seperate parts"""
            import astunparse
            self.formulae = [astunparse.unparse(n) for n in node.elts]
            self.generic_visit(node)

    x = x.strip().replace('\n','')

    tree = ast.parse(x, mode="eval")

    fv = TupleVisitor()

    fv.visit(tree)

    if fv.formulae is not None:
        return [s.strip() for s in fv.formulae]
    else:
        return [x]