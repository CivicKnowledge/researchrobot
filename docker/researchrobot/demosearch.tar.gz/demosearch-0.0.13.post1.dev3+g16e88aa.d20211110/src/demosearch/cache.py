# Copyright (c) 2021 Civic Knowledge. See LICENSE.txt for license details

"""A Simple interface to the object cache"""

import inspect
import pickle
from functools import wraps
from os import getenv
from pathlib import Path

import appdirs
import pandas as pd
from demosearch.exceptions import ConfigurationError

from .bunch import *
from .util import ensure_dir

ENV_NAME = 'DEMOSEARCH_CONFIG'


def cached(keyt):
    """Cache the return value of the decorated function

    :param keyt: 

    """

    def _inner(f):
        """

        :param f: 

        """

        @wraps(f)
        def wrapper(*args, **kwds):
            """

            :param *args: 
            :param **kwds: 

            """
            self = args[0]
            # Combine keyword args with position args after linking them to their names

            t_args = dict(tuple(kwds.items()) +
                          tuple((i, v) for i, v in zip(inspect.getfullargspec(f)[0], args)))
            key = keyt.format(**t_args)

            try:
                o = self.config.get(key)
            except KeyError:
                o = f(*args, **kwds)

                self.config.put(key, o)

            return o

        return wrapper

    return _inner


class ConfigFile(object):
    """Read and access a configuration file, which may be in a variety of places"""

    __redis_connection_pool = None

    appname = 'demosearch'
    appauthor = 'civick'
    config_name = 'ds_config.yaml'
    cache_env = "DS_CACHE_DIR"

    def __init__(self, path, cache=None, testing=False):

        self.cache = cache

        if path is not None:
            self.config_path = Path(path)
        else:
            self.config_path = None

        self.testing = testing

        self._redis = None
        self.redis_url = None

        assert self.config_path is not None

    def __reduce__(self):

        return (self.__class__, (self.config_path, self.cache, self.testing))

    @classmethod
    def _find_config(cls, path=None, cache_path=None):
        """Locate the configuration file among the possible locations

        :param path: Default value = None)
        :param cache_path: Default value = None)

        """

        search_path = []

        if path is not None:
            search_path.append(path)

        if cache_path is not None:
            search_path.append(Path(cache_path))
        else:
            cenv = getenv(cls.cache_env)
            if cenv and Path(cenv).is_dir():
                return cls._find_config(path=path, cache_path=cenv)

        search_path.append(Path.cwd())
        search_path.append(Path.home())
        search_path.append(Path(appdirs.user_config_dir(cls.appname, cls.appauthor)))
        search_path.append(Path(appdirs.site_config_dir(cls.appname, cls.appauthor)))

        for p in search_path:
            for cn in (p, p.joinpath(cls.config_name), p.joinpath('.' + cls.config_name)):

                if cn.exists() and cn.is_file():
                    return cn, cache_path

        return None, cache_path

    @classmethod
    def redis_cp(cls, testing=False):

        if testing:
            return None

        if cls.__redis_connection_pool is None:
            import redis
            redis_url = cls.default(testing=testing).config.redis
            cls.__redis_connection_pool = redis.ConnectionPool.from_url(redis_url, health_check_interval=15)

        return cls.__redis_connection_pool

    @classmethod
    def default(cls, testing=False):
        """

        :param testing:  (Default value = False)
        :returns: path, or the DS_CACHE_DIR env var. Looks for the cache in the configuration file,
        under the cache_path key

        """

        config_path, cache_path = cls._find_config()

        if cache_path is None and config_path is not None:
            # Locate the cache from the config file:
            cache_path = cls(config_path).config.cache_path

        if cache_path is None and config_path is None:
            raise ConfigurationError("Configuration not found and cache not specified")

        assert config_path is not None

        return ConfigFile(config_path, FileCache(cache_path), testing=testing)

    @property
    def config(self):
        """Accessor for configuration values"""

        with self.config_path.open() as f:
            return Bunch.fromYAML(f.read())

    @property
    def manager(self):
        """ """
        from .raster import RasterManager
        return RasterManager(self)

    @property
    def geocoder(self):
        """ """
        from .geocode import CachingGeocoder
        return CachingGeocoder(self)

    @property
    def redis(self):
        """ """

        if self._redis is not None:
            return self._redis

        def _real_redis():
            """ """
            # Use a real, remote redis server
            # Config should be:
            # redis:
            #   host: <host>
            #   port: <port>
            #   db: <db
            import redis

            redis_cp = ConfigFile.redis_cp(testing=self.testing)

            return redis.Redis(connection_pool=redis_cp), self.config.redis

            #redis_url = self.config.redis
            #return redis.Redis.from_url(redis_url), redis_url

        def _fake_redis():
            """Create a local redis server, running against a local file"""
            from redislite import Redis as RedisLite

            redis_url = self.cache.joinpath('redis.db')
            return RedisLite(redis_url), redis_url

        if self.testing:
            r, info = _fake_redis()
            r.flushdb()

        else:
            try:
                r, info = _real_redis()
            except (AttributeError, KeyError):
                raise
                r, info = _fake_redis()

        self._redis, self.redis_url = r, info

        return self._redis

    def __str__(self):
        return f"<ConfigFile {self.config_path} {self.cache}>"


class Config(object):
    """Configuration from the Cache"""

    def __init__(self, cache):
        self.cache = cache

    def path(self, k):
        """

        :param k: 

        """
        return 'config/' + k.strip('/') + '.pkl'

    def __setitem__(self, k, v):
        self.cache.put(self.path(k), v)

    def __getitem__(self, k):
        return self.cache.get(self.path(k))


class Cache(object):
    """ """

    def __init__(self):
        pass

    @property
    def config(self):
        """ """
        return Config(self)

    def get(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        raise NotImplemented()

    def put(self, key: str, o):
        """

        :param key: str:
        :param o: 
        :param key: str: 

        """
        raise NotImplemented()

    def exists(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        raise NotImplemented()

    def delete(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        raise NotImplemented()


def rm_tree(pth):
    """

    :param pth: 

    """
    pth = Path(pth)
    for child in pth.glob('*'):
        if child.is_file():
            child.unlink()
        else:
            rm_tree(child)
    pth.rmdir()


class FileCache(Cache):
    """ """

    def __init__(self, cache_root):
        self._cache_root = Path(cache_root)
        super().__init__()

    @property
    def root(self):
        """ """
        return self._cache_root

    def joinpath(self, *args, mkdir=False):
        """

        :param *args: 
        :param mkdir:  (Default value = False)

        """
        p = self._cache_root.joinpath(*args)
        if mkdir:
            p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def path(self, key):
        """

        :param key: 

        """
        return self._cache_root.joinpath(str(key).lstrip('/')).with_suffix('.pkl')

    def exists(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        return self.path(key).exists()

    def list(self, key='', glob='**/*'):
        """

        :param key: Default value = '')
        :param glob: Default value = '**/*')

        """
        key = key.lstrip('/')
        return list(str(e.relative_to(self._cache_root)) for e in sorted(self._cache_root.joinpath(key).glob(glob)))

    def glob(self, key, pattern):
        """

        :param key: param pattern:
        :param pattern: 

        """
        return self._cache_root.joinpath(key.lstrip('/')).glob(pattern + '.pkl')

    def get(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        try:
            with self.path(key).open('rb') as f:
                return pickle.load(f)
        except FileNotFoundError:
            raise KeyError

    def get_df(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        try:
            return pd.read_pickle(self.path(key))
        except FileNotFoundError:
            raise KeyError

    def put(self, key: str, o):
        """

        :param key: str:
        :param o: 
        :param key: str: 

        """

        ensure_dir(self.path(key))
        with self.path(key).open('wb') as f:
            pickle.dump(o, f)

    def put_df(self, key: str, df):
        """

        :param key: str:
        :param df: 
        :param key: str: 

        """

        ensure_dir(self.path(key))

        df.to_pickle(self.path(key))

    def delete(self, key):
        """

        :param key: 

        """
        from shutil import rmtree

        p = self.joinpath(key)

        if p.is_dir():
            rmtree(p)
        elif self.exists(key):
            self.path(key).unlink()

    def clean(self):
        """Delete the whole cache"""

        try:
            rm_tree(self._cache_root)
        except FileNotFoundError as e:
            pass

        self._cache_root.mkdir(parents=True, exist_ok=True)

    def __repr__(self):
        return f"<FileCache: {str(self._cache_root)}>"

    def __str__(self):
        return f"<FileCache: {str(self._cache_root)}>"


class RedisCache(object):
    """Basic cache interface, backed by redis"""

    @classmethod
    def get_redis(cls, config):
        """

        :param config: 

        """
        return cls(config.redis)

    def __init__(self, redis, config_info=None):
        self.redis = redis
        self.config_info = config_info

    def get(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """

        v = self.redis.get(key)

        if v is None:
            raise KeyError(key)

        return pickle.loads(v)

    def put(self, key: str, o):
        """

        :param key: str:
        :param o: 
        :param key: str: 

        """

        return self.redis.set(key, pickle.dumps(o))

    def set(self, key: str, o, expire=None):
        """

        :param key: str:
        :param o: 
        :param key: str: 
        :param expire:  (Default value = None)

        """

        return self.redis.set(key, pickle.dumps(o), ex=expire)

    def exists(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """

        return self.redis.exists(key)

    def delete(self, key: str):
        """

        :param key: str:
        :param key: str: 

        """
        return self.redis.delete(key)

    def list(self, prefix):
        """List cache keys, given a prefix

        :param prefix: 

        """

        return self.redis.keys(prefix + '/*')

    def clear(self, prefix):
        """

        :param prefix: 

        """
        for key in self.list(prefix):
            self.delete(key)

    def __repr__(self):
        return f"<RedisCache: {str(self.config_info)}>"

    def __str__(self):
        return f"<RedisCache: {str(self.config_info)}>"
