"""
Classes for accessing the HDF5 raster files created by the installer.
"""
__docformat__ = 'restructuredtext en'

import warnings
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import geopandas as gpd
import h5py
import numpy as np
import pandas as pd
from demosearch.exceptions import (RasterException, UnknownVariableError,
                                   UnknownLocationError, OutofBoundsError, BadArgumentError)
from demosearch.patch import (Patch, Patches)
from demosearch.constants import SMALL_PATCH_SIZE, LARGE_PATCH_SIZE, DEFAULT_RESOLUTION, MIN_PATCH_AREA_PIX
from demosearch.util import float_or_int, mk_transformers
from shapely.geometry import Point

from .formulae import decode_formula
from .geo import Location, LatLon, Utm, Bbox, UtmBbox, LatLonBbox
from .geocode import CachingGeocoder, GeocodeFailed
from .search import ftsearch
from .util import bound_to_utm_epsg

# Default value, for CBSAs that are too small.
DEFAULT_CBSA = '31000US00000'
from typing import NamedTuple


# I think this is a NamedTuple b/c is needs to be Json serializeable, but I don't recall
class UserArgs(NamedTuple):
    """Function return value, and encoded user location specification"""
    index: int  # Original index in the input array. Starts at 0
    location: tuple  # Not a location to allow to be serialized
    bbox: tuple
    band: int
    spec: str
    cbsa: "Cbsa"
    cbsa_name: str
    cbsa_geoid: str
    geohash: str = None
    marker: "MarkerPoint" = None

    def __hash__(self):
        """For general python hashing"""
        return hash((self.index, tuple(self.bbox), tuple(self.location), self.band, self.cbsa_geoid, self.spec))

    @property
    def hash_str(self):
        """For creating a unique hash key in caches"""
        import hashlib
        m = hashlib.sha256()
        m.update(
            f"{self.index}{str(self.bbox)}{str(self.location)}{self.band}{self.spec}{self.cbsa_geoid}".encode('utf8'))
        return m.hexdigest()


from collections import namedtuple

Cbsa = namedtuple('Cbsa', ['csafp', 'cbsafp', 'geoid', 'name', 'namelsad', 'lsad', 'memi', 'mtfcc', 'aland', 'awater',
                           'intptlat', 'intptlon', 'minx', 'miny', 'maxx', 'maxy'])


def _mangle_args(args, ll=False):
    """Unpack iterables and convert ndarrays, DataFrames and Series into lists

    :param args: param ll:  (Default value = False)
    :param ll:  (Default value = False)

    """

    from shapely.geometry import Point

    if isinstance(args[0], (Location, Bbox)):
        return [args[0]]

    if isinstance(args, (Location, Bbox)):
        return [args]

    if isinstance(args[0], Point):
        args = [args[0].y, args[0].x]

    if len(args) == 1:  # Unpack single arguments
        if isinstance(args[0], np.ndarray):
            args = np.ravel(args[0]).tolist()

        elif isinstance(args[0], pd.Series):
            args = args[0].tolist()

        elif isinstance(args[0], gpd.GeoDataFrame):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                args = args[0].total_bounds.tolist()

        elif isinstance(args[0], pd.DataFrame):
            args = args[0].iloc[0].tolist()

        elif isinstance(args[0], (tuple, list)):
            args = args[0]

        elif isinstance(args[0], str):
            # A search term
            return [args[0]]

    args = [float_or_int(e) for e in args]

    if ll:  # Re-order lat/lon args from x,y to y,x
        if len(args) == 4:
            args = [args[1], args[0], args[3], args[2]]
        elif len(args) == 2:
            args = [args[1], args[0]]

    return args


@dataclass
class RasterInfo(object):
    """Information class for a catalog of layers and bands in a raster file"""

    manager: "RasterManager"

    group: str
    dataset: str
    layer: str
    band: int
    path: str  # Path within the hd5 file
    bbox: Any
    area: Any

    epsg: int
    radius: int
    resolution: int
    patch_size: int
    geom_type: str
    primary_key: str = None

    def __hash__(self):
        return hash(self.path)

    def __post_init__(self):

        if self.epsg is not None:

            self._ll_to_utm, self._utm_to_ll = mk_transformers(self.epsg)
        else:
            self._ll_to_utm, self._utm_to_ll = None, None

        if self.bbox is not None:
            self._clip_utm_x = self.mk_cliper(self.bbox[0], self.bbox[2])
            self._clip_utm_y = self.mk_cliper(self.bbox[1], self.bbox[3])

            self._bbox = self.bbox

            self.bbox = UtmBbox.from_bbox(self, *self.bbox)

        else:
            self._bbox = None
            self._clip_utm_x = None
            self._clip_utm_y = None

        assert not isinstance(self._clip_utm_x, tuple)
        assert not isinstance(self._clip_utm_y, tuple)

    @staticmethod
    def mk_cliper(min_, max_):
        """

        :param min_: param max_:
        :param max_: 

        """

        def _f(v):
            """

            :param v: 

            """
            return max(min_, min(max_, v))

        return _f

    @staticmethod
    def null(lat, lon):
        """Make a Null RasterZone for doing calcs before having a real bounding box

        :param lat: param lon:
        :param lon: 

        """

        # THIS IS REALLY SLOW. Actually, just the part with making the transformers
        # in RasterInfo.__init__ is slow, but it is cached now.

        import utm
        from demosearch.utm import get_utm_bounds

        x, y, band, zone = utm.from_latlon(lat, lon)

        bbox = get_utm_bounds(lat, lon)

        epsg = 32600 + band if lat > 0 else 32700 + band

        return RasterInfo(None, 'group', 'dataset', 'layer', band, 'path', bbox, 0,
                          epsg, None, DEFAULT_RESOLUTION, None, None)

    @property
    def isnull(self):
        return self.manager is None and self.geom_type is None

    @property
    def key(self):
        """" Key for the index"""
        if self.dataset is not None:
            return f'{self.group}/{self.dataset}/{self.layer}'
        else:
            return f'{self.group}/{self.layer}'

    @property
    def keys(self):
        """All keys that can be used to lookup this entry, with band"""

        def _f():
            """ """
            if self.dataset is not None:
                return [self.key, f'{self.dataset}/{self.layer}', self.layer]
            else:
                return [self.key, self.layer]

        return _f() + [e.replace('/', '_') for e in _f()]

    def utm(self, *args, rz=None):
        """

        :param *args: 
        :param rz:  (Default value = None)

        """

        args = _mangle_args(args)

        if len(args) == 2:
            return Utm(None, *args)
        if len(args) == 4:
            return UtmBbox.from_bbox(self, *args)

    def clip_utm(self, x, y, dtype=float):
        """

        :param x: param y:
        :param dtype: Default value = float)
        :param y: 

        """

        return dtype(self._clip_utm_x(x)), dtype(self._clip_utm_y(y))

    def latlon(self, *args):
        """

        :param *args: 

        """

        args = _mangle_args(args)

        if len(args) == 1:
            return args[0].reassign(self).ll

        if len(args) == 2:
            return LatLon(self, *args)
        if len(args) == 4:
            return LatLonBbox.from_bbox(self, *args)

    @property
    def geo_record(self):
        """ """
        return self.manager.search_index(self.primary_key, self.band)

    @property
    def resolve_raster_path(self):
        """ """
        if self.geom_type == 'table':
            return self.geo_record.path
        else:
            return self.path

from demosearch.kernel import  kernels

formula_whitelist = {
    'attrs': ['wkernel', 'ukernel', 'unorm', 'zscore', 'qnorm', 'binarize',
              'kclip', 'ident', 'max', 'min', 'nanz', 'znan', 'int', 'ln', 'abs'],
    'funcs': list(kernels.keys()),
    'methods': ['convolve', 'convolve_unit', 'color', 'alpha', 'transparency', 'label',
                'map', 'epz', 'epq', 'clip', 'qclip', 'pband', 'qband',
                'gt', 'gte', 'lt', 'lte', 'round']
}


class RasterManager(object):
    """ """

    def __init__(self, config, raster_path=None, cache_raster=False):
        """
        :param config:
        :type config:
        :param raster_path:
        :type raster_path:
        :param cache_raster: If True, cache the whole band raster the first time it is read,
            rather than for each read. Runs faster if you are getting more than 100 patches on a single band.
            HOWEVER, each band can consume 1GB of memory or more.
        :type cache_raster: bool
        """
        self.nrings = 10
        self.config = config
        self.cache = config.cache
        self.cache_raster = cache_raster

        self.band_raster_cache = {}

        self.rp = raster_path if raster_path is not None else self.cache.joinpath('raster.h5')

        self.rp = Path(self.rp)

        self.resolution = DEFAULT_RESOLUTION

        self.h5_file = None  # An open HDF5 file
        self.h5_store = None  # Pandas HDF5 file object

        self.infos, self.index = self.index_h5()

        self.geocoder = CachingGeocoder(self.config)

    def index_h5(self):
        """Create an index of all of the layers in the h5 file"""

        ris = []

        if not self.rp or not self.rp.exists():
            return [], {}

        with h5py.File(self.rp, 'r') as f:
            def _f(k):
                """

                :param k: 

                """

                if k.startswith('_'):
                    return

                p = k.split('/')
                if len(p) == 2:
                    group, band = p
                    band = int(band)
                    d = dict(f[k].attrs.items())
                    del d['zone']
                    del d['layers']

                    d['epsg'] = int(d['epsg'])

                    # xc = f[k + "/x"][:]
                    # yc = f[k + "/y"][:]

                    try:
                        area = f[k + "/area"][:]
                    except KeyError:
                        area = None

                    bbox = f[k + "/coord_bbox"][:]

                    for layer in f[k].attrs['layers']:
                        path = f'{group}/{band}/layers/{layer}'
                        ris.append(RasterInfo(self, group, None, layer, band, path,
                                              bbox, area, **d))

                if len(p) == 4 and p[-2] == 'data':  # /group/band/data/dataset
                    group, band, _, dataset = p

                    geo_key = f'{group}/{band}'

                    d = dict(f[geo_key].attrs)
                    d['geom_type'] = 'table'
                    d['primary_key']: f[f'{group}/{band}'].attrs['primary_key']
                    d['epsg'] = int(d['epsg'])
                    del d['zone']
                    del d['layers']

                    bbox = f[geo_key + "/coord_bbox"][:]

                    for column in f[k].attrs['layers']:
                        path = f'{group}/{band}/data/{dataset}'

                        ris.append(RasterInfo(self, group, dataset, column, int(band), path,
                                              bbox, None, **d))

            f.visit(_f)

            idx = defaultdict(dict)

            for ri in ris:
                for key in ri.keys:
                    idx[key][ri.band] = ri

            return ris, dict(idx)



    def search_index(self, search, band=None):
        """Search the index for a layer, a layer and a group, with an optional band.
        Wil return a list of results, even if there is only one
        
        Layer is a strong that can describe the layer, layer and group,
        or other formats. possible formats are:
        
        * layer
        * group/layer
        * group/dataset/layer
        * dataset/layer
        
        * group/layer/band
        * group/dataset/layer/band
        
        
        If band is specified, returns only one entry. If band is not specified,
        returns all bands

        :param search: param band:  (Default value = None)
        :param band:  (Default value = None)

        """

        from fuzzywuzzy import process
        from itertools import chain

        try:
            g = self.index[search]
        except KeyError:
            choices = set(chain(*self.layers.values()))
            top_choices = [e[0] for e in process.extract(search, choices, limit=3) if e[1] > 60]

            if len(top_choices) > 0:
                raise UnknownVariableError(f"No variable '{search}'. Maybe you meant one of: " +
                                           ', '.join(top_choices))
            else:
                raise UnknownVariableError(f"No variable '{search}'.")

        if band is not None:
            try:
                return g[int(band)]
            except KeyError:
                raise UnknownVariableError(f"No band '{band}' for variable {search}.")

        else:
            return g

    def search_keys(self, term, band):
        """Run a search like search_index(), but instead return all of the keys
        the pbject can be access with in index

        :param term: search term
        :type term: str
        :param band: type band:
        :returns: rtype:

        """

    def is_open(self):
        """ """

        return self.h5_file is not None

    def open(self):
        """ """
        if self.h5_file is None:
            self.h5_file = h5py.File(self.rp, 'r')
            self.h5_store = pd.HDFStore(self.rp, mode='r')

        return self.h5_file

    def close(self):
        """ """

        if self.h5_file is not None:
            self.h5_file.close()
            self.h5_file = None
            self.h5_store.close()
            self.h5_store = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def latlon(self, layer, a):
        """ Make a location or bounding box from a sequence of 2 or 4 lat / lons
        :param layer: Layer name
        :type layer:
        :param a: list or tuple of 2 or 4 floats, representins lat /lon
        :type a:
        :return: LatLon or LatLonBbox
        :rtype:
        """
        from demosearch.geo import LatLon, LatLonBbox
        from demosearch.exceptions import BadArgumentError

        def _mkll(ri, a):

            if len(a) == 2:
                ll = LatLon(ri, *a)
            elif len(a) == 4:
                ll = LatLonBbox.from_bbox(ri, *a)
            else:
                raise BadArgumentError()

            return ll

        ll = _mkll(None, a)

        ri = self.search_index(layer, ll.band)

        return _mkll(ri, a)

    def ua_from_ll(self, ll, location_name=None):
        """Return a generic UserArgs object from a location or a tuple"""

        if isinstance(ll, (tuple, list)):
            ll = self.latlon('tract_id', ll)

        cbsa = self.find_cbsa(ll.center)

        return UserArgs(0,
                        list(ll),
                        None,
                        ll.band,
                        location_name if location_name is not None else str(ll),
                        cbsa,
                        cbsa.name,
                        cbsa.geoid,
                        ll.to_geohash())

    @property
    def groups(self):
        """


        :returns: the default list if there are none specified

        """

        groups = []

        with h5py.File(self.rp, 'r') as f:
            for n, group in f.items():
                if group.attrs.get('group_type') == 'raster':
                    groups.append(n)

            if len(list(f.keys())) > 0 and len(groups) == 0:
                # Raster has data, but they aren't marked for their groups,
                # so return legacy values
                return ['tracts', 'lines', 'osm_points', 'extra_points']

        return groups

    @property
    def bands(self):
        """ """
        keys = set()

        def _f(k):
            """

            :param k: 

            """
            p = k.split('/')
            if len(p) == 2:
                try:
                    keys.add(int(p[1]))
                except ValueError:
                    pass

        with h5py.File(self.rp, 'r') as f:
            f.visit(_f)
            return keys

    @property
    def layers(self):
        """ """

        d = {}

        for ri in self.infos:
            d[ri.key] = ri.keys

        return d

    @property
    @lru_cache(maxsize=50)
    def flat_layers(self):
        """Layer names that can be used in formulas"""
        from itertools import chain

        return list(set([e for e in chain(*self.layers.values())]))

    @property
    @lru_cache(maxsize=50)
    def formula_layers(self):
        """Layer names that can be used in formulas"""
        from itertools import chain
        return list(sorted(set([e for e in chain(*self.layers.values()) if '/' not in e])))

    @property
    @lru_cache(maxsize=50)
    def formula_layer_groups(self):
        """Layer names that can be used in formulas, organized into groups"""

        from collections import defaultdict
        s = defaultdict(set)
        for e in self.infos:
            s[e.group].add(sorted(e.keys, key=len)[0])

        for k, v in s.items():
            s[k] = list(sorted(v))

        return s

    @property
    def weight_names(self):
        """Names of all of the weights in the kernel data frame"""
        from .kernel import kernel_df
        return [c for c in kernel_df if c.startswith('w_')]

    def weights(self, name):
        """Returned weights from the weight kernel dataframe"""

        from .kernel import get_weights

        return get_weights(name)

    def ftsearch(self, query):
        """

        :param query: 

        """

        return pd.DataFrame(ftsearch(self.cache, query))

    @contextmanager
    def hdf_read(self, path):
        """A context manager accessing a path in the HDF file, which
        will not re-open the file if it is already open, so calls can be nested

        :param path: 

        """

        do_close = False
        try:
            # Open the file if it is not open, and if we open it here,
            # remember to close it at the end.
            if not self.is_open():
                self.open()
                do_close = True

            yield self.h5_file[path]

        finally:
            if do_close:
                self.close()

    def _get_raster_slice(self, raster_path: str, slc: slice):
        """ Return a slice of a band raster, possibly caching the whole band raster
        :param slc:
        :type slc:
        :return:
        :rtype:
        """

        if self.cache_raster is False:
            with self.hdf_read(raster_path) as f:

                if slc:
                    try:

                        raster = f[slc]
                    except Exception as e:
                        raise RasterException(f"Read on H5py file {raster_path} failed, for slice {slc}: {e}")
                else:
                    raster = f[:]

            return raster

        else:

            k = raster_path

            if not k in self.band_raster_cache:
                with self.hdf_read(raster_path) as f:
                    self.band_raster_cache[k] = f[:]

            if slc:
                return self.band_raster_cache[k][slc]
            else:
                return self.band_raster_cache[k]

    @lru_cache(maxsize=50)
    def get_raster(self, raster_path, bbox=None):
        """

        :param raster_path: param bbox:  (Default value = None)
        :param bbox:  (Default value = None)

        """
        # bbox is the tuple conversion of the PixBbox
        # not the slice, because slices are not hashable, as required by lru_cache
        if bbox is None:
            slc = None
        else:

            if isinstance(bbox, Bbox):
                bbox = list(bbox)

            slc = slice(*bbox[1::2]), slice(*bbox[0::2])



        return self._get_raster_slice(raster_path, slc)

    def process_location_arg(self, arg, layer=None, geocode=True, throw=True):
        """Handle names of metros and lat/lon coordinates, turning them into
        either Locations or Bboxes

        :param cache:
        :param arg:
        :return: A Location or Bbox

        """
        from demosearch.geo import Location, Bbox, is_geohash, decode_geohash
        import re

        if layer is None:
            # We need to have a layer to work with . Tract_id is preferred, but
            # doesn't have to exist.
            try_layers = ['tract_id', self.flat_layers[0]]

            for layer in try_layers:
                if layer in self.flat_layers:
                    break

        if layer is None:
            raise BadArgumentError(
                'process_location_args needs a layer name, and the default, tract_id, does not exist')

        def _f(arg, layer, geocode):

            if isinstance(arg, UserArgs):
                # UserAgs holds the location as a tuple, so extract
                # it and let a
                arg = arg.location

            # Is it already a location or bounding box?
            if isinstance(arg, (Location, Bbox)):
                return arg.ll

            # It is already a tuple of lat, lon?
            if isinstance(arg, (list, tuple)):
                if len(arg) == 2:
                    return self.latlon(layer, arg)
                elif len(arg) == 4:
                    return self.latlon(layer, arg)
                else:
                    raise ValueError(f'Sequence must have 2 or 4 elements; got {len(arg)}')

            # Is it a name of a CBSA or metro?
            try:
                search = ftsearch(self.cache, arg)[0]
                return LatLonBbox.from_bbox(None, *search.bb)

            except (IndexError, TypeError):
                pass

            # is it a lat,lon position as a string?
            try:
                p = re.compile(r'\s*(-?\d+.\d+)\s*,\s*(-?\d+.\d+)')
                g = p.match(arg)
                a = [float(e) for e in g.groups()]

                return LatLon(None, *a)
            except (AttributeError, TypeError):
                pass


            if isinstance(arg, Point):
                return self.latlon(layer, (arg.y, arg.x))

            # Maybe a geohash?
            if is_geohash(arg):
                ll = decode_geohash(arg)

                return self.latlon(layer, ll)

            if geocode:
                try:
                    r = self.geocoder.geocode(arg)

                    return LatLonBbox.from_dict(None, r['bbox'])
                except KeyError:  # Geocoder didn't return a bbox
                    return LatLon(None, r['lat'], r['lng'])
                except OutofBoundsError as e:

                    raise OutofBoundsError(f" Arg '{arg}' geocoded to out of bounds with " +
                                           f" geocoder '{r['_geocoder']}': {str(e)}")
                except GeocodeFailed:
                    pass

            raise UnknownLocationError(f'Could not interpret location input "{arg}" ')

        def _p():
            p = _f(arg, layer, geocode)

            # Always resign, because the layer may have changed

            raster_info = self.search_index(layer, p.band)
            p = p.reassign(raster_info)

            # If it is too small to be a sensible patch, convert it
            # to a point, and the default patch size will be used later.
            if isinstance(p, Bbox) and p.pix.area < MIN_PATCH_AREA_PIX:
                p = p.center

            return p

        if throw:
            return _p()
        else:
            try:
                return _p()
            except Exception as e:
                return e

    def geocode_user_args(self, lines, return_errors=False):
        """Identify the location and CBSA name for each of the user input lines in lines

        The function is a front-end to process_location_arg that also handles
        parallel geocoding and cache the whole set of input addresses in the Geocoder cache

        Elements of line may be:
        
        * A CBSA or Metro name
        * A lat/lon position
        * A geocodable address
        
        The response is a list of UserArgs objects

        :param lines: 

        """

        from demosearch.exceptions import DataNotFound
        from demosearch.geo import LatLon
        import hashlib

        def rtrn_val(rv, err=[]):
            """Adjust return value depending on need to return errors"""
            if return_errors:
                return rv, err
            else:
                return rv

        if isinstance(lines, (UserArgs, str, Point, Bbox, Location)):  # Just one UserArgs
            lines = [lines]

        # It's already a list of User Args
        if isinstance(lines, (tuple, list)) and len(lines) > 0 and isinstance(lines[0], UserArgs):
            return rtrn_val(lines)

        if isinstance(lines, str) and '\n' in lines:
            lines = [e.strip() for e in lines.splitlines()]

        errors = []
        iresults = []
        geocode_args = []

        if not lines or len(lines) == 0:
            return rtrn_val([])

        # Hash all of the lines to check if the response is cached
        # in the gc_cache. This hashes and stores the *entire collection*
        # of lines. The caching geocoder also caches addresses it geocodes, but
        # this caching here can sort-circuit an arbitarily large
        # set of addresses all at once.
        hasher = hashlib.sha256()
        for l in lines:
            hasher.update(str(l).encode('utf8'))

        gc = self.geocoder

        lines_key = f'{gc.user_cache_prefix}/{hasher.hexdigest()}'

        if self.geocoder.gc_cache.exists(lines_key):
            return rtrn_val(self.geocoder.gc_cache.get(lines_key), errors)

        # Process metro names and coordinated, collecting arguments
        # that will require geocoding, for later batch processing.
        for i, line in enumerate(lines):

            if isinstance(line, str) and not line.strip():
                continue

            try:
                r = self.process_location_arg(line, geocode=False)
                iresults.append((i, r))
            except UnknownLocationError as e:

                # Couldn't interpret without geocoding, so save it for geocoding
                geocode_args.append((i, line))

        # multi-process geocode

        for gr in gc.multi_geocode(geocode_args):
            try:
                iresults.append((gr['_enum'], LatLon(None, gr['lat'], gr['lng'])))
            except OutofBoundsError as e:
                errors.append((e, gr))

        # Sort the results, re-attache the original input,
        # and add the CBSA information
        results = []
        for i, p in sorted(iresults, key=lambda e: e[0]):
            try:
                cbsa = self.find_cbsa(p.center)
                cbsa_name = cbsa.name
                cbsa_geoid = cbsa.geoid
            except DataNotFound:
                cbsa_name = 'Non metro area'
                cbsa_geoid = DEFAULT_CBSA

            results.append(UserArgs(i,
                                    list(p.center.ll),
                                    list(p) if isinstance(p, Bbox) else None,
                                    p.band,
                                    lines[i] if not isinstance(lines[i], (Location, Bbox)) else str(list(lines[i])),
                                    cbsa,
                                    cbsa_name,
                                    cbsa_geoid,
                                    p.center.ll.to_geohash()))

        self.geocoder.gc_cache.set(lines_key, results, 60 * 60 * 4)

        return rtrn_val(results, errors)

    def process_layer_args(self, arg):
        """  Process Layer Arguments, returning a set of tuples
        describing each of arguments

        :param arg:
        :type arg:
        :return:
        :rtype:
        """
        from .exceptions import BadArgumentError
        from itertools import chain
        from .formulae import is_encoded_formula, split_formulae

        def _pa(arg):
            if arg is None:
                return self.process_layer_args(['total_population'])

            if is_encoded_formula(arg):
                arg = decode_formula(arg)

            def is_not_formula(s):
                """Return true if the string has no characters that would indicate a formula"""
                import re
                return re.match(r'^[\w\_\,\s]*$', s) is not None

            if isinstance(arg, str):
                if is_not_formula(arg):
                    parts = arg.split(',')  # Can split non formulas simply
                else:
                    parts = split_formulae(arg)  # Requires language-awareness to split formulas

                r = [('l', e) if is_not_formula(e) else ('f', e) for e in parts]

            else:
                try:
                    arg = list(arg)  # Is this a sequence
                except Exception as e:
                    raise BadArgumentError(f"Thought arg would be a sequence, instead got a {type(arg)}; {str(e)}")

                if not all(isinstance(e, str) for e in arg):
                    raise BadArgumentError(
                        f"Not all elements in sequence arg are strings: got: {[type(e) for e in arg]}")

                r = list(chain(*[_pa(e) for e in arg]))

            return r

        layers = self.formula_layers

        def _check_layer(e):

            if e[0] == 'l':
                if e[1] in layers:
                    return e
                else:
                    return ('e', e[1])  # Signal an error
            else:
                return e

        r = [_check_layer(e) for e in _pa(arg)]

        # split errors from non errors
        return [e for e in r if e[0] != 'e'], [e for e in r if e[0] == 'e'],

    def exec_formula(self, latlon, formula, size=None):
        """Parse a formula to return one or more patches.

        :param latlon: param formula:
        :param formula:

        """
        from demosearch.formulae import parse_formula, encode_formula

        # Formulas use large patch size so that convolutions will return correct
        # results at the boundaries.
        size = size if size is not None else LARGE_PATCH_SIZE

        whitelist = dict(formula_whitelist.items())
        whitelist['names'] = self.formula_layers

        formula = formula.strip()

        # Parse the formulas into the layer names that go into the formulas,
        # and the code to generate the formauls from those patches.
        names, parts, code = parse_formula(formula, whitelist)

        # Load the patches used in the formulas into the environment
        env = {name: self.patch(latlon, name, size=size) for name in names}
        env.update(kernels)

        # Evaluate the code, which returns a set of patches. The formulas are all defined
        # as operations on patches, so the results will all be patches.

        p = eval(code, {}, env)

        # the SIGMA character introduces formula strings
        p = p.update(layer_type='f',
                     name=encode_formula(formula),
                     layer_name=formula,
                     size=0,
                     )
        return p

    # @lru_cache(maxsize=100)
    def patch(self, arg, layer, size=None):
        """Return a patch for a single location and one layer. THey layer may be specified as a formula

                :param latlon: Location information. A point or a bounding box or a search string for CBSAs
                :type latlon: A location as a 2-tuple or Location object, or a bounding
            box as a 4-tuple or Bbox object, or a search string for a CBSA.
                :param formula: A python formula for fetching patches.
                :type formula: str
                :returns: If formula returns a tuple or list, function returns a Patches object. Otherwize
                    returns a Patch
                :rtype: Patch or demosearch.patch.Patches

                """

        # We frequently get ConnectionResetError: [Errno 54] Connection reset by peer
        # errors when using the system from Jupyter. Maybe a retry will fix it?

        try:
            return self._patch(arg, layer, size)
        except ConnectionResetError:
            return self._patch(arg, layer, size)

    def _patch(self, arg, layer, size=None):

        from .kernel import align_to_kernel, k_r

        if isinstance(arg, UserArgs):
            ua = arg
            if ua.bbox is not None:
                arg = ua.bbox
            else:
                arg = ua.location
        else:
            ua = None

        if isinstance(layer, tuple):  # Tuple indicates already processed
            layer_args = layer
        else:

            layer_args, layer_errors = self.process_layer_args(layer)

            if layer_errors:
                raise UnknownVariableError(f"Bad layer spec: {layer}")

            if len(layer_args) > 1:
                raise BadArgumentError(f"patch() should get only one layer. Got {len(layer_args)}")

            layer_args = layer_args[0]

        if layer_args[0] == 'l':  # A layer name, not a formula

            size = size if size is not None else SMALL_PATCH_SIZE

            loc = self.process_location_arg(arg, layer_args[1], geocode=True)

            if isinstance(loc, Bbox):
                bbox = loc.pix
            else:
                bbox = loc.pix.patch(size)

            raster = self.get_raster(loc.raster_info.resolve_raster_path, bbox)

            # For too-small rasters
            #raster = align_to_kernel(raster, k_r())
            #bbox = loc.center.utm.patch()
            #loc = bbox.center

            p = Patch(layer_args[1], loc.raster_info, loc=loc, bbox=bbox, raster=raster,
                         location_info=ua)
        else:

            size = size if size is not None else LARGE_PATCH_SIZE

            loc = self.process_location_arg(arg, geocode=True)

            assert layer_args[0] == 'f', layer_args[0]
            p = self.exec_formula(loc, layer_args[1], size=size).replace(location_info=ua)

        return p

    def _coalesce_arguments(self, args, layers):

        from itertools import product

        # Process a wide variety of arguments that specify one or more locations
        uargs, location_errors = self.geocode_user_args(args, return_errors=True)

        layer_args, layer_errors = self.process_layer_args(layers)

        pargs = list(product(uargs, layer_args))

        return pargs, location_errors, layer_errors

    def coalese_arguments(self, args, layers):

        pa, location_errors, layer_errors = self._coalesce_arguments(args, layers)

        pa = [{'location_info': location_info, 'layer_spec': layer_spec}
              for location_info, layer_spec in pa]

        return {
            'pa': pa,
            'location_errors': location_errors,
            'layer_errors': layer_errors
        }

    def patches(self, args, layers, size=None, errors='warn', add_summary=False):
        """
        :param args: String|List Argument or argument specifying the location
        :type args:
        :param size: Default value = 100)
        :param layers:  (Default value = None)
        :param return_exc:
        :type return_exc:

        """

        from .exceptions import FormulaError

        pa, location_errors, layer_errors = self._coalesce_arguments(args, layers)

        do_close = not self.is_open()  # DOn't close if we were opened previously.

        try:
            self.open()

            patches = []
            for location_info, layer_spec in pa:
                try:
                    p = self.patch(location_info, layer_spec, size=size)
                    p = p.update(location_info=location_info, layer_name=layer_spec[1])
                    patches.append(p)
                except FormulaError as e:
                    layer_errors.append(('e', e))
                except UnknownVariableError as e:
                    # Layer doesn't exist, or there is no data for that variable in the required band
                    layer_errors.append(('e', e))

        finally:
            if do_close:
                self.close()

        if errors is None or errors == 'ignore':
            patches = Patches(patches)
        elif errors == 'warn':
            for e in location_errors:
                warnings.warn("Location error: " + str(type(e[1])) + ": " + str(e[1]))

            for e in layer_errors:
                warnings.warn("Location error: " + str(type(e[1])) + ": " + str(e[1]))

            patches = Patches(patches, add_summary=add_summary)

        elif errors == 'return':
            patches = Patches(patches, add_summary=add_summary), location_errors, layer_errors
        else:

            if len(location_errors + layer_errors) > 0:  #

                error_strs = \
                    ';'.join(["Layer Error: " + str(e[1]) for e in (layer_errors)]) + \
                    ';'.join(["Location Error: " + str(e[1]) for e in (location_errors)])

                raise RasterException(error_strs)

            patches = Patches(patches, add_summary=add_summary)

        return patches

    def predict(self, latlon, params, name='predict'):
        """Given parameters from a linear model, fetch the layers defined by the
        index of the params multiply the paramsters, and produce a new raster with the prediction

        :param params: type params:
        :param latlon: param name:  (Default value = 'predict')
        :param name:  (Default value = 'predict')
        :returns: rtype:

        """

        layers = list(params.index)

        if 'const' in layers:
            const = True
            layers.remove('const')
            cols = ['const'] + layers
        else:
            const = False
            cols = layers

        patches = self.patches(latlon, layers=layers)

        r = (patches.ravel(const) * params[np.newaxis, :]).sum(axis=1).reshape(patches[0].raster.shape)

        return patches[0].replace(name=name, raster=r)

    @lru_cache()
    def find_cbsa(self, loc: Location):
        """

        :param loc: Location:
        :param loc: Location: 
        :returns: is in multiple bounding boxes, return the largest.

        """

        try:
            pos = list(loc.ll.center)
        except AttributeError:
            # Hopefully a tuple or list, already in the right format.
            pos = loc

        t = pd.read_hdf(self.rp, '/_support/cbsa',
                        where=[f"(minx<={pos[1]}) & (maxx >= {pos[1]}) & (miny<={pos[0]}) & (maxy >= {pos[0]})"])

        rows = t.sort_values('aland', ascending=False)

        if len(rows) > 0:
            return Cbsa(**rows.iloc[0].to_dict())
        else:
            from .exceptions import DataNotFound
            raise DataNotFound(f"CBSA List has no records for position '{str(loc)}' ")

    @lru_cache()
    def percentiles(self, cbsa, weight_name='w_zero'):
        """

        :param cbsa: 

        """

        try:
            return pd.read_hdf(self.rp, '/_support/percentiles',
                               where=[f"(cbsa=='{cbsa}')", f"(weight=='{weight_name}')"])
        except KeyError:
            from .exceptions import DataNotFound
            raise DataNotFound(f"Did not find a percentiles file")
        except ValueError:
            raise

    @lru_cache()
    def get_data(self, key, band, area_norm=False):
        """

        :param key: param band:
        :param area_norm: Default value = False)
        :param band: 

        """

        ri = self.search_index(key, band)

        assert ri.geom_type == 'table'

        if self.is_open():  # Don't need to re-open the file if it is already open
            data = pd.read_hdf(self.h5_store, ri.path)
        else:
            data = pd.read_hdf(self.rp, ri.path)

        if area_norm is True:
            area = data['area']
            r2 = ri.resolution ** 2

            t = data.iloc[:, 2:].divide(area, axis=0) * r2
            t = t.replace([np.inf, -np.inf], np.nan)

            data.iloc[:, 2:] = t

        return data



    def rasterize(self, group_name, g, resolution=DEFAULT_RESOLUTION):
        """

        :param group_name: param g:
        :param resolution: Default value = 100)
        :param g: 

        """
        rzi = RasterZoneInstaller.rasterize(group_name, g, resolution=resolution)
        rzi.write(self.rp)
        return rzi


class RasterZoneInstaller(object):
    """Rasterize a geo vector data and write ther results to an HDF file"""

    def __init__(self, group_name, epsg, xa, bbox, geom_type,
                 primary_key=None, area=None, resolution=DEFAULT_RESOLUTION):

        x = xa.coords['x']
        y = xa.coords['y']
        radius = 10_000

        self.bbox = bbox

        self.group_name = group_name
        self.utm_band = str(epsg)[-2:]
        self.epsg = epsg
        self.xa = xa
        self.resolution = resolution

        self.primary_key = primary_key
        self.area = area

        self.radius = radius
        self.patch_size = int(radius / resolution)
        self.coord_bbox = (x.min(), y.min(), x.max(), y.max())

        self._ll_to_utm, self._utm_to_ll = mk_transformers(self.epsg)

        self.geom_type = geom_type

    def write(self, file_path):
        """

        :param file_path: 

        """
        utm_band = self.utm_band  # Actually the utm band, not the zone.
        group_name = self.group_name

        with h5py.File(file_path, 'a') as f:

            group_key = f"{group_name}/{utm_band}"

            if group_key in f:
                del f[group_key]

            g = f.create_group(group_key)

            g.attrs['zone'] = self.utm_band
            g.attrs['epsg'] = self.epsg
            g.attrs['radius'] = self.radius
            g.attrs['resolution'] = self.resolution
            g.attrs['patch_size'] = self.patch_size
            g.attrs['layers'] = list(self.xa.keys())
            g.attrs['geom_type'] = self.geom_type
            g.attrs['primary_key'] = str(self.primary_key) if self.primary_key else ''

            f.create_dataset(f"{group_key}/coord_bbox", compression="gzip",
                             data=self.coord_bbox)
            dsx = f.create_dataset(f"{group_key}/x", compression="gzip", compression_opts=9,
                                   data=self.xa.coords['x'].values)
            dsy = f.create_dataset(f"{group_key}/y", compression="gzip", compression_opts=9,
                                   data=self.xa.coords['y'].values)

            if self.area is not None:
                f.create_dataset(f"{group_key}/area", compression="gzip", compression_opts=9,
                                 data=self.area)

            for layer_name, layer in self.xa.items():
                dsti = f.create_dataset(f"{group_key}/layers/{layer_name}", compression="gzip",
                                        compression_opts=9, data=layer)

                dsti.dims[0].label = 'y'
                dsti.dims[0].attach_scale(dsy)
                dsti.dims[1].label = 'x'
                dsti.dims[1].attach_scale(dsx)

            f[group_name].attrs['group_type'] = 'raster'

    @classmethod
    def rasterize(cls, group_name, g, resolution=DEFAULT_RESOLUTION, primary_key=None):
        """Rasterize a pandas dataset. The dataset have have these columns
        
            geometry
            one or mor numeric columns
        
            It must not have any numeric columns that you don't want rasterized

        :param group_name: param g:
        :param resolution: Default value = 100)
        :param primary_key: Default value = None)
        :param g: 

        """

        from geocube.api.core import make_geocube

        # Figure out what columns to rasterize, numeric columns only, and
        # exclude some support columns
        measurements = set(g.select_dtypes(include=np.number).columns.tolist()) - \
                       {'band', 'zone', 'epsg', 'geometry'}

        # In 4326, so find the UTM band of the centroid, and
        # convert to the corresponding UTM CRS

        if g.crs.to_epsg() == 4326:

            epsg = bound_to_utm_epsg(g)
            g = g.to_crs(epsg)

        # Already in UTM
        elif g.crs.to_epsg() // 100 in (326, 327):

            epsg = g.crs.to_epsg()
        else:
            raise RasterException(f"Dataframe CRS is not UTM or 4326. Got: EPSG:{g.crs.to_epsg()}")

        g.loc[:, g.dtypes == 'Int64'] = g.loc[:, g.dtypes == 'Int64'].fillna(0).astype('int32')

        if primary_key:
            t = g[[primary_key, 'geometry']].copy()
            t['area'] = t.area
            area = t[[primary_key, 'area']].astype(np.uint32)
        else:
            area = None

        rast = make_geocube(vector_data=g, resolution=(resolution, resolution),
                            measurements=measurements)

        bbox = g.total_bounds
        gt = g.iloc[0].geometry.geom_type

        rzi = cls(group_name, epsg, rast, bbox, gt, primary_key, area, resolution)

        return rzi
