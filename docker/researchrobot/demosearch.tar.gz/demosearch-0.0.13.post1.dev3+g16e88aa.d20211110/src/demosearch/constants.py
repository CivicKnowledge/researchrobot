KERNEL_SIZE = 100  # In pix. Actual kernel is 2*KERNEL_SIZE + 1, so there is a single pix in the center
SMALL_PATCH_SIZE = KERNEL_SIZE  # FOr layer pateches that will not be convolves
LARGE_PATCH_SIZE = 200  # 100 cells 8 100m / cell == 10KM # For layers that will be convolved
DEFAULT_RESOLUTION = 100
MIN_PATCH_AREA_PIX = ((KERNEL_SIZE * 2) + 1) ** 2  # In pixels
MIN_PATCH_AREA = MIN_PATCH_AREA_PIX * (DEFAULT_RESOLUTION ** 2)  # In meters
SUMMARY_ADDRESS = 'Summary'