from functools import lru_cache
from multiprocessing import Pool, cpu_count
from pathlib import Path
from timeit import default_timer
import numpy as np


import libgeohash as gh
from auto_tqdm import tqdm

from pyproj import Transformer

from shapely.wkt import loads, dumps
import geopandas as gpd
import pandas as pd

_base32 = '0123456789bcdefghjkmnpqrstuvwxyz'

_basemap = {}
for i in range(32):
    _basemap[_base32[i]] = i

from contextlib import contextmanager


@contextmanager
def nope_maybe():
    """Use AppNope if it is available"""
    try:
        import appnope
        with appnope.nope_scope():
            yield
    except ImportError:
        yield


def gh_to_int(ghc):
    """

    :param ghc: 

    """
    return sum(_basemap[c] * 32 ** i for i, c in zip(range(12, 0, -1), ghc))

def extrema(s):
    """

    :param s: 

    """
    return np.min(s), np.max(s)

def disaggregate(ghashes, level):
    """Break up a list of geohashes into hashes of the same level

    :param ghashes: param level:
    :param level: 

    """

    for gh in ghashes:
        if len(gh) == level:
            yield gh
        elif len(gh) > level:
            yield gh[:level]
        else:  # len(gh) < level
            yield from disaggregate([gh + c for c in _base32], level)

def run_mp(f, tasks, desc='', n_cpu=None, debug=False):
    """Run a function in multiple processes and return the results as a list
    displays a progress bar

    :param f: param tasks:
    :param desc: Default value = '')
    :param n_cpu: Default value = None)
    :param debug: Default value = False)
    :param tasks: 

    """
    from joblib import Parallel, delayed
    from multiprocessing import cpu_count

    if n_cpu is None:
        n_cpu = cpu_count() - 2

    if debug is True:
        results = []
        for t in tqdm(tasks, desc=desc):
            results.append(f(*t))
        return results
    else:
        return Parallel(n_jobs=n_cpu)(delayed(f)(*t) for t in tqdm(tasks, desc=desc))


def get_cache():
    """ """


def _gh_to_int(s):
    """Convert a geohash into a number

    :param s: 

    """
    v = 0
    for i, c in enumerate(s):
        v += _base32.index(c) * 32 ** i

    return v


def gh_to_int(s):
    """

    :param s: 

    """
    if isinstance(s, str):
        return _gh_to_int(s)
    else:
        return [_gh_to_int(e) for e in s]


def gh_data_path(ghash, *args):
    """

    :param ghash: param *args:
    :param *args: 

    """
    return gh_path('data', ghash, *args)


def gh_path(prefix, ghash, *args):
    """

    :param prefix: param ghash:
    :param ghash: 
    :param *args: 

    """
    return prefix + '/' + '/'.join([ghash[:2], ghash[2:4]] + list(args))


def ensure_dir(path):
    """

    :param path: 

    """
    if not path.parent.exists():
        path.parent.mkdir(parents=True)


class Timer(object):
    """ """
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.timer = default_timer

    def __enter__(self):
        self.start = self.timer()
        return self

    def __exit__(self, *args):
        end = self.timer()
        self.elapsed_secs = end - self.start
        self.elapsed = self.elapsed_secs * 1000  # millisecs
        if self.verbose:
            print(f'elapsed time: {self.elapsed} ms')


def munge_pbar(progress_bar):
    """

    :param progress_bar: returns: and for anything else, use the input
    :returns: and for anything else, use the input

    """
    from auto_tqdm import tqdm

    def null_pbar(itr, *args, **kwargs):
        """

        :param itr: param *args:
        :param *args: 
        :param **kwargs: 

        """
        return itr

    if progress_bar is None:
        return null_pbar
    elif progress_bar is True:
        return tqdm
    else:
        return progress_bar


def expand_to_gh4(lat, lon=None):
    """

    :param lat: param lon:  (Default value = None)
    :param lon:  (Default value = None)
    :returns: Code a lat/lon to a 5 digit geohash, expand twice, and return the 4 digit prefixes.

    """

    if lon:
        ghc = gh.encode(lat, lon, 5)
    else:
        ghc = lat[:5]

    return list(sorted(set([e[:4] for e in gh.expand(ghc, 2)])))


def df_to_geo(df, crs=4326):
    """Convert a dataframe with a geometry column with WKT geometries into a GeoPandas GeoDataFrame

    :param df: param crs:  (Default value = 4326)
    :param crs:  (Default value = 4326)

    """



    t = df.copy()
    t['geometry'] = t.geometry.apply(loads)

    return gpd.GeoDataFrame(t, crs=crs)

def geo_to_df(gdf, crs=None):
    """

    :param gdf: param crs:  (Default value = None)
    :param crs:  (Default value = None)

    """

    if crs is not None:
        t = pd.DataFrame(gdf.to_crs(crs), copy=True)
    else:
        t = pd.DataFrame(gdf, copy=True)

    t['geometry'] = pd.Series(list(t.geometry.apply(dumps)))

    return t


def resfloor(v, resolution):
    """Return the floor of a UTM value, rounded down to the resoution

    :param v: type v:
    :param resolution: Size of a pixel, in meters
    :type resolution: return:
    :returns: rtype:

    """
    return np.floor(v / resolution) * resolution


def resceil(v, resolution):
    """Return the ceiling of a UTM value, rounded down to the resoution

    :param v: type v:
    :param resolution: type resolution:
    :returns: rtype:

    """
    return np.ceil(v / resolution) * resolution



# From https://stackoverflow.com/a/47171600
def replace_with_dict(ar, dic):
    """Replace values in a numpy array according to a dict

    :param ar: param dic:
    :param dic: 

    """
    # Extract out keys and values

    dic[np.nan] = np.nan

    k = np.array(list(dic.keys()))
    v = np.array(list(dic.values()))

    # Get argsort indices
    sidx = k.argsort()

    ks = k[sidx]
    vs = v[sidx]

    return vs[np.searchsorted(ks, ar)]

def bound_to_utm_epsg(g):
    """

    :param g: returns: of a collections of shapes in a GeoDataFrame
    :returns: of a collections of shapes in a GeoDataFrame

    """

    import utm
    lat, lon = np.mean(g.total_bounds[1::2]), np.mean(g.total_bounds[::2])

    band = utm.from_latlon(lat, lon)[2]

    if lat > 0:
        return 32600 + band
    else:
        return 32700 + band


def _mean_road_length(resolution):
    """Find the mean linear length of a road that runs through a 100x100 cell

    :param resolution: 

    """
    from numpy.random import randint

    # Create points that lie on on a 100x100 square
    p = np.array([(randint(0, 2) * resolution, randint(0, resolution)) if randint(0, 2)  # x<-{0,100} --> left and right edge
                  else (randint(0, resolution), randint(0, 2) * resolution)  # y<-{0,100} --> top and bottom edge
                  for i in range(50000)])

    x = np.hstack(np.split(p, 2))  # Reshape to 4 cols, x1,y1,x2,y2
    x = x[(x[:, 0] != x[:, 2]) & (x[:, 1] != x[:, 3])]  # Remove rows that are on same side
    return np.mean(np.sqrt(np.square(x[:, 0] - x[:, 2]) + np.square(x[:, 1] - x[:, 3])))


def raster_transform(xmin, ymin, xmax, ymax, resolution):
    """

    :param xmin: param ymin:
    :param xmax: param ymax:
    :param resolution: 
    :param ymin: 
    :param ymax: 

    """
    from rasterio.transform import from_origin
    xmin, ymin, xmax, ymax = (resfloor(xmin, resolution), resfloor(ymin, resolution),
                              resceil(xmax, resolution), resceil(ymax, resolution))

    return from_origin(xmin, ymin, resolution, -resolution)


def float_or_int(v):
    """

    :param v: 

    """
    if round(float(v)) == float(v):
        return int(v)
    else:
        return float(v)


def _is_utm(*args):
    """Try to determine if a Location or Bounding box is in Lat/Lon ot UTM.
    Returns True if the arguments are likely to be in UTM

    :param *args: 

    """

    if any(int(e) > 180 or int(e) < -180 for e in args):
        return True

    if all(isinstance(e, int) for e in args):
        return True

    return None  # Not False. We just don't know


def nn(o):
    """Convenience for nan_to_num

    :param o: 

    """
    return np.nan_to_num(o)

def infnan(o):
    """ Convert inf to nan
    :param o:
    :type o:
    :return:
    :rtype:
    """
    o[np.isinf(o)] = np.nan
    return o


@lru_cache()
def mk_transformers(epsg):
    """

    :param epsg: 

    """
    return Transformer.from_crs(4326, epsg), Transformer.from_crs(epsg, 4326)

def signif(x, p):
    """Round to significant digits.
    From https://stackoverflow.com/a/59888924"""
    x = np.asarray(x)
    x_positive = np.where(np.isfinite(x) & (x != 0), np.abs(x), 10**(p-1))
    mags = 10 ** (p - 1 - np.floor(np.log10(x_positive)))
    return np.round(x * mags) / mags


class CallContainer(object):
    """Hold a list of callables, and calls each with the same parameters"""

    def __init__(self, objs, return_class, **kwargs):
        self.objs = objs
        self.kwargs = kwargs
        self.return_class = return_class

    def __call__(self, *args, **kwargs):
        return self.return_class([e(*args, **kwargs) for e in self.objs], **self.kwargs)


def truncate_elip(content, length=100, suffix='...'):
    """Truncate at words and add elipses"""
    return content if len(content) <= length else content[:length].rsplit(' ', 1)[0]+suffix