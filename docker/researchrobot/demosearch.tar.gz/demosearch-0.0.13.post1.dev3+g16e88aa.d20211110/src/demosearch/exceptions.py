class RasterException(Exception):
    """ """
    ...


class PatchError(RasterException):
    """ """
    ...


class BadArgumentError(RasterException):
    """ """
    ...

class NotAllowedError(Exception):
    """ """
    ...


class InstallException(RasterException):
    """ """
    ...

class DataNotFound(RasterException):
    """ """
    ...

class ConfigurationError(RasterException):
    """ """
    ...

# Errors that are often because of user input

class UserInputError(RasterException):
    """ """
    ...

class UnknownVariableError(UserInputError):
    """ """
    ...

class KernelSizeError(UserInputError):
    """ """
    ...

class FormulaError(UserInputError):
    """ """
    ...

class OutofBoundsError(UserInputError):
    """ """
    ...

class UnknownLocationError(UserInputError):
    """ """
    ...

class CacheMiss(UserInputError):
    """ """
    ...

class BatchError(RasterException):
    """ """
    ...