"""
Kernels to define rings for patches, and ring weighting functions.
"""

from functools import lru_cache

import numpy as np


def mean_r(r1, r2):
    """Return the radius between r1 and r2 the splits the ring between them into
    two rings of equal area"""

    return np.sqrt((r1 ** 2 + r2 ** 2) / 2)


def ring_area(r1, r2):
    """Return the area between the two radii"""

    return np.pi * (r2 ** 2 - r1 ** 2)


def calc_limits(s):
    s = [0] + s
    return list(zip(s[0:-1], s[1:]))


def step_weight(r_min, r_max, r):
    return np.array([int(r_min <= rl and ru <= r_max) for rl, ru in r])


def ring_overlaps(ring_limits, breaks):
    def overlap(start1, end1, start2, end2):
        """how much does the range (start1, end1) overlap with (start2, end2)"""
        return max(max((end2 - start1), 0) - max((end2 - end1), 0) - max((start2 - start1), 0), 0)

    rm = {}
    for i, (r1, r2) in enumerate(ring_limits):
        for j, (b1, b2) in enumerate(calc_limits(breaks)):
            if overlap(r1, r2, b1, b2) > 0:
                rm[i] = j

    return [rm.get(i, -1) for i in range(len(ring_limits))]


def lin(x, v1, v2, r1, r2):
    """Linear mapping, from v1 to v2 over the range or radii r1 to r2"""
    m = (v2 - v1) / (r2 - r1)
    b = v1

    y = m * x + b

    mn, mx = sorted([v1, v2])

    if y < mn:
        y = mn
    elif y > mx:
        y = mx

    return y


def unorm(a):
    return a / np.nanmax(a)



def _mesh(size):
    """Return a 2D mesh, where each cell value is the distance from the center"""
    r = np.arange(-size, size + 1, 1)
    x, y = np.meshgrid(r, r, sparse=True)
    return np.sqrt(x ** 2 + y ** 2)


@lru_cache()
def k_r():
    """Return a kernel of distances from the center"""
    from demosearch.constants import DEFAULT_RESOLUTION
    from demosearch.constants import KERNEL_SIZE

    r = (_mesh(KERNEL_SIZE) * DEFAULT_RESOLUTION).round(0).astype(int)
    r = np.where(r <= KERNEL_SIZE * DEFAULT_RESOLUTION, r, np.nan)

    return r


def clip_to_kernel(r, k, return_widths=False):
    """Return a center portion of the raster r that is ( should be ) aligned with the kernel k.
    r must be larger than k and both must be square and have odd dimensions"""

    r_w = (np.array(r.shape) - 1) / 2
    k_w = (np.array(k.shape) - 1) / 2

    dw = r_w - k_w

    slices = [slice(*e) for e in zip(dw.astype(int), (dw + k_w * 2 + 1).astype(int))]

    return r[slices[0], slices[1]]


def pad_to_kernel(r, k):
    """Pad out a raster to be the same size as the kernel.

    WARNING! Assumes that the raster and the kernel are centered on each other
    """
    dx, dy = np.clip(np.array(k.shape) - np.array(r.shape), 0, None)

    if dx == 0 and dy == 0:
        return r

    return np.pad(r, (
        (int(np.floor(dx / 2)), int(np.ceil(dx / 2))),
        (int(np.floor(dy / 2)), int(np.ceil(dy / 2)))
    ), mode='edge')


def align_to_kernel(r, k):
    r1 = np.ravel(k)
    r2 = np.ravel(r)

    if r1.shape != r2.shape:  # Maybe the raster is smaller than the kernel?
        r = pad_to_kernel(r, k)
        r2 = np.ravel(r)

    if r1.shape != r2.shape:  # Or, maybe larger. This should be the more common case.
        r = clip_to_kernel(r, k)
        r2 = np.ravel(r)

    if r1.shape != r2.shape:
        from .exceptions import KernelSizeError
        raise KernelSizeError(
            f"Kernel shape {r1.shape} can't be broadcast to patch shape {r2.shape} ")

    return r


#
#
#

def mk_lin_map(x1, x2, y1, y2):
    """Make a vectorized linear mapping function"""
    if x1 == x2:
        m = 1
    else:
        m = (y2 - y1) / (x2 - x1)

    b = y1 - m * x1

    def _f(x):

        if x <= x1:
            return y1
        if x >= x2:
            return y2

        return m * x + b

    return np.vectorize(_f, otypes=[float])


def bounded_exp(f, x, x1, x2, y1, y2, y1l=None, y2l=None):
    """ Run the function f as a bounded expresion

    Map values in x from the domain (x1,x2) to the range (y1,y2) with a line map,
    then map (y1,y2) with f. When the mapped values of x are equal to y1 or y2,
    force the the values y1l or y2l


    :param f:
    :type f:
    :param x:
    :type x:
    :param x1:
    :type x1:
    :param x2:
    :type x2:
    :param y1:
    :type y1:
    :param y2:
    :type y2:
    :param y2l:
    :type y2l:
    :param y1l:
    :type y1l:
    :return:
    :rtype:
    """

    lm = mk_lin_map(x1, x2, y1, y2)

    x_ = lm(x)

    r = f(x_)

    if y1l is not None and y2l is not None:
        # Force values that don't extend all the way to the limits of the range
        r[x_ == y1] = y1l
        r[x_ == y2] = y2l

    return r


def _k_hnorm(x, a, b):
    """Half a normal distribution"""
    norm_range = 2.5

    f = lambda x: np.exp(-x ** 2)

    return bounded_exp(f, x, a, b, 0, norm_range, 1, 0)


def _k_norm(x, a, b):
    """full normal distribution"""
    norm_range = 2.5

    f = lambda x: np.exp(-x ** 2).round(2)

    return bounded_exp(f, x, a, b, -norm_range, norm_range, 0, 0)


def _k_lin(x, a, b):
    return mk_lin_map(a, b, 1, 0)(x)


def _k_log(x, a, b):
    """logistic function"""
    norm_range = 5

    f = lambda x: 1 - 1 / (1 + np.exp(-x))

    return bounded_exp(f, x, a, b, -norm_range, norm_range, f(-norm_range * 10), f(norm_range * 10))


def _k_step(x, a, b=None):
    """Step function"""

    if b is None:
        a, b = 0, a

    return np.where((x >= a) & (x < b), 1, 0)


def _k_exp(x, a, b):
    """Exponential decay"""
    f = lambda x: np.exp(x)

    return bounded_exp(f, x, a, b, np.log(.99), np.log(.0005), 1, 0)


def prep_k(kf, reversed=False, inverted=False, norm=False):
    from functools import partial, lru_cache  # FIXME switch to cached in 3.9
    r = k_r()

    def _f(x, *args):

        x_min, x_max = np.nanmin(x), np.nanmax(x)

        if len(args) == 0:
            args = [x_min, x_max]
        elif len(args) == 1:
            args = [0, args[0]]

        if reversed:
            x = np.nanmax(x) - x

        lnmf = mk_lin_map(x_min, x_max, 0, 1)

        s = kf(lnmf(x), *lnmf(args))

        if inverted:
            s = 1 - s

        if norm:
            s = s / np.nansum(s)

        return s

    return lru_cache(partial(_f, r))


def plot_kernel_slice(k, ax=None):
    """Plot a slice through the center of a kernel"""
    import matplotlib.pyplot as plt
    from demosearch.constants import KERNEL_SIZE

    if ax == None:
        fig, ax = plt.subplots(1)

    ax.plot(k[KERNEL_SIZE, KERNEL_SIZE:])

    return ax


kernels = {}
kernel_names = []

# Create all of the kernel variants.
for k, v in list(locals().items()):
    if k.startswith("_k_"):
        root = k.strip('_')

        kernels[root] = prep_k(v)
        kernels[root + '_r'] = prep_k(v, reversed=True)
        kernels[root + '_i'] = prep_k(v, inverted=True)
        kernels[root + '_ri'] = prep_k(v, reversed=True, inverted=True)

        kernels[root + '_n'] = prep_k(v, norm=True)
        kernels[root + '_rn'] = prep_k(v, reversed=True, norm=True)
        kernels[root + '_in'] = prep_k(v, inverted=True, norm=True)
        kernels[root + '_rin'] = prep_k(v, reversed=True, inverted=True, norm=True)

        kernel_names.append(root)

k_step = None  # to fake out IDE. Gets overwritten by locals.update()
k_log = None

for k, v in kernels.items():
    v.__name__ = k

locals().update(kernels)

v_walk = 1.4 * 60  # Walking Velocity

k_walk5 = lambda: k_step(5 * v_walk)
k_walk10 = lambda: k_step(10 * v_walk)
k_walk15 = lambda: k_step(15 * v_walk)

# Driving speed, 30 mph, in meters per minute
v_drive = 30 * 1600 / 60

k_drive5 = lambda: k_step(5 * v_drive)
k_drive10 = lambda: k_step(10 * v_drive)
k_drive15 = lambda: k_step(15 * v_drive)

meters_per_mile = 1609.344

k_1miles = lambda: k_step(1 * meters_per_mile)
k_3miles = lambda: k_step(3 * meters_per_mile)
k_5miles = lambda: k_step(5 * meters_per_mile)

# Set the name for all of the lambdas
for k, v in list(locals().items()):
    try:
        if k.startswith("k_") and v.__name__ == '<lambda>':
            v.__name__ = k
            kernels[k] = v
    except AttributeError:
        pass

DEFAULT_KERNEL = k_log

__all__ = list(kernels.keys()) + ['k_r', 'kernel_names', 'DEFAULT_KERNEL']
