"""UTM Zone boundaries"""

import numpy as np
import pandas as pd
import geopandas as gpd
from pyproj import Transformer
from shapely.geometry import box
from shapely.ops import transform
import metapack as mp
from .util import resceil, resfloor
from .exceptions import OutofBoundsError

#_ll_to_utm = Transformer.from_crs(4326, self.epsg)
#_utm_to_ll = Transformer.from_crs(self.epsg, 4326)

def get_zone_boundaries():
    """Function to return the _utm_zb_ll list"""
    utmg = mp.open_package('http://library.metatab.org/civicknowledge.com-mgrs.csv').resource('utm_grid').geoframe()
    t = utmg[utmg.us_state == 1][['band', 'geometry']].groupby('band').apply(lambda g: g.total_bounds)
    rows = np.array([[idx] + list(v) for idx, v in t.iteritems()])
    return rows.round(2).tolist()


# Zone boundaries in LAT/LON for portion of bands that cover US states
# The longitudes are official, but the latitudes vary so that each
# mand's bound box is the minimum to cover the US states that intersect that band.
# band min_lon min_lat max_lon max_lat (minx miny maxx maxy)
_utm_zb_ll = [
    [1, -180.0, 24.0, -174.0, 56.0],
    [2, -174.0, -16.0, -168.0, 72.0],
    [3, -168.0, 16.0, -162.0, 72.0],
    [4, -162.0, 16.0, -156.0, 72.0],
    [5, -156.0, 16.0, -150.0, 72.0],
    [6, -150.0, 56.0, -144.0, 72.0],
    [7, -144.0, 56.0, -138.0, 72.0],
    [8, -138.0, 48.0, -132.0, 64.0],
    [9, -132.0, 48.0, -126.0, 64.0],
    [10, -126.0, 32.0, -120.0, 56.0],
    [11, -120.0, 32.0, -114.0, 56.0],
    [12, -114.0, 24.0, -108.0, 56.0],
    [13, -108.0, 24.0, -102.0, 56.0],
    [14, -102.0, 24.0, -96.0, 56.0],
    [15, -96.0, 24.0, -90.0, 56.0],
    [16, -90.0, 24.0, -84.0, 56.0],
    [17, -84.0, 24.0, -78.0, 48.0],
    [18, -78.0, 32.0, -72.0, 48.0],
    [19, -72.0, 16.0, -66.0, 48.0],
    [20, -66.0, 16.0, -60.0, 24.0],
    [55, 144.0, 8.0, 150.0, 24.0],
    [59, 168.0, 48.0, 174.0, 56.0],
    [60, 174.0, 48.0, 180.0, 56.0]
]

# For just the continential US
_utm_zb_ll_cc =[
    [10, -126.0, 32.0, -120.0, 56.0],
    [11, -120.0, 32.0, -114.0, 56.0],
    [12, -114.0, 24.0, -108.0, 56.0],
    [13, -108.0, 24.0, -102.0, 56.0],
    [14, -102.0, 24.0, -96.0, 56.0],
    [15, -96.0, 24.0, -90.0, 56.0],
    [16, -90.0, 24.0, -84.0, 56.0],
    [17, -84.0, 24.0, -78.0, 48.0],
    [18, -78.0, 32.0, -72.0, 48.0],
    [19, -72.0, 40.0, -66.0, 48.0]
]

# Total utm bounding box for continential URL states. These are the UTM
# bounding box parameters for a bounding box that can hold any of the UTM zones
# that contain a continential US state.
total_utm_bb = [ 194773, 2657479,  805227, 6210141]

def bb_res(res=100, buffer=0):
    """

    :param res: Default value = 100)
    :param buffer: Default value = 0)

    """

    return [
        resfloor(total_utm_bb[0], res)-buffer, resfloor(total_utm_bb[1], res)-buffer,
        resceil(total_utm_bb[2], res)+buffer, resceil(total_utm_bb[3], res)+buffer
    ]

def utm_zb_utm():
    """ """
    for band, *bbox in _utm_zb_ll:

        epsg = 32600+band
        ll_to_utm = Transformer.from_crs(4326, epsg)

        zbox = box(*bbox)
        yield band, epsg, zbox

def bb_to_array_shape(bb, resoution):
    """Given a UTM bounding box, return an array shape that can
    contain a raster with the given geometric extents.

    :param bb: param resoution:
    :param resoution: 

    """

    t = np.array(bb) / resoution
    return (t[2] - t[0]),(t[3] - t[1])


def total_bounding_box():
    """Function to create the total bounding box"""
    gdf = gpd.GeoDataFrame(list(utm_zb_utm()), columns='band epsg geometry'.split(), crs=4326)
    t = gdf.groupby('band').apply(lambda g: pd.Series(g.to_crs(int(g.epsg.iloc[0])).total_bounds))
    t.columns = 'minx miny maxx maxy'.split()
    t = t.describe()
    return np.array([t.loc['min', 'minx'], t.loc['min', 'miny'], t.loc['max', 'maxx'], t.loc['max', 'maxy']])



def make_utm_data():
    """


    :returns: This is the code that is used to generate the
    
    keys for each record are:
    
        'epsg',
        'minx', 'miny', 'maxx', 'maxy',
        'min_lon', 'min_lat', 'max_lon', 'max_lat'

    """

    bpkg = mp.open_package('http://radius.civicknowledge.com.s3.amazonaws.com/businesslistdatabase.com-us_business-1.1.1.csv')

    ug = bpkg.reference('utm_grid').geoframe()

    ugc = ug[ug.cus_state==1]

    tg = ugc.groupby('band').geometry.transform(lambda r: r.to_crs(32600+r.name)).bounds

    llb = ugc.geometry.bounds
    llb.columns = 'min_lon min_lat max_lon max_lat'.split()
    llb

    t = ugc.join(tg).join(llb)
    t = t[['band','row','epsg']+list(tg.columns)+list(llb.columns)]

    return t.set_index(['band','row']).to_dict(orient='index')
from operator import itemgetter
utmbbig = itemgetter('minx', 'miny', 'maxx', 'maxy')

def get_utm_bounds(lat, lon):
    """

    :param lat: param lon:
    :param lon: 

    """
    import utm
    x, y, band, zone = utm.from_latlon(lat, lon)
    try:
        r = utm_bounds[(band, zone)]
        return utmbbig(r)
    except KeyError:
        raise OutofBoundsError(f' Position lat={lat} lon={lon}, with utm zone {band}{zone} is out of bounds')

utmbbigll = itemgetter('min_lon', 'min_lat', 'max_lon', 'max_lat')

def get_utm_bounds_ll(lat, lon):
    """

    :param lat: param lon:
    :param lon: 

    """
    import utm
    x, y, band, zone = utm.from_latlon(lat, lon)
    try:
        r = utm_bounds[(band, zone)]
        return utmbbigll(r)
    except KeyError:
        raise OutofBoundsError(f' Position lat={lat} lon={lon}, with utm zone {band}{zone} is out of bounds')



utm_bounds= {(10, 'S'): {'epsg': 32610, 'minx': 216576.77161182277, 'miny': 3540435.7117609726, 'maxx': 783423.223370885, 'maxy':
4432069.062657429, 'min_lon': -126.000000025146, 'min_lat': 32.0000001667067, 'max_lon': -120.00000002794, 'max_lat':
40.0000000512227}, (10, 'T'): {'epsg': 32610, 'minx': 243900.35007431763, 'miny': 4427757.224423593, 'maxx':
756099.6453931876, 'maxy': 5320655.800752877, 'min_lon': -126.000000025146, 'min_lat': 40.0000000512227, 'max_lon':
-120.00000002794, 'max_lat': 48.0000001033768}, (10, 'U'): {'epsg': 32610, 'minx': 276224.0831751401, 'miny':
5316300.235941396, 'maxx': 723775.9128654469, 'maxy': 6210141.344241487, 'min_lon': -126.000000025146, 'min_lat':
48.0000001033768, 'max_lon': -120.00000002794, 'max_lat': 56.0000001555309}, (11, 'S'): {'epsg': 32611, 'minx':
216576.7713477522, 'miny': 3540435.7117609726, 'maxx': 783423.2389507093, 'maxy': 4432069.062978871, 'min_lon':
-120.00000002794, 'min_lat': 32.0000001667067, 'max_lon': -113.999999863096, 'max_lat': 40.0000000512227}, (11, 'T'):
{'epsg': 32611, 'minx': 243900.34983576293, 'miny': 4427757.224423593, 'maxx': 756099.6594676063, 'maxy':
5320655.801077517, 'min_lon': -120.00000002794, 'min_lat': 40.0000000512227, 'max_lon': -113.999999863096, 'max_lat':
48.0000001033768}, (11, 'U'): {'epsg': 32611, 'minx': 276224.0829667479, 'miny': 5316300.235941396, 'maxx':
723775.9251603176, 'maxy': 6210141.3445441695, 'min_lon': -120.00000002794, 'min_lat': 48.0000001033768, 'max_lon':
-113.999999863096, 'max_lat': 56.0000001555309}, (12, 'R'): {'epsg': 32612, 'minx': 194772.8248919978, 'miny':
2654226.551123713, 'maxx': 805227.2026985979, 'maxy': 3544369.928380006, 'min_lon': -113.999999863096, 'min_lat':
24.0000001145527, 'max_lon': -107.99999986589, 'max_lat': 32.0000001667067}, (12, 'S'): {'epsg': 32612, 'minx':
216576.78692757746, 'miny': 3540435.7117609726, 'maxx': 783423.238686641, 'maxy': 4432069.062970834, 'min_lon':
-113.999999863096, 'min_lat': 32.0000001667067, 'max_lon': -107.99999986589, 'max_lat': 40.0000000512227}, (12, 'T'):
{'epsg': 32612, 'minx': 243900.36391018264, 'miny': 4427757.224423593, 'maxx': 756099.6592290535, 'maxy':
5320655.801069401, 'min_lon': -113.999999863096, 'min_lat': 40.0000000512227, 'max_lon': -107.99999986589, 'max_lat':
48.0000001033768}, (12, 'U'): {'epsg': 32612, 'minx': 276224.09526161966, 'miny': 5316300.235941396, 'maxx':
723775.9249519273, 'maxy': 6210141.344536602, 'min_lon': -113.999999863096, 'min_lat': 48.0000001033768, 'max_lon':
-107.99999986589, 'max_lat': 56.0000001555309}, (13, 'R'): {'epsg': 32613, 'minx': 194772.8246075529, 'miny':
2654226.551123713, 'maxx': 805227.2024141543, 'maxy': 3544369.9283726714, 'min_lon': -107.99999986589, 'min_lat':
24.0000001145527, 'max_lon': -101.999999868684, 'max_lat': 32.0000001667067}, (13, 'S'): {'epsg': 32613, 'minx':
216576.78666350804, 'miny': 3540435.7117609726, 'maxx': 783423.2384225727, 'maxy': 4432069.0629627975, 'min_lon':
-107.99999986589, 'min_lat': 32.0000001667067, 'max_lon': -101.999999868684, 'max_lat': 40.0000000512227}, (13, 'T'):
{'epsg': 32613, 'minx': 243900.363671629, 'miny': 4427757.224423593, 'maxx': 756099.658990501, 'maxy':
5320655.801061284, 'min_lon': -107.99999986589, 'min_lat': 40.0000000512227, 'max_lon': -101.999999868684, 'max_lat':
48.0000001033768}, (13, 'U'): {'epsg': 32613, 'minx': 276224.09505322843, 'miny': 5316300.235941396, 'maxx':
723775.9247435369, 'maxy': 6210141.3445290355, 'min_lon': -107.99999986589, 'min_lat': 48.0000001033768, 'max_lon':
-101.999999868684, 'max_lat': 56.0000001555309}, (14, 'R'): {'epsg': 32614, 'minx': 194772.82432311063, 'miny':
2654226.551123713, 'maxx': 805227.2021297626, 'maxy': 3544369.9283653405, 'min_lon': -101.999999868684, 'min_lat':
24.0000001145527, 'max_lon': -95.9999998714775, 'max_lat': 32.0000001667067}, (14, 'S'): {'epsg': 32614, 'minx':
216576.78639944084, 'miny': 3540435.7117609726, 'maxx': 783423.2381585526, 'maxy': 4432069.062954762, 'min_lon':
-101.999999868684, 'min_lat': 32.0000001667067, 'max_lon': -95.9999998714775, 'max_lat': 40.0000000512227}, (14, 'T'):
{'epsg': 32614, 'minx': 243900.36343307747, 'miny': 4427757.224423593, 'maxx': 756099.658751992, 'maxy':
5320655.801053169, 'min_lon': -101.999999868684, 'min_lat': 40.0000000512227, 'max_lon': -95.9999998714775, 'max_lat':
48.0000001033768}, (14, 'U'): {'epsg': 32614, 'minx': 276224.09484483895, 'miny': 5316300.235941396, 'maxx':
723775.9245351844, 'maxy': 6210141.3445214685, 'min_lon': -101.999999868684, 'min_lat': 48.0000001033768, 'max_lon':
-95.9999998714775, 'max_lat': 56.0000001555309}, (15, 'R'): {'epsg': 32615, 'minx': 194772.8240387176, 'miny':
2654226.551123713, 'maxx': 805227.2018453175, 'maxy': 3544369.928358006, 'min_lon': -95.9999998714775, 'min_lat':
24.0000001145527, 'max_lon': -89.9999998742715, 'max_lat': 32.0000001667067}, (15, 'S'): {'epsg': 32615, 'minx':
216576.78613541962, 'miny': 3540435.7117609726, 'maxx': 783423.237894483, 'maxy': 4432069.062946726, 'min_lon':
-95.9999998714775, 'min_lat': 32.0000001667067, 'max_lon': -89.9999998742715, 'max_lat': 40.0000000512227}, (15, 'T'):
{'epsg': 32615, 'minx': 243900.36319456727, 'miny': 4427757.224423593, 'maxx': 756099.6585134382, 'maxy':
5320655.801045054, 'min_lon': -95.9999998714775, 'min_lat': 40.0000000512227, 'max_lon': -89.9999998742715, 'max_lat':
48.0000001033768}, (15, 'U'): {'epsg': 32615, 'minx': 276224.09463648556, 'miny': 5316300.235941396, 'maxx':
723775.9243267933, 'maxy': 6210141.3445139015, 'min_lon': -95.9999998714775, 'min_lat': 48.0000001033768, 'max_lon':
-89.9999998742715, 'max_lat': 56.0000001555309}, (16, 'R'): {'epsg': 32616, 'minx': 194772.82375427522, 'miny':
2654226.551123713, 'maxx': 805227.2015608856, 'maxy': 3544369.9283506726, 'min_lon': -89.9999998742715, 'min_lat':
24.0000001145527, 'max_lon': -83.9999998770654, 'max_lat': 32.0000001667067}, (16, 'S'): {'epsg': 32616, 'minx':
216576.78587135253, 'miny': 3540435.7117609726, 'maxx': 783423.2376304256, 'maxy': 4432069.062938691, 'min_lon':
-89.9999998742715, 'min_lat': 32.0000001667067, 'max_lon': -83.9999998770654, 'max_lat': 40.0000000512227}, (16, 'T'):
{'epsg': 32616, 'minx': 243900.36295601577, 'miny': 4427757.224423593, 'maxx': 756099.6582748955, 'maxy':
5320655.801036937, 'min_lon': -89.9999998742715, 'min_lat': 40.0000000512227, 'max_lon': -83.9999998770654, 'max_lat':
48.0000001033768}, (16, 'U'): {'epsg': 32616, 'minx': 276224.0944280962, 'miny': 5316300.235941396, 'maxx':
723775.9241184114, 'maxy': 6210141.3445063345, 'min_lon': -89.9999998742715, 'min_lat': 48.0000001033768, 'max_lon':
-83.9999998770654, 'max_lat': 56.0000001555309}, (17, 'R'): {'epsg': 32617, 'minx': 194772.8234698407, 'miny':
2654226.551123713, 'maxx': 805227.201276442, 'maxy': 3544369.9283433384, 'min_lon': -83.9999998770654, 'min_lat':
24.0000001145527, 'max_lon': -77.9999998798594, 'max_lat': 32.0000001667067}, (17, 'S'): {'epsg': 32617, 'minx':
216576.78560729267, 'miny': 3540435.7117609726, 'maxx': 783423.2373663574, 'maxy': 4432069.062930655, 'min_lon':
-83.9999998770654, 'min_lat': 32.0000001667067, 'max_lon': -77.9999998798594, 'max_lat': 40.0000000512227}, (17, 'T'):
{'epsg': 32617, 'minx': 243900.3627174708, 'miny': 4427757.224423593, 'maxx': 756099.6580363429, 'maxy':
5320655.801028822, 'min_lon': -83.9999998770654, 'min_lat': 40.0000000512227, 'max_lon': -77.9999998798594, 'max_lat':
48.0000001033768}, (18, 'S'): {'epsg': 32618, 'minx': 216576.78534322564, 'miny': 3540435.7117609726, 'maxx':
783423.2371022903, 'maxy': 4432069.062922618, 'min_lon': -77.9999998798594, 'min_lat': 32.0000001667067, 'max_lon':
-71.9999998826534, 'max_lat': 40.0000000512227}, (18, 'T'): {'epsg': 32618, 'minx': 243900.36247891924, 'miny':
4427757.224423593, 'maxx': 756099.6577977914, 'maxy': 5320655.801020706, 'min_lon': -77.9999998798594, 'min_lat':
40.0000000512227, 'max_lon': -71.9999998826534, 'max_lat': 48.0000001033768}, (19, 'T'): {'epsg': 32619, 'minx':
243900.3622403667, 'miny': 4427757.224423593, 'maxx': 756099.6575592464, 'maxy': 5320655.8010125905, 'min_lon':
-71.9999998826534, 'min_lat': 40.0000000512227, 'max_lon': -65.9999998854473, 'max_lat': 48.0000001033768}}