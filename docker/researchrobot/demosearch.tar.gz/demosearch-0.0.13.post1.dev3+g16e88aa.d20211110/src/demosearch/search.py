"""
Text search on regions
"""

from whoosh.fields import SchemaClass, TEXT, KEYWORD, ID, STORED, NUMERIC
import os, os.path
import pandas as pd
from whoosh import index
from whoosh.index import EmptyIndexError
import rowgenerators as rg
import json
from geoid.census import Cbsa

import geopandas as gpd


class GeoSchema(SchemaClass):
    """ """
    geoid = ID(stored=True)
    name = TEXT(stored=True)
    area = NUMERIC(stored=True)
    data = TEXT(analyzer=None, stored=True)

def build_index(cache, df):
    """Index names of CBSAs. The input is a GeoDataFrame of a census CBSA TigerLine shapefile

    :param cache: param df:
    :param df: 

    """

    # Census list of CBSAs and their geographic boundaries

    p = cache.joinpath('ftsearch', mkdir=True)
    p.mkdir(parents=True, exist_ok=True)

    ix = index.create_in(p, GeoSchema)

    writer = ix.writer()
    try:
        for idx, row in df.iterrows():
            d = {
                'lat': float(row.INTPTLAT),
                'lon': float(row.INTPTLON),
                'area': float(row.ALAND) + float(row.AWATER),
                'bb': row.geometry.bounds
            }
            writer.add_document(geoid=row.GEOID, name=row.NAME, data=json.dumps(d))

        writer.commit()
    except:
        writer.cancel()
        raise

from collections import  namedtuple

CBSAResult = namedtuple("CBSAResult", ['lat','lon', 'pt', 'area', 'bb', 'name', 'geoid'])

from whoosh.index import EmptyIndexError #noqa

def ftsearch(cache, query):
    """

    :param cache: param query:
    :param query: 

    """

    from .exceptions import BadArgumentError

    try:
        from whoosh.qparser import QueryParser

        p = cache.joinpath('ftsearch', mkdir=True)
        ix = index.open_dir(p)

        qp = QueryParser("name", schema=ix.schema)
        try:
            q = qp.parse(query)
        except AttributeError:
            # query is not a string
            raise TypeError(f"Input type '{type(query)}' is not a string")

        rows = []
        with ix.searcher() as s:
            for r in s.search(q, limit=None):
                r = r.fields()
                d = json.loads(r['data'])
                d.update({
                    'name': r['name'],
                    'geoid': r['geoid'],
                    'lat': d['lat'],
                    'lon': d['lon'],
                    'pt': (d['lat'], d['lon']),
                    'area': d['area'],
                    'bb': tuple(d['bb'])
                })

                d['geoid'] = str(Cbsa(d['geoid']).as_acs())
                rows.append(CBSAResult(**d))

        return list(reversed(sorted(rows, key=lambda r:r.area)))
    except EmptyIndexError:
        raise EmptyIndexError('No search index. Create one with ds_cachedata -i')

