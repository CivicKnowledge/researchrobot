# Copyright (c) 2021 Civic Knowledge. See LICENSE.txt for license details

raise Exception()

import contextily as ctx
import geopandas as gpd
import libgeohash as gh
import matplotlib.pyplot as plt
import numpy as np
from demosearch.util import expand_to_gh4
from pyproj import Transformer
from shapely.geometry import Point
from shapely.ops import transform

import logging

logger = logging.getLogger(__name__)

default_gh_precision = 4  # Precision for geohash encoding

hw_map = {
    '1': 'primary',
    '2': 'secondary',
    '3': 'tertiary',
    'm': 'highway',
    'r': 'residential',
    't': 'trunk'
}

def encode(lat, lon, precision=default_gh_precision):
    """

    :param lat: param lon:
    :param precision: Default value = default_gh_precision)
    :param lon: 

    """
    return gh.encode(lat, lon, precision)

def make_ea_radii(n, maxr):
    """Return the radii for  n rings of equal area, with the largest ring having
    a radius of maxr

    :param n: Number of rings
    :param maxr: Max radius

    """

    return (np.array([np.sqrt(i / n) for i in range(1, n + 1)]) * maxr).round(0).astype(int).tolist()

def make_modea_radii(n, maxr):
    """Building rings with an emphasis on locality
    
    Like make_ea_radii, but the first ring is split in two, with 1/4 of the area in the first split,
    and 3/4 in the second split. The areas of the final rings will be 1/(n-1)*(1/4) for the first ring,
    1/(n-1)*(3/4) for the next, and 1/(n-1) for the remaining
    
    for 6 rings and a maxr of 8,000m, the first ring is a radius of 1.1mi
    
    To check the are proportions:

    :param n: param maxr:
    :param maxr: 

    >>> r = make_modea_radii(5, 8000)
    >>> r2 = [e**2 / r[-1]**2 for e in r]
    >>> [ (b-a) for a,b in list(zip([0]+r2, r2))]
    """

    r1 = make_ea_radii(n-1, maxr)
    r2 = make_ea_radii(4, r1[0])

    return [r2[0]] + r1

class SearchRings(object):
    """Generate search ring data"""

    def __init__(self, cache, lat, lon, utm_epsg, hashes, tracts, data,
                 radii=make_modea_radii(6,8000)):

        raise Exception("Unused!")

        self.config = cache
        self.radii = radii
        self.lat = lat
        self.lon = lon

        self.hashes = hashes
        self._data = data
        self._tracts = tracts

        self.precision = default_gh_precision

        self.ghc = encode(self.lat, self.lon, self.precision)
        self.ghe = encode(self.lat, self.lon)

        self.utm_epsg = utm_epsg

        self.to_utm = Transformer.from_crs(4326, utm_epsg)

        self.utm_point = transform(self.to_utm.transform, Point(self.lat, self.lon))

        self._buffer = None
        self._ratios = None



    @property
    def buffer(self):
        """ """
        if self._buffer is None:
            self._buffer = gpd.GeoDataFrame({'rad': self.radii},
                                            geometry=[self.utm_point.buffer(r) for r in self.radii],
                                            index=self.radii,
                                            crs=self.utm_epsg)
        return self._buffer

    @property
    def census_ring_counts(self):
        """ """

        # This crs conversion takes about 100ms, while the geohash search only takes 8. We could eliminate
        # the conversion here ( move it upfront ) by creating sets of tracts in each UTM zone, and within 10km
        # on either side, then convert them all to the same utm zone upfront.

        tracts = self._data['census'].to_crs(self.utm_epsg)

        cols = list(tracts.iloc[0, list(tracts.columns).index('geometry') + 1:].index)

        # Overlay to get areas for each combination of tract and rung
        g = gpd.overlay(self.buffer, tracts).groupby(['tract_id', 'rad'])

        # Extract the geometry and areas from the result
        t = g.agg({'geometry': 'first', 'oarea': 'first'})

        # compute the ratio of each new area to the original tract
        area_ratios = t.area / t.oarea

        # Extract census data
        census_data = g[cols].sum()

        # Multiply by the ratio to get the population in each overlay area
        t = census_data.multiply(area_ratios, axis=0)


        # Sum over all tracts in each buffer to get the population per buffer
        t = t.groupby(level='rad').sum().sort_index()
        # Or: t = t.sum(level='rad').sort_index().astype(int)

        # Subtract the population of each smaller buffer to get populaltions of rings
        t = t.subtract(t.shift(axis=0).fillna(0), axis=0).astype(int)

        return t

    @property
    def point_ring_counts(self):
        """ """

        points = self._data['points'].to_crs(self.utm_epsg)
        excl_cols = ['geohash', 'geometry', 'utm_epsg']
        cols = [c for c in points.columns if c not in excl_cols]

        t = gpd.sjoin(self.buffer, points).groupby('rad')[cols].sum().sort_index()
        t = t.subtract(t.shift(axis=0).fillna(0), axis=0).astype(int)

        return t

    @property
    def road_ring_counts(self):
        """ """

        roads = self._data['roads']
        roads.crs =self.utm_epsg # the crs of the roads data is broken
        excl_cols = ['geohash', 'geometry', 'utm_epsg']
        cols = [c for c in roads.columns if c not in excl_cols]

        t =  gpd.overlay(roads, self.buffer)
        t['len'] = t.length
        t = t.groupby(['highway', 'rad']).len.sum().unstack(0).fillna(0)
        t = t.subtract(t.shift(axis=0).fillna(0), axis=0).astype(int)
        t = t.rename(columns=hw_map)
        return t

    def weights(self, shift=0):
        """Returns weights for each ring according to 1/r, with the first ring
        being normalized to 1

        :param shift: Default value = 0)

        """
        t = np.array([ 2/(r1+r2) for r1, r2 in list(zip( [1]+self.radii[:-1], self.radii)) ])
        t = (t/t[0]).tolist()

        # Shift the radii right, inserting 1 in the front
        if shift > 0:
            t = ([1.0]*shift + t)[:len(self.radii)]

        elif shift < 0:
            t = (t + [0] * abs(shift) )[-len(self.radii):]

        t = (np.array(t) / sum(t)).tolist()

        return t

    def score_rings(self, shift=0):
        """

        :param shift: Default value = 0)

        """

        t = self.census_ring_counts.join(self.point_ring_counts)

        score = t.multiply(np.transpose(self.weights(shift)), axis=0).sum(axis=0)
        score.name = 'score'
        sm = t.sum(axis=0)
        sm.name = 'sum'

        scores = t.append(sm).append(score)

        return scores

    def plot_rings(self,  path=None, axes=False, axlim=True, ax=None):
        """

        :param path: Default value = None)
        :param axes: Default value = False)
        :param axlim: Default value = True)
        :param ax: Default value = None)

        """

        r = self.buffer.boundary.to_crs(epsg=3857)

        ax = r.plot(figsize=(8, 8), ax=ax)

        r.iloc[0:1].centroid.plot(ax=ax) # Center point

        try:
            self.tracts.boundary.to_crs(epsg=3857).plot(ax=ax, edgecolor='lightslategray')
        except ValueError:
            pass # No tracts?

        # Make the image just a bit bigger than the rings.
        if axlim:
            tb = r.geometry.unary_union.bounds
            dy = np.abs(tb[1] - tb[3]) * .02
            ax.set_ylim(tb[1] - dy, tb[3] + dy)
            dx = np.abs(tb[0] - tb[2]) * .02
            ax.set_xlim(tb[0] - dx, tb[2] + dx)

        if not axes:
            ax.set_axis_off()



        if path:
            plt.savefig(path.with_suffix('.png'), bbox_inches='tight', transparent=True)

        return ax
