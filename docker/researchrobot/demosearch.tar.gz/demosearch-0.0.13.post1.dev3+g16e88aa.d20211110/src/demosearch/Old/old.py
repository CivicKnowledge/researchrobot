from itertools import chain

import geopandas as gpd
import libgeohash as gh
import metapack as mp
import numpy as np
import pandas as pd
import shapely
from auto_tqdm import tqdm
from demosearch.install import logger
from demosearch.osm import logger
from demosearch.util import gh_data_path, munge_pbar, run_mp
from shapely.geometry import Point
from tqdm import tqdm


class InstallManager(object):
    """Install data into the cache"""

    hashes_key = 'data/hashes'
    tracts_key = 'data/tracts'
    census_key = 'data/census'
    roads_key = 'data/roads'
    tags_key = 'data/tags'
    points_key = 'data/points'
    roads_key = 'data/roads'

    roads_r_key = 'data/roads_r'
    roads_nr_key = 'data/roads_nr'

    def __init__(self, cache, data_url):
        """ """

        raise Exception('Not used?')

        self.data_url = data_url
        self.config = cache

        self.data_pkg = mp.open_package(self.data_url)

    def census(self, tracts, hashes):
        """

        :param tracts: param hashes:
        :param hashes: 

        """

        census = self.data_pkg.resource('census_set').dataframe()

        t = tracts.merge(hashes[['utm_epsg']], left_on='gh4', right_index=True)
        t['oarea'] = t.aland + t.awater
        tracts = t[['geoid', 'tract_id', 'geohash', 'utm_epsg', 'oarea', 'geometry']].copy()

        tracts['gh_4'] = tracts.geohash.str.slice(0, 4)
        tracts.sort_values('geohash', inplace=True)

        return tracts.merge(census).set_index('gh_4')

    def install_gh(self, df, name):
        """

        :param df: param name:
        :param name: 

        """

        for idx, g in tqdm(df.groupby(level=0), desc='Install data'):
            key = gh_data_path(idx, name)
            if not self.cache.exists(key) or True:
                self.cache.put_df(key, g)

    def install_tracts(self, force=False):
        """

        :param force: Default value = False)

        """

        #
        # Geohashes
        if not self.cache.exists(self.hashes_key) or force:
            logger.debug('Processing hashes')
            hashes = self.data_pkg.resource('us_geohashes').dataframe().set_index('geohash')
            self.cache.put_df(self.hashes_key, hashes)

            self.install_gh(hashes, 'hashes')
        else:
            logger.debug('Hashes already processed')

        #
        # Tracts
        if not self.cache.exists(self.tracts_key) or force:
            logger.debug('Processing tracts')
            tracts = self.data_pkg.resource('us_tracts').geoframe()
            self.cache.put_df(self.tracts_key, tracts)

            self.install_gh(tracts.set_index('gh4'), 'tracts')
        else:
            logger.debug('Tracts already processed')

        #
        # Census
        if not self.cache.exists(self.census_key) or force:
            logger.debug('Processing census')
            tracts = self.cache.get_df(self.tracts_key)
            hashes = self.cache.get_df(self.hashes_key)

            census = self.census(tracts, hashes)
            self.cache.put_df(self.census_key, census)

            self.install_gh(census, 'census')
        else:
            logger.debug('Census already processed')

    def install_osm(self, force):
        """Install OSM files into the cache

        :param force: 

        """
        #
        # Geohash tags ( points
        if not self.cache.exists(self.tags_key) or force:
            logger.debug('Processing tags')
            tags = self.data_pkg.resource('point_tags').geoframe()
            self.cache.put_df(self.tags_key, tags)
        else:
            logger.debug('Tags already processed')

        #
        # Residential roads
        if not self.cache.exists(self.roads_r_key) or force:
            logger.debug('Processing residential roads')
            t = self.data_pkg.resource('residential_roads').geoframe().set_index('geohash')
            self.cache.put_df(self.roads_r_key, t)
        else:
            logger.debug('Residential already processed')

        #
        # Non residential roads
        if not self.cache.exists(self.roads_nr_key) or force:
            logger.debug('Processing non residential roads')
            t = self.data_pkg.resource('nonres_roads').geoframe().set_index('geohash')
            self.cache.put_df(self.roads_nr_key, t)
        else:
            logger.debug('Non residential already processed')

    def install_points(self, force=False):
        """

        :param force: Default value = False)

        """

        if not self.cache.exists('data/points') or force:
            logger.debug('Creating  points dataframe')
            tags = self.cache.get_df(self.tags_key)
            # Reduces memory usage from 450Mb to 80Mb
            tag_cols = [c for c in tags.columns if c not in ['utm_epsg', 'geohash', 'geometry']]

            hashes = self.cache.get_df(self.hashes_key)

            t = tags.set_index(tags.geohash.str.slice(0, 4)).join(hashes[['utm_epsg']])
            t.loc[:, tag_cols] = t.loc[:, tag_cols].fillna(0).astype(np.int8)

            t.index.name = 'gh_4'
            logger.debug('Writing points to cache')
            self.install_gh(t, 'points')
            self.cache.put_df('data/points', t)
        else:
            logger.debug('File points already processed')

    def install_roads(self, force):
        """

        :param force: 

        """

        if not self.cache.exists(self.roads_key) or force:
            logger.debug('Creating roads dataframe')

            t = self.cache.get_df(self.roads_nr_key)
            hashes = self.cache.get_df(self.hashes_key)
            roads1 = t.join(hashes[['utm_epsg']])

            t = self.cache.get_df(self.roads_r_key)
            hashes = self.data_pkg.resource('us_geohashes').dataframe().set_index('geohash')
            roads2 = t.join(hashes[['utm_epsg']])

            logger.debug('Concatenate roads')
            roads = pd.concat([roads1, roads2]).sort_index()

            logger.debug('Writing roads to cache')
            self.install_gh(roads, 'roads')
            self.cache.put_df(self.roads_key, roads)
        else:
            logger.debug('File roads already processed')

