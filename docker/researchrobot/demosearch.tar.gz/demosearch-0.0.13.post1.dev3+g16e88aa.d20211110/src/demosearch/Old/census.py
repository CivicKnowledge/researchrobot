# Copyright (c) 2021 Civic Knowledge. See LICENSE.txt for license details
__docformat__ = 'restructuredtext en'

import logging

import libgeohash as gh
import pandas as pd
import rowgenerators as rg
from demosearch.util import munge_pbar
from geoid.censusnames import stusab

from .util import gh_to_int, gh_data_path

logger = logging.getLogger(__name__)

class TractProcessor(object):
    """ """

    def __init__(self, cache, year=None, progress_bar = None):

        self.cache = cache
        self.pbar = munge_pbar(progress_bar)

        if year is None:
            self.year = self.cache.config['census/year']
        else:
            self.year = year

        self.tracts_key = 'data/tracts.pkl'
        self.bg_key = 'data/bg.pkl'

    def _set_config(self):
        """ """
        self.config['tracts/year'] = self.year

    def process_tracts(self):
        """ """

        logger.debug("Fetching tracts")
        frames = [rg.geoframe(f'censusgeo://2019/5/{st}/tract') for st in stusab.values()]
        tracts = pd.concat(frames).to_crs(26911)  # UTM

        logger.debug("Processing tracts")
        tracts['idx'] = range(len(tracts))
        # tracts['centroid'] = gpd.GeoSeries(tracts[['intptlat','intptlon']].astype(float)\
        #                                   .apply(lambda r: Point(r.intptlat, r.intptlon), axis=1),crs=tracts.crs)

        tracts['geohash'] = tracts[['intptlat', 'intptlon']].astype(float) \
            .apply(lambda r: gh.encode(r.intptlat, r.intptlon), axis=1)

        tracts['gh_4'] = tracts.geohash.apply(lambda v: gh_to_int(v[0:4]))
        tracts['gh_3'] = tracts.geohash.apply(lambda v: gh_to_int(v[0:3]))
        tracts['oarea'] = tracts.area

        logger.debug("Finished processing tracts")
        return tracts

    def process_blockgroups(self):
        """ """

        logger.debug("Fetching blockgroup")
        frames = [rg.geoframe(f'censusgeo://2019/5/{st}/blockgroup') for st in stusab.values()]
        bg = pd.concat(frames).to_crs(26911)  # UTM

        logger.debug("Processing blockgroup")
        bg['idx'] = range(len(bg))
        # tracts['centroid'] = gpd.GeoSeries(tracts[['intptlat','intptlon']].astype(float)\
        #                                   .apply(lambda r: Point(r.intptlat, r.intptlon), axis=1),crs=tracts.crs)

        bg['geohash'] = bg[['intptlat', 'intptlon']].astype(float) \
            .apply(lambda r: gh.encode(r.intptlat, r.intptlon), axis=1)

        bg['gh_4'] = bg.geohash.apply(lambda v: gh_to_int(v[0:4]))
        bg['gh_3'] = bg.geohash.apply(lambda v: gh_to_int(v[0:3]))
        bg['oarea'] = bg.area

        logger.debug("Finished processing blockgroup")
        return bg


    def clear_tracts(self):
        """Delete the cached tracts file"""
        self.cache.delete(self.tracts_key)

    def get_tracts(self):
        """Create a tracts file if it does not exist, return the tracts if it does"""

        if self.cache.exists(self.tracts_key):
            logger.debug("Returning tracts from cache")
            return self.cache.get(self.tracts_key)

        tracts = self.process_tracts()

        self.cache.put(self.tracts_key, tracts)

        return tracts

    def get_blockgroups(self):
        """Create a tracts file if it does not exist, return the tracts if it does"""

        if self.cache.exists(self.tracts_key):
            logger.debug("Returning tracts from cache")
            return self.cache.get(self.tracts_key)

        bg = self.process_blockgroups()

        self.cache.put(self.bg_key, bg)

        return bg

    @property
    def tract_hashes(self):
        """ """
        tracts = self.get_tracts()

        return [ (ghc, gh.expand(ghc), gh.geohash_to_polygon(gh.expand(ghc)) )
                 for  ghc in tracts.geohash.str.slice(0, 4).unique() ]

    def write_tracts_by_hash(self, force=False):
        """Write tracts for each expanded geohash.

        :param force: Default value = False)

        """

        tracts = self.get_tracts()

        for gh4, g_df in self.pbar(tracts.groupby(tracts.geohash.str.slice(0, 4)),desc='Tracts by Hash'):

            key = gh_data_path(gh4, 'tracts.pkl')
            if force or not self.cache.exists(key):
                self.cache.put_df(key, g_df)

    def get_tracts_by_hash(self, ghc):
        """

        :param ghc: 

        """
        key = gh_data_path(ghc, 'tracts.pkl')
        return self.cache.get(key)

    def get_expanded_tracts_by_hash(self, ghc):
        """Like get_tracts_by_hash, but also get the 8 surrounding hash areas

        :param ghc: 

        """

        def _get(ghc):
            """

            :param ghc: 

            """
            try:
                return self.get_tracts_by_hash(ghc)
            except KeyError:
                return None

        gh4e = gh.expand(ghc[0:4])
        frames = [_get(e) for e in gh4e]

        return pd.concat([e for e in frames if e is not None])



class CensusProcessor(object):
    """ """

    def __init__(self, cache, year=None, progress_bar=None):

        self.cache = cache
        self.pbar = munge_pbar(progress_bar)

        self.tables = ['B01001', # Sex by age
                       'B01002', # Median Age by Sex
                       'B19313', # Median Household Income
                       'B11009', # Coupled Households by Type
                       'B26105', # Group Quarters Type (3 Types) by School Enrollment
                       'B15001', # Sex by Age by Educational Attainment
                       ]

        self._tracts = None

        if year is None:
            self.year = self.cache.config['census/year']
        else:
            self.year = year

        if not self.year:
            raise Exception("Must set year")

    def _set_config(self):
        """ """
        self.cache.config['census/year'] = self.year

    @property
    def tracts(self):
        """ """
        if self._tracts is None:
            tp = TractProcessor(self.cache, year=self.year, progress_bar=True)

            self._tracts = tp.get_tracts()

        return self._tracts

    def _process_table(self, df):
        """

        :param df: 

        """

        # Link to the tracts to assign the idx number and geohash, which we will use to
        # reference them instead of geoids

        df = self.tracts[['geoid', 'idx', 'geohash']].merge(df, on='geoid')
        m90_cols = [c for c in df.columns if c.endswith('m90')]
        df = df.drop(columns=['name', 'stusab', 'county', 'geoid'] + m90_cols)

        return df

    def make_col_title_map(self,df):
        """

        :param df: 

        """
        def col_f(v):
            """

            :param v: 

            """
            return not v[0].endswith('_m90') and not v[0] in ('geoid','stusab', 'county','name')

        return dict(filter(col_f, zip(df.columns, df.titles.columns)))

    def combine_colmaps(self):
        """Create a singledataset of all of the colmaps"""

        # Processing combined column maps seperately so
        # so can update rather than re-processing all of them
        column_map = {}
        for fn in self.cache.list('colmaps'):
            column_map[fn.stem] = self.cache.get(str(fn))

        def munge(v):
            """

            :param v: 

            """
            return v.title() \
                       .replace('Partner Households By Sex Of Partner  - Households  - Total  -', '') \
                       .replace('Total Population  - Total  - ', '') \
                       .replace(' Total Population  - Total', 'Total Population') \
                       .replace('  - ', ', ')[11:].strip()

        def yield_cm_entries(column_map):
            """

            :param column_map: 

            """
            for k, d in column_map.items():
                for kk, v in d.items():
                    yield (k, kk, v, munge(v))

        t = pd.DataFrame(list(yield_cm_entries(column_map)), columns=['table', 'column', 'orig_title', 'title'])

        self.cache.put_df('/colmaps/colmap', t)

        return t

    @property
    def colmap(self):
        """ """
        return self.cache.get_df('/colmaps/colmap')

    def get_table(self, table, force=False):
        """

        :param table: param force:  (Default value = False)
        :param force:  (Default value = False)

        """
        release = 5
        state = 'US'
        sl = 'tract'

        key = f'data/{table}'

        if self.cache.exists(key) and not force:
            logger.debug(f"Returning table {table} from cache")
            return self.cache.get_df(key)
        else:
            logger.debug(f"Fetching table {table}")
            data = rg.dataframe(f'census://{self.year}/{release}/{state}/{sl}/{table}').reset_index()

            self.cache.put(f'colmaps/{table.lower()}', self.make_col_title_map(data))

            data = self._process_table(data)
            self.cache.put_df(key, data)
            return data

    def split_table(self, census_table, pbar_leave=True, force=False):
        """

        :param census_table: param pbar_leave:  (Default value = True)
        :param force: Default value = False)
        :param pbar_leave:  (Default value = True)

        """

        data = self.get_table(census_table)

        l = data.geohash.str.slice(0, 4).unique()
        for gh4 in self.pbar(l, leave=pbar_leave, desc=f"Table {census_table}"):

            key = gh_data_path(gh4, f'{census_table}.pkl')
            if force or not self.cache.exists(key):
                gh4e = gh.expand(gh4)
                g = data[data.geohash.str.slice(0, 4).isin(gh4e)].drop(columns=['geohash'])
                self.cache.put_df(key, g)

    def get_split_table(self, ghc, census_table):
        """

        :param ghc: param census_table:
        :param census_table: 

        """
        key = gh_data_path(ghc[:4], f'{census_table}.pkl')
        return self.cache.get_df(key)

    def split_tables(self, force=False):
        """Split all of the tables

        :param force: Default value = False)

        """

        for table in self.pbar(self.tables, desc=f'Splitting {len(self.tables) } Tables'):
            self.split_table(table, pbar_leave=False, force=force)

        self.combine_colmaps()

        self._set_config()


def ProcessTractScore_f(o):
    """

    :param o: 

    """
    return o._run()

class ProcessTractScore(object):
    """A task class to create a scores dataframe for each of the geohash regions"""
    def __init__(self, cache_dir, idx, lat, lon, table):
        self.cache_dir = cache_dir
        self.idx = idx
        self.lat = lat
        self.lon = lon
        self.ghc = gh.encode(lat, lon)
        self.table = table

    @classmethod
    def make_tasks(cls, cache, table, limit = None):
        """

        :param cache: param table:
        :param limit: Default value = None)
        :param table: 

        """

        cp = CensusProcessor(cache)
        tracts = cp.tracts

        if limit:
            tracts = tracts[:limit]

        cr = cache._cache_root
        tasks = [ (ProcessTractScore(cr, int(r.idx), r.intptlat, r.intptlon, table),) for idx, r in
                 list(tracts[['idx', 'intptlat', 'intptlon']].astype(float).iterrows())]

        return tasks

    @classmethod
    def run(cls, cache, table, limit = None):
        """

        :param cache: param table:
        :param limit: Default value = None)
        :param table: 

        """
        from .util import run_mp
        tasks = cls.make_tasks(cache, table, limit)

        run_mp(ProcessTractScore_f, tasks)

    @property
    def path(self):
        """ """
        return '/'.join(['scores',self.ghc[:2],self.ghc[2:], f"{self.table}-{self.idx}"])

    @property
    def exists(self):
        """ """
        from .cache import FileCache
        cache = FileCache(self.cache_dir)
        return cache.exists(self.path)

    def _run(self):
        """ """
        from .cache import FileCache
        from .radius import SearchRings

        cache = FileCache(self.cache_dir)
        if not cache.exists(self.path):
            lat, lon = gh.decode(self.ghc)
            sr = SearchRings(cache, lat, lon)
            s = sr.score_rings(self.table)

            cache.put_df(self.path, s)
            return self.idx

