"""Batch Scoring"""

import logging

from demosearch.raster import *
from demosearch.util import run_mp, nope_maybe
from tqdm.auto import tqdm

logger = logging.getLogger(__name__)

# Chunk the business file, to have more tasks for the prep phase

default_cache_key = 'batch_score'


def chunk_dataframe(config, cache_key, df, chunk_size=None):
    """Split the source dataset into chunks, so preparing tasks can be multi-process

    :param config: param cache_key:
    :param df: param chunk_size:  (Default value = None)
    :param cache_key: 
    :param chunk_size:  (Default value = None)

    """

    cache = config.cache

    logger.info("Chunk dataframes")

    chunk_size = len(df) // 100 if chunk_size is None else chunk_size

    k_src = cache_key + '/source/{idx}'

    rng = list(range(0, len(df), chunk_size))
    source_chunks = []
    for i in tqdm(rng, desc='Chunk Dataframe', leave=True):
        chunk = df.iloc[i:i + chunk_size]
        k = k_src.format(idx=i)
        if not cache.exists(k):
            assert len(chunk) > 0
            cache.put_df(k, chunk)
            logger.debug(f"Wrote chunk {i}, len {len(chunk)} to  {k}")
        else:
            logger.debug(f"Source chunk {i} exists as key {k}")
        source_chunks.append(k)

    logger.info(f"Chunked {len(source_chunks)} dataframes")

    return source_chunks


def _prep_batch(config, cache_key, df_key, chunk_number, layer, raster_path=None):
    """Multiprocess task for preparing batch tasks

    :param config: param cache_key:
    :param df_key: param chunk_number:
    :param layer: param raster_path:  (Default value = None)
    :param cache_key: 
    :param chunk_number: 
    :param raster_path:  (Default value = None)

    """

    from demosearch.exceptions import OutofBoundsError

    cache = config.cache

    k = f'{cache_key}/args/{layer}/{chunk_number}'

    if cache.exists(k):
        return k

    df = cache.get_df(df_key)

    if len(df) == 0:
        print(f"Source data at {df_key} is empty")

    rm = RasterManager(config, raster_path)

    args = defaultdict(list)

    for _, row in df.iterrows():
        try:
            loc = rm.process_location_arg((row.geometry.y, row.geometry.x), layer)
            bbox = loc.pix.make_summary_patch(size=100) if isinstance(loc, Location) else loc.pix

            ri = loc.raster_info

            args[loc.band].append({'source': k, 'idx': row['idx'], 'loc': list(loc), 'bbox': list(bbox),
                                   'ri_num': rm.infos.index(ri), 'ri_key': ri.key,
                                   'band': loc.band})
        except OutofBoundsError:
            pass
        except Exception as e:
            raise
            pass  # Position is out of bounds

    assert len(args) > 0
    cache.put(k, args)

    return k


def make_prep_tasks(config, source_chunks, cache_key, layers=None, raster_path=None):
    """Create preparation tasks from the source chunks

    :param config: param source_chunks:
    :param cache_key: param layers:  (Default value = None)
    :param raster_path: Default value = None)
    :param source_chunks: 
    :param layers:  (Default value = None)

    """

    rm = RasterManager(config, raster_path)

    prep_tasks = []

    if layers == None:
        layers = list(rm.layers.keys())

    for layer in layers:
        for i, source_chunk in enumerate(source_chunks):
            prep_tasks.append((config, cache_key, source_chunk, i, layer, raster_path))

    return prep_tasks


def prep_tasks(config, cache_key, source_chunks, layers, raster_path=None, debug=False):
    """Run _process_patch_args on all of the tasks so we can organize the inputs to scoring
    to alight with RasterInfo objects, per band and layer

    :param cache: type cache:
    :param source_chunks: type source_chunks:
    :param layers: type layers:
    :param config: param cache_key:
    :param raster_path: Default value = None)
    :param debug: Default value = False)
    :param cache_key: 
    :returns: rtype:

    """
    from pickle import PickleError

    logger.info("Prepare tasks")

    cache = config.cache

    prep_tasks_tasks = make_prep_tasks(config, source_chunks, cache_key, layers=layers, raster_path=raster_path)

    k = f'{cache_key}/prepped_tasks'

    if cache.exists(k):
        r = cache.get(k)
        logger.info(f"Got {len(r)} tasks from cache from key {k}")
        return r

    with nope_maybe():
        try:
            r = run_mp(_prep_batch, prep_tasks_tasks, debug=debug)
        except PickleError as e:
            import pickle
            logger.error(f"Failed to pickle task preparation jobs: {e}")

            _ = pickle.dumps(_prep_batch)

            try:
                _ = pickle.dumps(config)
            except TypeError as e:
                logger.error(f"Failed to pickle the config: {e}")

            try:
                _ = pickle.dumps(prep_tasks_tasks[0])
            except TypeError as e:
                logger.error(f"Failed to pickle task preparation jobs: {prep_tasks_tasks[0]}")

            raise RasterException(f"Failed to pickle task preparation jobs. ")

    cache.put(k, r)

    logger.info(f"Prepared {len(r)} tasks")

    return r


def chunk_tasks(config, cache_key, prepped_tasks, raster_path):
    """Read the tasks from the cache and create chunked tasks, ready for mp scoring

    :param config: param cache_key:
    :param prepped_tasks: param raster_path:
    :param cache_key: 
    :param raster_path: 

    """

    logger.info(f"Chunking scoring tasks for {len(prepped_tasks)} prep tasks")

    cache = config.cache

    k = f'{cache_key}/chunked_tasks'

    sorted_pt = defaultdict(list)
    for f in tqdm(prepped_tasks, desc='collect task', leave=True):
        pt = cache.get(f)
        assert len(pt) > 0, f'No prepped tasks  in {f}'
        for band, tasks in pt.items():
            for task in tasks:
                pt_key = (band, task['ri_key'])
                sorted_pt[pt_key].append(task)

    # Now split the band/var groups into chunks

    chunked_tasks = []
    for (band, var_key), tasks in tqdm(sorted_pt.items(), desc='chunk tasks', leave=True):

        sections = len(tasks) // min(2000, len(tasks))

        for i, chunk in enumerate(np.array_split(tasks, sections)):  # 2000 scores should be about 30 sec
            chunked_tasks.append((config, cache_key, band, var_key, i, chunk, raster_path))

    assert len(chunked_tasks) > 0

    logger.info(f"Created {len(chunked_tasks)} scoring task chunks")

    return chunked_tasks


def f_batch_score(config, cache_key, band, var_key, chunk_num, band_args, raster_path, debug=False):
    """

    :param config: param cache_key:
    :param band: param var_key:
    :param chunk_num: param band_args:
    :param raster_path: 
    :param cache_key: 
    :param var_key: 
    :param band_args: 

    """
    scores = []
    err = []

    cache = config.cache

    k = f'{cache_key}/scores/{var_key}/{band}/{chunk_num}'

    if cache.exists(k) and debug is False:
        return k

    rm = RasterManager(config, raster_path, cache_raster=True)
    ri = rm.search_index(var_key, band)

    if debug is True:
        band_args = band_args[:10]

    for ba in band_args:

        try:

            patch = rm.patch(ba['loc'], ri.layer)

            scores.append({
                'idx': ba['idx'],
                'lat': ba['loc'][0],
                'lon': ba['loc'][1],
                'layer': ba['ri_key'],
                'kernel': patch.kernel_f.__name__,
                'weights': patch.weight_name,
                'ringsums': np.ravel(patch.dist_sum().T.values).tolist()
            })

        except Exception as e:
            raise
            if debug is False:
                err.append((band, var_key, chunk_num, ba['idx'], e))
            else:
                raise

    cache.put(k, [scores, err])

    if debug is False:
        return k
    else:
        return [scores, err]


def batch_score(config, cache_key, df, layers, raster_path=None, debug=False):
    """

    :param config: param cache_key:
    :param df: param layers:
    :param raster_path: Default value = None)
    :param debug: Default value = False)
    :param cache_key: 
    :param layers: 

    """
    from random import shuffle

    logger.info('Starting batch scoring')

    if cache_key is None:
        cache_key = default_cache_key

    if debug:
        logger.debug('Sampling dataset for debugging')
        df = df.sample(100)

    source_chunks = chunk_dataframe(config, cache_key, df, len(df) // 100)

    prepped_tasks = prep_tasks(config, cache_key, source_chunks, layers, raster_path, debug=debug)

    chunked_tasks = chunk_tasks(config, cache_key, prepped_tasks, raster_path)

    # shuffle the tasks to get coverage of all layers if we want to
    # read and process intermediary results.
    shuffle(chunked_tasks)

    logger.info("Starting batch scoring")
    with nope_maybe():
        r = run_mp(f_batch_score, chunked_tasks)

    logger.info(f"Generated {len(r)} scoring files")

    return r


def list_score_files(config, cache_key):
    """ List all of the cached scoring files
    :param config:
    :type config:
    :param cache_key:
    :type cache_key:
    :return:
    :rtype:
    """
    cache = config.cache

    if cache_key is None:
        cache_key = default_cache_key

    ck = f'{cache_key}/scores/'

    logger.info(f"Compiling scores from {str(cache.joinpath(ck))} ")

    score_files = list(cache.list(ck, glob='**/*.pkl'))

    return score_files


def coalesce(config, cache_key, df, ignore_errors=False):
    """

    :param config: param cache_key:
    :param df: 
    :param cache_key: 

    """

    from pandas.errors import MergeError
    from .exceptions import BatchError

    cache = config.cache

    score_files = list_score_files(config, cache_key)

    logger.info(f"Found {len(score_files)} files")

    if len(score_files) == 0:
        logger.info('No cached filed; nothing to do')
        return None

    rows = []
    errors = []
    for arg_path in tqdm(score_files, leave=True):

        scores, errs = cache.get(arg_path)

        for s in scores:
            s.update({f'ring_{i+1}': v for i, v in enumerate(s['ringsums'])})
            del s['ringsums']
            rows.append(s)

        errors.extend(errs)

        if len(errors) > 10 and ignore_errors is False:
            break

    if len(errors) > 0:
        from itertools import islice
        logger.error(f'Got {len(errors)} errors. Showing first 10')
        for e in islice(errors, 10):
            print(e)
        if ignore_errors is False:
            raise BatchError("Caching process generated errors")

    if len(rows) == 0:
        raise BatchError("Didn't get any score rows")

    t = pd.DataFrame(rows)

    try:
        df.columns = [c.lower() for c in df.columns]
        t = df[['idx', 'geoid', 'geometry']].merge(t)
    except (MergeError, KeyError) as e:
        raise BatchError(f"Failed to merge on {['idx', 'geoid', 'geometry']} with dataset with cols : {t.columns} and {df.columns}")

    return t
