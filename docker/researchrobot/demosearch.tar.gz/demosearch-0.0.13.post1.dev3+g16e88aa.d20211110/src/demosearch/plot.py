import io
from functools import lru_cache

import contextily as cx
import cv2
import matplotlib.cm as cm
import numpy as np

def to_uint8(a):
    """

    :param a: 

    """
    t = np.nan_to_num(a)
    t = t - t.min()
    t = t / t.max() * 255
    return t.astype(np.uint8)


def to_float32(a):
    """

    :param a: 

    """
    t = np.nan_to_num(a)
    t = t - t.min()
    t = t / t.max()
    return t.astype(np.float32)


def ims(v, ax=None, dilate=None, cmap='turbo', alphaq=None, alpha=1, title=None, extent=None):
    """Plot a patch

    :param v: param ax:  (Default value = None)
    :param dilate: Default value = None)
    :param cmap: Default value = 'turbo')
    :param alphaq: Default value = None)
    :param alpha: Default value = 1)
    :param title: Default value = None)
    :param extent: Default value = None)
    :param ax:  (Default value = None)

    """
    import matplotlib.pyplot as plt

    # cmap = ListedColormap(np.insert(plt.get_cmap('Set1', 25).colors[:-1], 0, np.array([1,1,1,0]), axis=0))

    if ax is None:
        fig, ax = plt.subplots(1, figsize=(10, 10))

    t = to_uint8(v)

    if dilate is not None:
        t = cv2.dilate(t, np.ones((dilate, dilate), np.uint8), iterations=1)

    t = np.nan_to_num(t.astype("uint8"), 0)

    if alphaq:
        import cv2 as cv
        q = np.quantile(t, alphaq)
        alpha_mask = cv.threshold(t, q, 1, cv.THRESH_BINARY)[1] * alpha
    else:
        alpha_mask = None

    ax.imshow(t, cmap=cmap, origin='lower', alpha=alpha_mask, extent=extent)

    if title:
        ax.set_title(title)

    return ax


def plot_layers(rm, lat, lon):
    """Plot all of the patched in a layer

    :param rm: param lat:
    :param lon: 
    :param lat: 

    """
    import matplotlib.pyplot as plt

    patch, layers = rm.make_summary_patch(lat, lon)

    fig, axes = plt.subplots(4, 3, figsize=(15, 15))

    for i, ax in enumerate(np.ravel(axes)):
        if i < patch.shape[-1]:
            ax.set_title(layers[i])

            ims(patch[:, :, i], ax, dilate=2)


def scale10(a):
    """Rescale an array to 0 to 1

    :param a: 

    """

    a = a - np.nanmin(a)
    a = a / np.nanmax(a)
    return a




# Subset of basemap names
cx_preferred_providers = [
    'OpenStreetMap.Mapnik',
    'OpenStreetMap.HOT',
    'OpenTopoMap',
    'Stamen.Toner',
    'Stamen.TonerBackground',
    'Stamen.TonerHybrid',
    'Stamen.TonerLite',
    'Stamen.Watercolor',
    'Stamen.Terrain',
    'Stamen.TopOSMRelief',
    'Esri.WorldStreetMap',
    'Esri.DeLorme',
    # 'Esri.WorldTopoMap',
    'Esri.WorldImagery',
    'Esri.NatGeoWorldMap',
    'Esri.WorldGrayCanvas',
    'CartoDB.Positron',
    'CartoDB.DarkMatter',
    'CartoDB.Voyager',
    # 'NASAGIBS.ViirsEarthAtNight2012'
]

cx_providers = {}


def get_providers(provider):
    """

    :param provider: 

    """
    if "url" in provider:
        cx_providers[provider['name']] = provider
    else:
        for prov in provider.values():
            get_providers(prov)


get_providers(cx.providers)


def cx_source(name=None):
    """

    :param name: Default value = None)

    """

    if name is None:
        name = 'Stamen.Toner'

    source = cx_providers[name]

    return source


def basemap_image(bbox, epsg=None, map_name=None):
    """Get a basemap via contextilly for a bounding box.

    :param bbox: param epsg:  (Default value = None)
    :param map_name: Default value = None)
    :param epsg:  (Default value = None)

    """

    bbox = bbox.utm

    if epsg is None:
        epsg = bbox.epsg

    base, base_ext = cx.bounds2img(*bbox.ll, ll=True, source=cx_source(map_name))
    base, base_ext = cx.warp_tiles(base, base_ext, f"EPSG:{epsg}")

    return base, base_ext


def add_basemap(ax, bbox, epsg=None, map_name=None):
    """

    :param ax: param bbox:
    :param epsg: Default value = None)
    :param map_name: Default value = None)
    :param bbox: 

    """

    bbox = bbox.utm

    if epsg is None:
        epsg = bbox.epsg

    w, s, e, n = list(bbox.ll)
    base, base_ext = cx.bounds2img(w, s, e, n, ll=True, source=cx_source(map_name))
    base, base_ext = cx.warp_tiles(base, base_ext, f"EPSG:{epsg}")

    ax.imshow(base, extent=base_ext)

    cx.add_attribution(ax, cx_source(map_name)['attribution'])


def add_rings(ax, p, add_text=False, color='red'):
    """ Drawn rings on a patch.
    :param ax:
    :type ax:
    :param p:
    :type p:
    :return:
    :rtype:
    """
    import matplotlib.pyplot as plt

    from .kernel import meters_per_mile

    loc = p.loc

    try:
        x, y = list(loc.utm)
    except AttributeError:
        x, y = loc  # Assume it is a list or tuple

    for r in  [1*meters_per_mile, 3*meters_per_mile, 5*meters_per_mile]:
        cc = plt.Circle((x, y), r, color=color, linewidth=0.5, fill=False)
        ax.add_artist(cc)

        if add_text:
            ax.text(x, y - r, f"{round(r, -2)} m", fontsize=7, color='white', weight='bold',
                    bbox=dict(facecolor='gray', edgecolor='gray', boxstyle='round'))


def basemap(bbox, epsg=None, figsize=(10, 10)):
    """

    :param bbox: param epsg:  (Default value = None)
    :param figsize: Default value = (10)
    :param 10: 
    :param epsg:  (Default value = None)
    :param 10): 

    """
    import matplotlib

    matplotlib.use('Agg', force=True)

    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, figsize=figsize)

    add_basemap(ax, bbox, epsg)

    return fig, ax


def write_plot_to_buffer(ax, format='png'):
    """

    :param ax: param format:  (Default value = 'png')
    :param format:  (Default value = 'png')

    """

    fig = ax.get_figure()

    io_buf = io.BytesIO()
    fig.savefig(io_buf, format=format, dpi=fig.get_dpi(), bbox_inches='tight', pad_inches=0)

    from matplotlib.pyplot import close

    close(fig)

    return io_buf.getvalue()


def plot_to_image(overlay, bbox, format='png', figsize=(10, 10)):
    """Plot a base image and an overlay image to bytes

    :param overlay: param bbox:
    :param format: Default value = 'png')
    :param figsize: Default value = (10)
    :param 10: 
    :param bbox: 
    :param 10): 

    """

    fig, ax = basemap(bbox, figsize=figsize)

    overlay_ext = [bbox.utm.x_min, bbox.utm.x_max,
                   bbox.utm.y_min, bbox.utm.y_max]

    ax = ims(overlay, extent=overlay_ext, ax=ax)

    return ax


def find_peaks(rast, size=10, threshold=.1):
    """

    :param rast: param size:  (Default value = 10)
    :param threshold: Default value = .1)
    :param size:  (Default value = 10)

    """

    import numpy as np
    import scipy.ndimage as ndimage
    import scipy.ndimage.filters as filters

    from demosearch.kernel import k_circle

    data = to_float32(rast)

    # Neighborhood max and min. Returns a raster of same size as input
    footprint = k_circle(size=size, thresh=size)
    d_max = filters.maximum_filter(data, footprint=footprint)
    # Also get the min, to properly set the range, but it is probably
    # not necessary, because the data is pre-scaled to 0 to 1,
    # so the min will be very small everywhere.
    d_min = filters.minimum_filter(data, footprint=footprint)

    # Extract the points that set each neighborhood max
    maxima = (data == d_max)

    diff = ((d_max - d_min) > threshold)

    # Clear out all cells where the min max dif doesn't clear the
    # threshold.
    maxima[diff == 0] = 0

    # Labeling assigns a value to each cluster of contiguous, same-values points.
    labeled, num_objects = ndimage.label(maxima)

    # Get the x.y positions of the center of each of the labeled clusters.
    return np.array(ndimage.center_of_mass(data, labeled, range(1, num_objects + 1)))
