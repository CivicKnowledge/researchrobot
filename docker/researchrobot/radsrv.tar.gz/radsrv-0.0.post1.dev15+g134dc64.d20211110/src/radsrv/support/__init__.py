from pathlib import Path
from csv import DictReader

# Load the layers data
p = Path(__file__).parent.joinpath('layers.csv')

with p.open() as f:
    r = DictReader(f)
    layers = { e['layer']:e for e in list(r)}
