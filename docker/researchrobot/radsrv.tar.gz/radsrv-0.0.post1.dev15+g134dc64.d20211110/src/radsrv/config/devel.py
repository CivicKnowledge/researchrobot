import redis

SESSION_TYPE = 'redis'
SESSION_PERMANENT = False
SESSION_USE_SIGNER = True
SESSION_REDIS =  None #redis.from_url('redis://:redis_password@barker:6379/0', health_check_interval=15)