from flask import jsonify, request, current_app as app, Response, url_for
from flask import send_file
from werkzeug.exceptions import BadRequest, InternalServerError
from flask import Flask, render_template_string, request, session, redirect, url_for
from flask_session import Session
from demosearch.kernel import k_step

from . import bp


@bp.route('/test', methods=('GET', 'POST'))
def register():
    """ """
    if request.method == 'POST':
        return jsonify({'method': 'POST', 'test': request.method})
    else:
        return jsonify({'method': 'GET', 'test': request.method})

@bp.route('/layers')
def layers():
    """ """

    return jsonify(app.rm.formula_layer_groups)

@bp.route('/mapnames')
def mapnames():
    """ """
    from demosearch.plot import cx_providers
    return jsonify(cx_providers)

@bp.route('/geocode', methods=('GET',))
def geocode():
    """ """

    query = request.args.get('q')

    if not query:
        return jsonify({'error': 'No input'})

    r = app.rm.geocoder.geocode(query)

    return jsonify({'response': r})

@bp.route('/geocode', methods=('POST',))
def geocode_many():
    """Geocode multiple addresses in parallel"""


def patch_hash(*args):
    """

    :param *args: 

    """
    import numpy as np

    h = 0

    for arg in args:
        if isinstance(arg, list):
            arg = tuple(arg)
        h = h ^ hash(arg)

    return hex(np.uint64(h))[2:]  # Ensure it's always positive.

def multibool(v):
    try:
        return bool(int(v))
    except (ValueError, TypeError):
        if v == '0' or v is None:
            return False
        return bool(v)

def robust_int(v):
    try:
        return int(v)
    except ValueError:
        return 0

def robust_float(v):
    try:
        return float(v)
    except:
        return None

def patch_config(layer_name, pos, request):
    """

    :param layer_name: 
    :param lat: 
    :param lon: 
    :param request: 

    """

    from radsrv.ui.util import ll_decode


    alphaq = robust_float(request.args.get('aq', 0))
    opacity = robust_float(request.args.get('op'))
    colormap = request.args.get('cm')
    map_name = request.args.get('bm')

    add_rings = multibool(request.args.get('rn', 0))
    markers_encoded = request.args.get('mk', None)
    ignore_cache = int(request.args.get('ic', 0))
    legend = multibool(request.args.get('lg', 0))

    h = patch_hash(layer_name, *pos, alphaq, opacity, colormap, map_name, markers_encoded,
                  add_rings, legend)

    opt = {
        'rings': add_rings,
        'ignore_cache': bool(ignore_cache),
        'legend': legend
    }

    def proc_patch(p):
        """Apply the above configuration to a patch

        :param p: 

        """

        # Formulas are not automatically convolved
        if p.layer_type == 'l':

            if p.ri.geom_type == 'Point':
                # Make points easier to see
                p = p.nanz.convolve(k_step(150)).binarize

            # The alpha, transparency, map and color setters will not change the
            # value if the input is None
            p = p.transparency(opacity).map(map_name).color(colormap)

        elif p.layer_type == 'f':

            p = p.kclip # Return formula layer to same size as non formula layer.

        if markers_encoded:
            positions = [app.rm.process_location_arg(e) for e in ll_decode(markers_encoded) ]
            p.set_markers(positions)

        return p

    return h, opt, proc_patch

def _patch(pos, layer_name):
    """

    :param lat: param lon:
    :param layer_name: 
    :param lon: 

    """
    import io

    try:

        h, opt, proc_patch = patch_config(layer_name, pos, request)

        image_key = f'image/patch/{h}'

        rds = app.redis

        image_data = rds.get(image_key)

        if not image_data or opt.get('ignore_cache'):
            app.logger.info(f"Cache miss: {image_key}, ic={opt.get('ignore_cache')}")

            p = app.rm.patch(pos, layer_name)

            p = proc_patch(p)

            image_data = p.show(return_buffer=True, show_rings=opt.get('rings'), legend=opt.get('legend'))

            rds.set(image_key, image_data)
        else:
            app.logger.info(f"Cache hit: {image_key}, ic={opt.get('ignore_cache')}")

        return send_file(io.BytesIO(image_data), mimetype='image/png')
    except Exception as e:
        # FIXME! Sometimes p.show(return_buffer=True) throws an error in the Matplotlib renderer,
        # With a private Exception Done
        if 'Done' in str(e) or 'RendererAgg' in str(e):
            raise InternalServerError(e)
        raise
        raise Exception(f" {pos} {e}")
        raise BadRequest(e)


@bp.route('/patch/<layer_name>/<lat>/<lon>')
def patch_ll(lat, lon, layer_name):

    return _patch((lat, lon), layer_name)


@bp.route('/patch/<layer_name>/<pos>')
def patch_gh(pos, layer_name):
    """Patch with the location specified as a geohash or lat lon, with
    multiple values seperated by a SEMICOLON"""

    import libgeohash as gh
    from radsrv.util.geo import decode_pos

    dpos = decode_pos(pos)

    return _patch(dpos, layer_name)

@bp.route('/<layer_name>/score')
def score(layer_name):
    """

    :param layer_name: 

    """
    import json


    location_query = request.args.get('q')

    p = app.rm.patch(location_query, layer_name)
    s = p.score()

    return jsonify(
        {
            'score': s[0].iloc[0]['score'],
            'pct': s[0].iloc[0]['pct'],
            'rings': json.loads(s[1].T.to_json(orient='table'))['data']
        }
    )


@bp.route('/scores')
def scores():
    """ """
    import json

    location_query = request.args.get('q')

    layers = request.args.get('l').split(',')

    p = app.rm.patches(location_query, layers)
    s = p.score()

    return json.loads(s[0].to_json(orient='table'))


@bp.route('/img/colorbars')
def colormaps():
    """ """

    width = request.args.get('width')

    from ..util.colormap import make_colormap_sprite

    file_object = make_colormap_sprite(width)

    return send_file(file_object, mimetype='image/PNG')


@bp.route('/css/colorbars')
def colormaps_css():
    """ """

    from ..util.colormap import colormap_css

    width = request.args.get('width')

    return Response(colormap_css(url=url_for('api.colormaps', width=width), width=width), mimetype="text/css")

# Testing

@bp.route('/test/redis')
def test_redis():
    """Test Incrementing redis"""

    if not 'test_session_i' in session:
        session['test_session_i'] = 0
        i = None
    else:
        session['test_session_i'] = session['test_session_i']+1
        i = session['test_session_i']

    return jsonify(
        {'x':app.redis.incr('x') ,
        'session': i}
    )

@bp.route('/test/request', methods=('GET', 'POST'))
def test_request():
    """Return a jsonified request"""

    return jsonify(
        {
            'args': request.args,
            'form': request.form,
            'values': request.values,
            'data': request.data.decode('utf8'),
            'session': session
        }
    )

