import libgeohash as gh
from demosearch.exceptions import CacheMiss
from flask import (
    request, current_app as app, render_template,
    url_for, flash, redirect, session
)
from radsrv.api.routes import multibool
from radsrv.util.report_cache import get_addresses
from radsrv.util.report_cache import set_report_config, get_report_config

from . import bp, next_ic_index
from .forms import *


def cache_patch(p):
    """Write a patch image to the file cache

    :param p: 

    """
    idx = next_ic_index()
    with app.rm.cache.joinpath('cached_images', str(idx), mkdir=True).open('wb') as f:
        f.write(p.show(return_buffer=True))

    return idx


def make_ordinal(n):
    '''
    Convert an integer into its ordinal representation::

        make_ordinal(0)   => '0th'
        make_ordinal(3)   => '3rd'
        make_ordinal(122) => '122nd'
        make_ordinal(213) => '213th'

    From:  https://stackoverflow.com/a/50992575
    '''
    n = int(n)
    suffix = ['th', 'st', 'nd', 'rd', 'th'][min(n % 10, 4)]
    if 11 <= (n % 100) <= 13:
        suffix = 'th'
    return str(n) + suffix


example_addresses = [
    """1605 E Garfield St Phoenix, Az 85006
    5101 N 16Th St, Phoenix, Az 85016-3904
    546 E Osborn Rd, Phoenix, Az 85012-2314
    900 E 11th St, Austin, TX 78702
    907 W  5Th St, Austin, Tx 78703
    10107 Research Blvd, Austin, Tx 78759
    1801 E. 51St Street Bldg A, Austin, Tx 78723
    5820 Broadway The Bronx, Ny 10463
    225 W 79Th St New York, Ny 10024
    1452 2Nd Ave New York, Ny 10021""",
    """7819 Nw 166th Terrace, Hialeah, FL 33016
    940 West 81st Road, Hialeah, FL 33014
    7975 Nw 154th St # 230, Hialeah, FL 33016
    2823 Hertha Avenue, Orlando, FL 32826
    301 East Pine St # 1400, Orlando, FL 32801
    4542 L B Mcleod Road, Orlando, FL 32811
    108 1/2 South Lincoln St, Wilmington, DE 19805
    2500 Grubb Road # 210, Wilmington, DE 19810
    2609 Ferris Road, Wilmington, DE 19805
    """,
    """1842 North Elston Avenue, Chicago, IL 60642
    66TH ST., Chicago, IL 60602
    1400 s lake shore dr, Chicago, IL 60605
    600 North Pearl St # S201, Dallas, TX 75201
    7109 Military Parkway # D, Dallas, TX 75227
    3407 Borger St, Dallas, TX 75212
    2615 Heatherwood Drive, Tampa, FL 33618
    1739 West Walnut Street, Tampa, FL 33607
    7302 West Hillsborough Avenue, Tampa, FL 33634
    """,
    """9430 West National Avenue, Milwaukee, WI 53227
    255 North 21st St, Milwaukee, WI 53233
    8620 West Fond Du Lac Avenue, Milwaukee, WI 53225
    6301 Oxford Avenue, Philadelphia, PA 19111
    2215 arch st # 1, Philadelphia, PA 19103
    302 North Broad St, Philadelphia, PA 19103
    7700 Bonhomme Avenue, Saint Louis, MO 63105
    8204 Toddy Avenue, Saint Louis, MO 63114
    Po Box 2632, Saint Louis, MO 63116
    """,
    """30161 Mission Rd San Diego, Ca,  92003
   2420 Vista Way San Diego, Ca,  92054
   2135 Valley Pkwy San Diego, Ca,  92027
   2254 Moore St San Diego, Ca,  92110
   9302 Bond Ave San Diego, Ca,  92021
   10951 Sorrento Valley Rd San Diego, Ca,  92121"""]


def get_example_adresses():

    from textwrap import dedent

    if not 'ea_idx' in session:
        session['ea_idx'] = 0
    else:
        session['ea_idx'] = (session['ea_idx'] + 1) % len(example_addresses)

    i = session['ea_idx']
    return [e.strip() for e in example_addresses[i].splitlines()]


@bp.context_processor
def inject_mp_url():
    def _mlp_url(p, **kwargs):
        return url_for('api.patch_gh', pos=p.bbox.ll.to_geohash(), layer_name=p.layer_name,
                       mk=';'.join([m.geohash for m in p.markers]), **kwargs)

    def _layer_info(p):
        return layer_info.get(p.name, {})

    return dict(mlp_url=_mlp_url, patch_info=_layer_info, ord_inc=make_ordinal,
                example_addresses=get_example_adresses)


@bp.context_processor
def inject_patch_image_support():
    """Functions to support the patch_image macro """

    def _color_map(p):
        return request.args.get('cm', p.colormap.name)

    def _patch_image_args(p, rings=0):

        args = dict(request.args)

        if p.layer_type == 'f':
            if 'cr' in args:
                del args['cr']

        if p.layer_type == 'f':
            if 'cm' in args:
                del args['cm']
        else:
            args['cm'] = _color_map(p)

        args['rn'] = args.get('rn', rings)

        for a in ('address',):
            if a in args:
                del args[a]

        return args

    def _patch_image_url(p, rings=0):

        args = _patch_image_args(p, rings)

        return url_for('api.patch_gh', layer_name=p.name, pos=p.geohash, **args)

    return {
        'color_map': _color_map,
        'patch_image_url': _patch_image_url,
        'patch_image_args': _patch_image_args
    }


@bp.route('report')
def report_session():
    from radsrv.util.report_cache import mk_addr_key

    report_key = session.get('addresses_key')

    if report_key and app.redis.exists(mk_addr_key(report_key)):
        return redirect(url_for('ui.report', report_key=report_key))
    else:
        flash(f"Couldn't find report for the report key  {report_key}", "danger")
        return redirect(url_for('home'))


@bp.route('report/<report_key>', methods=('GET', 'POST'))
def report(report_key):
    """ """
    from radsrv.util.report_cache import mk_addr_key
    from demosearch.kernel import DEFAULT_KERNEL, k_1miles,k_3miles,k_5miles

    form = ReportForm()

    if form.layer.data:
        layer = form.layer.data
    else:
        layer = 'total_population'

    uas = get_addresses(app, report_key)

    if not uas:
        if app.redis.exists(mk_addr_key(report_key)):
            flash(f"Found report key {report_key} but the report is empty", "danger")
        else:
            flash(f"Couldn't find addresses for the report key {report_key}", "danger")

        return redirect(url_for('home'))

    ps = app.rm.patches(uas, layer)
    metro_g = ps.group_by_cbsa()

    metros = []
    for cbsa, m in metro_g.items():
        scores = m.score([DEFAULT_KERNEL, k_1miles,k_3miles,k_5miles])\
            .sort_values('pct', ascending=False).to_dict(orient='records')
        metros.append( (cbsa, m, scores))


    return render_template('ui/overview.html',
                           report_key=report_key, form=form, metros=metros, colormap='plasma')


@bp.route('patch')
def patch_query():
    """ """

    loc = request.args.get('lc')
    layer = request.args.get('lr')

    p = app.rm.patch(loc, [layer]).label(loc)

    return render_template('ui/patch.html', patch=p, args=request.args)


@bp.route('patch/<layer>/<geohash>')
def patch(layer, geohash):
    """ """

    address = request.args.get('address')

    p = app.rm.patch(geohash, [layer])

    if address is not None:
        p = p.replace(address=address)

    args = dict(request.args)

    def del_maybe(v):
        if v in args:
            del args[v]

    if p.layer_type == 'f':
        del_maybe('cm')
        del_maybe('cr')

    if 'lc' in args:
        del args['lc']
    if 'lr' in args:
        del args['lr']

    return render_template('ui/patch.html', patch=p, args=request.args)


def cached_location_form(report_key):
    form = None
    if request.method == 'GET':

        try:
            form_data = get_report_config(app, report_key, 'layers')
            app.logger.info(f"Loaded Form Data {form_data}")
        except (CacheMiss):
            app.logger.info(f"Form Data cache miss")
            form_data = {}

        try:
            form = LocationForm(data=form_data)
        except ValueError as e:
            app.logger.info(f"Malformed cached form data: {form_data}: {e}")

    if form is None:
        form = LocationForm()

    return form


def get_layers(form):
    # Copy the data so the next extend() doesn't add into the form
    try:
        layers = [l for l in form.layers.data[:] if l]
    except TypeError:
        layers = []

    if form.formulas.data:
        layers = [l for l in form.formulas.data.splitlines() if l] + layers

    if not layers:
        layers = ['total_population']

    app.logger.info(f"Layers {layers}")

    if len(layers) > 6:
        flash(f"Only 6 total layers and formulas are allowed ", "danger")
        layers = layers[:6]

    return layers


def _location_cbsa(report_key, geohash=None, geoid=None):
    """ """

    form = cached_location_form(report_key)

    layers = get_layers(form)

    uas = get_addresses(app, report_key, geohash=geohash, geoid=geoid)

    if not uas:
        # Didn't find the cache UA, so just decode the geohash
        uas = [app.rm.ua_from_ll(gh.decode(uas[0].geohash))]

    ps, loc_err, layer_err = app.rm.patches(uas, layers, errors='return')

    for e in loc_err:
        flash(f"Location error: {str(e[1])}", "danger")

    for e in layer_err:
        flash(f"Layer error: {str(e[1])}", "danger")

    d = form.data
    del d['csrf_token']
    set_report_config(app, report_key, 'layers', d)

    return form, ps


@bp.route('metro/<report_key>/<cbsa_geoid>', methods=('GET', 'POST'))
def metro(report_key, cbsa_geoid):
    """ """

    form, ps = _location_cbsa(report_key, geoid=cbsa_geoid)

    g = ps.group_by_location()

    return render_template('ui/location.html',
                           report_key=report_key,
                           rings=int(multibool(form.rings.data)),
                           location=ps[0].cbsa.name, patch_groups=g, form=form, args=request.args)


@bp.route('location/<report_key>/<location_key>', methods=('GET', 'POST'))
def location(report_key, location_key):
    form, ps = _location_cbsa(report_key, geohash=location_key)

    return render_template('ui/location.html',
                           report_key=report_key,
                           rings=int(multibool(form.rings.data)),
                           location=ps[0].address, patch_groups={None: ps}, form=form, args=request.args)


@bp.route('help/colorbars')
def help_colorbars():
    """ """
    from ..util.colormap import all_colormaps

    return render_template('ui/help/colorbars.html', all_cm=all_colormaps())


@bp.route('help/locationslayers')
def help_loclayers():
    """ """

    return render_template('ui/help/loc_layers.html',
                           layers=app.rm.formula_layer_groups)


@bp.route('help/formulas')
def help_formulas():
    """ """

    return render_template('ui/help/formulas.html',
                           layers=app.rm.formula_layer_groups)


@bp.route('help/maps')
def help_mapnames():
    """ """
    from demosearch.plot import cx_preferred_providers

    layer = 'cafe'
    pos = '9v6kppwz'  # Somewhere in Austin

    return render_template('ui/help/mapnames.html',
                           basemaps=cx_preferred_providers,
                           layer=layer, pos=pos)
