from flask_wtf import FlaskForm
from wtforms import (StringField, SelectField, TextAreaField,
                     SelectMultipleField, BooleanField,
                     ValidationError)
from wtforms.validators import DataRequired, Length
from radsrv.support import layers as layer_info

class RowsLength(Length):
    """ """
    def __call__(self, form, field):
        l = field.data and len(field.data.strip().splitlines()) or 0
        if l < self.min or self.max != -1 and l > self.max:
            message = self.message
            if message is None:
                if self.max == -1:
                    message = field.ngettext('Field must be at least %(min)d lines long.',
                                             'Field must be at least %(min)d lines long.', self.min)
                elif self.min == -1:
                    message = field.ngettext('Field cannot be longer than %(max)d lines.',
                                             'Field cannot be longer than %(max)d lines.', self.max)
                elif self.min == self.max:
                    message = field.ngettext('Field must be exactly %(max)d lines long.',
                                             'Field must be exactly %(max)d lines long.', self.max)
                else:
                    message = field.gettext('Field must be between %(min)d and %(max)d lines long.')

            raise ValidationError(message % dict(min=self.min, max=self.max, length=l))

important_layers = [
    'households',
    'housing_rented_college',
    #'households_unmaried',
    #'households_cohabiting',
    'housing_owned',
    'total_population',
    'population_18lt',
    'seniors',
    'manufacturing_ocupations',
    'commute_25gte',
    'commute_25lt',
    'highway',
    'primary',
    'secondary',
    'tertiary',
    'active',
    'amenity',
    'bar',
    'cafe',
    'casual',
    'entertain',
    'food',
    'playpark',
    'restaurant',
    'shop',
    'travel',
    'safegraph_bars',
    'gas_conveniece',
    'snack_bev',
    'ls_restaurants',
    'hardware'
]

layer_choices = [('','')] + [ (e, layer_info.get(e)['title']) for e in important_layers]

class ReportForm(FlaskForm):
    """ """
    layer = SelectField('Layer', choices=layer_choices)

class LocationForm(FlaskForm):
    """ """
    layers = SelectMultipleField('Layers', choices=layer_choices)
    rings = BooleanField('Show Rings')
    formulas = TextAreaField('Formulas')

class AddressesForm(FlaskForm):
    """ """
    names = TextAreaField('Addresses', validators=[DataRequired(), RowsLength(max=10)])
    layers = SelectMultipleField(u'Layers', choices=layer_choices)
    business_type = SelectField('Business Type',
                                choices='cafe entertain restaurant active bar'.split(),
                                validators=[DataRequired()])


class OverviewForm(FlaskForm):
    """ """
    names = TextAreaField('Addresses', validators=[DataRequired(), RowsLength(max=10)])
    layer = SelectField(u'Layer', choices=layer_choices)


class FormulaForm(FlaskForm):
    """ """
    location = StringField('Location', validators=[DataRequired()])
    formula = TextAreaField('Formula', validators=[DataRequired()])
