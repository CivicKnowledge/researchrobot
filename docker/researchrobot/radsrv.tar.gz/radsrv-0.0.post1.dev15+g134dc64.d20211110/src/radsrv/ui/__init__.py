from multiprocessing import Value
from werkzeug.exceptions import BadRequest

from flask import (
    Blueprint, flash, g, redirect, render_template, request,  session, url_for,
    current_app as app
)


bp = Blueprint('ui', __name__, url_prefix='/ui',
                        template_folder='templates',
                        static_folder='static')

@bp.errorhandler(BadRequest)
def handle_bad_request(e):
    """

    :param e: 

    """

    app.logger.error('Bad Request!')
    #flash('Form expired', 'warning')
    return redirect(request.base_url)



image_cache_index = Value('i', 0)

MAX_IC_INDEX = 50

def next_ic_index():
    """ """
    with image_cache_index.get_lock():
        image_cache_index.value += 1
        if image_cache_index.value > MAX_IC_INDEX:
            image_cache_index.value = 0
    return image_cache_index.value

from . import routes
