import json
import zlib
import base64
import libgeohash as gh
from urllib.parse import urlencode

def list_encode(a):
    """Encode a python list into json, then compress, then base64

    :param a:

    """
    return base64.urlsafe_b64encode(zlib.compress(json.dumps(a).encode('utf8'))).decode('utf8')

def list_decode(d):
    """Encode a python list into json, then compress, then base64

    :param d:

    """
    return json.loads(zlib.decompress(base64.urlsafe_b64decode(d)))

def ll_encode(a):
    """Encode tuples of lat/lon points as a string of geohashes"""
    return ';'.join([gh.encode(*e, 8) for e in a])

def ll_decode(d):
    """Decode encoded lat/lon points"""

    return [gh.decode(e) for e in d.split(';')]

