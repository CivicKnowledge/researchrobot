from flask import render_template, url_for, jsonify, session, redirect
from flask_wtf import FlaskForm
from radsrv.app import app  # Needed to break circular import
from radsrv.ui.forms import RowsLength
from radsrv.util.report_cache import cached_addresses, get_addresses
from wtforms import (SubmitField)
from wtforms import (TextAreaField)
from wtforms.validators import DataRequired


class AddressesForm(FlaskForm):
    """ """
    addresses = TextAreaField('Addresses', validators=[DataRequired(), RowsLength(max=10)])
    submit = SubmitField(label='Submit')
    examples = SubmitField(label='Example Addresses')


@app.route('/', methods=('GET', 'POST'))
def home():
    """ """
    from radsrv.util.report_cache import mk_addr_key

    form = AddressesForm()

    def render_page(addresses=[]):
        form.addresses.data = '\n'.join([e.title() for e in addresses])
        return render_template('main.html', form=form)

    def success(report_key):
        return redirect(url_for('ui.report', report_key=report_key))

    def convert_addresses(addresses):
        report_key, uas = cached_addresses(app, addresses)
        session['report_key'] = report_key
        return report_key

    if form.examples.data == True:
        # User selected example data; re-display the page with the new addresses
        from radsrv.ui.routes import get_example_adresses

        ea = get_example_adresses()

        form.addresses.data = '\n'.join(ea)
        addresses = ea
        return render_page(addresses)

    elif form.submit.data == True:
        # User submitted the form with own addresses
        if form.addresses.data:  # And the user supplied data
            addresses = [e.strip() for e in form.addresses.data.splitlines()]
            if not form.validate_on_submit():
                addresses = addresses[:10]  # Assume error b/c there are too many
                return render_page(addresses)
            else:
                return success(convert_addresses(addresses))
        else:
            return render_page()  # User did not, so try again

    else:
        # Probably just getting the form
        if 'report_key' in session and app.redis.exists(mk_addr_key(session['report_key'])):
            # Show user prior addresses
            report_key = session['report_key']
            uas = get_addresses(app, report_key)
            if not uas:
                return render_page()
            addresses = [e.spec for e in uas]

            return render_page(addresses)
        else:
            # New session, show blank
            return render_page()


def has_no_empty_params(rule):
    """

    :param rule:

    """
    defaults = rule.defaults if rule.defaults is not None else ()
    arguments = rule.arguments if rule.arguments is not None else ()
    return len(defaults) >= len(arguments)


@app.route("/site-map")
def site_map():
    """ """
    links = []
    for rule in app.url_map.iter_rules():
        # Filter out rules we can't navigate to in a browser
        # and rules that require parameters
        if "GET" in rule.methods and has_no_empty_params(rule):
            url = url_for(rule.endpoint, **(rule.defaults or {}))
            links.append((url, rule.endpoint))
    # links is now a list of url, endpoint tuples
    return jsonify(links)
