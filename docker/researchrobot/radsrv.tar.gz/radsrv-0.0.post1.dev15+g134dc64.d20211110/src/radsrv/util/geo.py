def decode_pos(v):
    """Decode a URL path element that specifies a position or a bounding box"""

    import libgeohash as gh
    from itertools import chain

    from demosearch.geo import decode_geohash

    try:
       return decode_geohash(v)
    except TypeError:
        return [float(e) for e in v.split(';')]


