import pickle

report_key_prefix = 'reports'
addr_key_suffix = 'addresses'
loc_key_suffix = 'location'


def mk_addr_key(key):
    return f"{report_key_prefix}/{key}/{addr_key_suffix}"


def clean_addresses(addresses):
    import hashlib, base64

    if not isinstance(addresses, (list, tuple)):
        addresses = addresses.splitlines()

    addresses = [e.strip().lower() for e in addresses if e]

    # Key that identifies this particular set of addresses

    key = base64.urlsafe_b64encode(hashlib.sha256('\n'.join(addresses).encode('utf8')).digest()).decode('utf8')[:16]

    if not addresses:
        return key, None
    else:
        return key, addresses


def get_addresses(app, key, geohash=None, geoid=None):
    o = app.redis.get(mk_addr_key(key))

    if o is None:
        return None
    else:
        uas = pickle.loads(o)

    if geohash is not None:
        # Get addresses by it's geohash
        return [e for e in uas if e.geohash == geohash]

    elif geoid is not None:
        # Get addresses by CBSA geoid
        return [e for e in uas if e.cbsa.geoid == geoid]

    else:
        return uas


def cached_addresses(app, addresses):
    """Check if there are cached addresses. If not,
    convert to UserArgs and cache the result"""

    key, addresses = clean_addresses(addresses)

    if not addresses:
        return None, None

    uas = get_addresses(app, key)

    if uas is None:
        uas = app.rm.geocode_user_args(addresses)

        app.redis.set(mk_addr_key(key), pickle.dumps(uas))

    return key, uas


def mk_report_config_key(report_key, group):
    return f"{report_key_prefix}/{report_key}/{group}"


def get_report_config(app, report_key, group):
    from demosearch.exceptions import CacheMiss

    v = app.redis.get(mk_report_config_key(report_key, group))
    if v:
        return pickle.loads(v)
    else:
        raise CacheMiss()


def set_report_config(app, report_key, group, arg):
    o = pickle.dumps(arg)
    app.redis.set(mk_report_config_key(report_key, group), o)
