import matplotlib.cm as cm
import numpy as np
import matplotlib.pyplot as plt

line_rep = 20

def make_colormap_array(width=500):
    """Create a colormap sprite with one colormap per row.

    :param width:  (Default value = 500)

    """


    cm_list = plt.colormaps()

    cm_rows = []
    for cm_name in cm_list:
        color_map = cm.get_cmap(cm_name)
        g = np.linspace(0, color_map.N, width).astype(np.uint8)
        for i in range(line_rep):
            cm_rows.append(color_map(g.reshape(1, width)))


    return np.vstack(cm_rows)

# Mostly from https://stackoverflow.com/a/56948059
def make_colormap_sprite(width=500):
    """Create a colormap sprite with one colormap per row.
    
    Send this as an image in flask with:
    
        return send_file(file_object, mimetype='image/PNG')

    :param width:  (Default value = 500)

    """
    from PIL import Image
    import io

    width = int(width)  # Is used as a query parameter

    a = make_colormap_array(width)[:, :, 0:3] # Drop Alpha

    a = (a * 255).astype('uint8')

    img = Image.fromarray(a)

    file_object = io.BytesIO()

    img.save(file_object, 'PNG')

    file_object.seek(0)

    return file_object

def all_colormaps():
    """ """
    return list(plt.colormaps())

def colormap_css(url, width=500):
    """

    :param url: 
    :param width:  (Default value = 500)

    """

    import inspect

    css_blocks = []

    width = int(width) # Is used as a query parameter


    css_blocks.append(inspect.cleandoc(
        """
        /* Turn off image anti-aiasing */
        img { 
            image-rendering: optimizeSpeed;             /* STOP SMOOTHING, GIVE ME SPEED  */
            image-rendering: -moz-crisp-edges;          /* Firefox                        */
            image-rendering: -o-crisp-edges;            /* Opera                          */
            image-rendering: -webkit-optimize-contrast; /* Chrome (and eventually Safari) */
            image-rendering: pixelated; /* Chrome */
            image-rendering: optimize-contrast;         /* CSS3 Proposed                  */
            -ms-interpolation-mode: nearest-neighbor;   /* IE8+                           */
        }
        """

    ))

    css_blocks.append(inspect.cleandoc(
        """
        .colorbar-min {
            float: left;
        }
        
        .colorbar-max {
            float: right;
        }
        """

    ))


    for i, cm_name in enumerate(plt.colormaps()):
        cmap = cm.get_cmap(cm_name)

        css_blocks.append(inspect.cleandoc(
            f"""

            .colorbar-{cm_name} {{

                image-rendering: pixelated;
                               
                height: {line_rep}px;
                width: {width-1}px;
                background-image: url('{url}') ;
                background-position: -0px -{i*line_rep}px; 
                
                transform:scale(1, {20/line_rep});

                padding: 2px;
                color: white;
                font-weight: bold; 
                font-size: 12px;
                text-shadow: 1px 1px 2px black;

            }}



            """
        ))

    return '\n'.join(css_blocks)

