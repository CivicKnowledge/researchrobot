from flask import Flask, render_template, url_for, jsonify, session
from flask_session import Session
from flask_bootstrap import Bootstrap
from flask_wtf.csrf import CSRFProtect
import demosearch as ds
from os import environ

csrf = CSRFProtect()

SESSION_TYPE = 'redis'

def create_app():
    """ """

    app = Flask(__name__,instance_relative_config=True)

    app.cf = ds.ConfigFile.default(testing=app.testing)
    app.rm = app.cf.manager
    app.rm.open()
    app.redis = app.cf.redis

    try:
        app.config.from_envvar('FLASK_APP_CONFIG_FILE')
    except RuntimeError:
        app.config.from_object('radsrv.config.devel') # Load the configutation

    if not app.config.get('SECRET_KEY' ):
        app.config['SECRET_KEY'] = environ.get('FLASK_SECRET_KEY', 'OYNA7EkNlwKR0dT0')

    app.config['SESSION_REDIS'] = app.cf.redis

    Bootstrap(app)

    from . import api
    app.register_blueprint(api.bp)

    from . import ui
    app.register_blueprint(ui.bp)

    csrf.init_app(app)

    return app

app = create_app()

import logging
logging.basicConfig( level=logging.INFO,
                    format=f'%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s')

if __name__ == '__main__':
    app.run()

import radsrv.routes