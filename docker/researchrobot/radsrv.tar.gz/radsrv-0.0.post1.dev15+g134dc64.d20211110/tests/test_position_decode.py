import unittest
import radsrv
from contexttimer import Timer
from urllib.parse import quote_plus

from tests.locations import locations
import warnings

# ResourceWarning: unclosed <socket.socket fd=15, family=AddressFamily.AF_INET, type=SocketKind.SOCK_STREAM, proto=6, laddr=('192.168.1.49', 52289), raddr=('192.168.1.30', 8080)>
#   r = gcf(query, gc_key)


class TestPositionDecode(unittest.TestCase):
    """ """

    def setUp(self):
        """ """

        radsrv.app.config['TESTING'] = True
        self.app = radsrv.app.test_client()

    def test_something(self):
        """ """

        from radsrv.util.geo import decode_pos

        pos_inputs = [
            "-97.8547234409487;30.232442799735953;-97.61348756746735;30.437076534477367",
            "-97.8547234409487;30.232442799735953",
            'c22gzv9',
            'c22gzv9k23',
            'c22gzv9k23;c22gzv9k23'
        ]

        for e in pos_inputs:
            print(decode_pos(e),e)





if __name__ == '__main__':
    unittest.main()
