import unittest
import radsrv
from contexttimer import Timer
from urllib.parse import quote_plus

from tests.locations import locations
import warnings

# ResourceWarning: unclosed <socket.socket fd=15, family=AddressFamily.AF_INET, type=SocketKind.SOCK_STREAM, proto=6, laddr=('192.168.1.49', 52289), raddr=('192.168.1.30', 8080)>
#   r = gcf(query, gc_key)


class TestImageLoad(unittest.TestCase):
    """ """

    def setUp(self):
        """ """

        radsrv.app.config['TESTING'] = True
        self.app = radsrv.app.test_client()

    def test_something(self):
        """ """
        rv = self.app.get('/api/test')

        print(rv.get_data())

    def test_geocode_to_image(self):
        """ """
        from time import sleep
        import json
        from address_parser import Parser

        for l in locations:

            try:
                rv = self.app.get(f'api/geocode?q={quote_plus(str(l).encode("ascii"))}').json
                lat, lon = (rv['response']['lat'],rv['response']['lng'])

                with Timer() as t:
                    rv = self.app.get(f"api/tracts_pop_total_population/{lat}/{lon}/patch")
                    print(rv)
                print(t.elapsed)

            except Exception as e:
                raise
                print("ERROR", l)

        for l in locations:

            try:
                rv = self.app.get(f'api/geocode?q={quote_plus(str(l).encode("ascii"))}').json
                lat, lon = (rv['response']['lat'],rv['response']['lng'])

                with Timer() as t:
                    rv = self.app.get(f"api/tracts_pop_total_population/{lat}/{lon}/patch")
                    #print(rv)
                print(t.elapsed)

            except Exception as e:
                raise
                print("ERROR", l)




if __name__ == '__main__':
    unittest.main()
