======
radsrv
======


Server interface for the demographic radius search system


Description
===========

A longer description of your project goes here...


.. _pyscaffold-notes:

Development
===========

Use pyment to manage, create and update doc strings:

    find . -type f -name '*.py' -exec pyment -w {} \;



Making Changes & Contributing
=============================

This project uses `pre-commit`_, please make sure to install it before making any
changes::

    pip install pre-commit
    cd radsrv
    pre-commit install

It is a good idea to update the hooks to the latest version::

    pre-commit autoupdate

Don't forget to tell your contributors to also install and use pre-commit.

.. _pre-commit: http://pre-commit.com/


